const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const SETTINGS_KEY = "subtitleStudio.settings.v2";
const THEME_KEY = "subtitleStudio.theme";
const LAYOUT_KEY = "subtitleStudio.layout.v2";
const MODE_LABEL = { extract: "字幕提取", align: "字幕对齐" };
const THEMES = ["system", "light", "dark"];
const SESSION_TOKEN = document.querySelector('meta[name="subtitle-session"]')?.content || "";
const projectVersions = new Map();
let projectSaveChain = Promise.resolve();
let configSaveChain = Promise.resolve();
const HISTORY_LIMIT = 60;
const SAVE_DELAY = 1200;
const PARAM_LIMITS = {
  gap: { min: 0, max: 2, step: 0.1 },
  width: { min: 6, max: 30, step: 1 },
};
function defaultPanelWidth() {
  return Math.round(Math.max(336, Math.min(520, (window.innerWidth - 810) / 2)));
}
const DEFAULT_LAYOUT = { left: defaultPanelWidth(), right: defaultPanelWidth() };
const MODEL_ORDER = ["large-v3", "large-v3-turbo", "fireredasr2-aed", "qwen3-asr-1.7b", "paraformer-zh"];
const MODEL_META = {
  "tiny": {
    tag: "极速", size: "约 0.08 GB",
    desc: "最快出结果，适合先粗看内容或低配电脑；中文同音字和标点较弱，不建议作为最终字幕。",
  },
  "base": {
    tag: "轻量", size: "约 0.15 GB",
    desc: "比 tiny 稍准，速度仍然很快；适合试听素材内容，正式成片建议用 large 系列。",
  },
  "small": {
    tag: "轻量+", size: "约 0.5 GB",
    desc: "速度和准确率的折中，普通对白能用；生僻词、多人抢话仍容易出错。",
  },
  "medium": {
    tag: "均衡", size: "约 1.5 GB",
    desc: "中文短剧的均衡选择，准确率明显高于 small；CPU 也能跑，但会比 GPU 慢很多。",
  },
  "large-v3-turbo": {
    tag: "大模型·快", size: "约 1.6 GB",
    desc: "large-v3 的快速版本，准确率接近 large-v3，速度更快、占用更低；综合推荐。",
  },
  "large-v2": {
    tag: "大模型", size: "约 3.0 GB",
    desc: "上一代最准模型之一，中文稳定；与 large-v3 速度相近，但整体略旧。",
  },
  "large-v3": {
    tag: "最准", size: "约 3.0 GB",
    desc: "Whisper 系列中文通用最准的模型，适合最终成片；建议 NVIDIA GPU，CPU 会明显变慢。",
  },
};
const MEDIA_EXT_RE = /\.(mp4|mkv|mov|avi|flv|ts|m4v|webm|wmv|mp3|wav|m4a|aac|flac|ogg|opus|wma)$/i;
const SCRIPT_EXT_RE = /\.(txt|md|docx)$/i;

const state = {
  media: null,
  srtPath: "",
  subtitleFile: null,
  mediaEpoch: 0,
  uploadEpoch: 0,
  loading: false,
  operation: "",
  submitting: false,
  dirty: false,
  editRevision: 0,
  pendingSaves: 0,
  pendingResult: null,
  retryPoll: null,
  healthTimer: null,
  models: [],
  cues: [],
  script: [],
  modelDownload: null,
  auxModels: [],
  downloadTimer: null,
  downloadActive: false,
  scriptDocument: null,
  referenceGaps: [],
  scriptName: "",
  scriptPath: "",
  queue: [],
  jobId: null,
  batch: false,
  selected: -1,
  filter: "all",
  search: "",
  history: [],
  redoStack: [],
  editBefore: null,
  saveTimer: null,
  configTimer: null,
  waveform: null,
  videoErrorShown: false,
  asrEpoch: 0,
  uploading: false,
  waveSpan: 0,
  waveStart: 0,
  detailWave: null,
  detailWaveEpoch: 0,
  detailWaveTimer: null,
  auditionEnd: null,
  auditionTimer: null,
  uploadPercent: 0,
  uploadName: "",
  uploadXhr: null,
  scriptUploading: false,
  scriptUploadName: "",
  scriptXhr: null,
  scriptEpoch: 0,
  scriptPickerOpen: false,
  mediaPickerOpen: false,
  theme: "system",
  layout: { ...DEFAULT_LAYOUT },
  settings: {
    mode: "extract", model: "large-v3", device: "auto", vad: true, gap: 0.6, width: 20,
    keepPunc: true, skipEmpty: true, singleLine: false,
    excludeNoise: true, sound: true, volume: 80, arabicNumbers: false,
    matchMinimum: .64, matchHigh: .94, matchPhonetic: .90, matchAmbiguity: .035, matchGroup: 3,
    auxModel: 'qwen3-forcedaligner-0.6b',
  },
};

const video = $("#video");
const overlay = $("#overlay");
const waveCanvas = $("#wave");
const cueBody = $("#cueBody");
const emptyHint = $("#emptyHint");
const progressBar = $("#progressBar");
const jobMsg = $("#jobMsg");
const scriptList = $("#scriptList");
const toastEl = $("#toast");
const tipEl = $("#tip");
const themeRoot = document.documentElement;
const appearance = $("#appearance");
const themeButtons = $$(".appearance-btn");
const lampCord = $("#lampCord");

// ---------- 基础 ----------
async function api(path, body = null, method = null, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.timeout ?? (path === "/api/dialog" ? 610000 : 30000));
  const opt = { method: method || (body !== null ? "POST" : "GET"),
    headers: { "X-SubtitleStudio-Token": SESSION_TOKEN }, signal: controller.signal, ...options };
  if (body !== null) {
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  try {
  const res = await fetch(path, opt);
  let data;
  try {
    data = await res.json();
  } catch {
    throw new Error(`服务返回异常（HTTP ${res.status}）`);
  }
  if (!res.ok || data.ok === false) {
    const err = new Error(data.error || `请求失败（HTTP ${res.status}）`);
    err.data = data;
    err.errors = data.errors || [];
    err.status = res.status;
    throw err;
  }
  return data;
  } catch (error) {
    if (error.name === "AbortError") throw new Error("请求超时，请检查连接后重试");
    throw error;
  } finally { clearTimeout(timeout); }
}

function projectPath() { return state.media?.path || state.srtPath || ""; }
function subtitleText(text) { return window.SubtitleNumbers?.format(text, !!state.settings.arabicNumbers) ?? text; }
function editLocked() { return !!(state.jobId || state.submitting || state.batch || state.operation || state.loading || state.uploading || downloadBusy()); }
function sameDocument(path, epoch, before) {
  return projectPath() === path && state.mediaEpoch === epoch && snapshot() === before;
}
function replaceCues(cues, { reset = false, before = snapshot(), subtitleFile = state.subtitleFile } = {}) {
  state.editBefore = null;
  state.cues = cues.map(normalizeCue);
  state.subtitleFile = subtitleFile;
  state.selected = -1;
  if (reset) { state.history = []; state.redoStack = []; }
  else pushHistory(before);
  renderAll();
  updateOverlay();
  scheduleSave();
}

// 所有提示音均由浏览器本地合成；首次用户操作后解锁，不加载外部音频。
let audioContext = null;
let lastTick = 0;
function playSound(kind = "key") {
  if (!state.settings.sound || Number(state.settings.volume ?? 80) <= 0) return;
  const Audio = window.AudioContext || window.webkitAudioContext;
  if (!Audio) return;
  try {
    audioContext ||= new Audio();
    if (audioContext.state === "suspended") audioContext.resume().catch(() => {});
    const now = audioContext.currentTime;
    if (kind === "tick" && now - lastTick < 0.035) return;
    if (kind === "tick") lastTick = now;
    const notes = kind === "success" ? [[660, 0, 0.12], [880, 0.12, 0.18], [1100, 0.27, 0.24]]
      : kind === "tick" ? [[1150, 0, 0.025]] : [[520, 0, 0.055]];
    for (const [frequency, delay, duration] of notes) {
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = kind === "success" ? "sine" : "triangle";
      oscillator.frequency.setValueAtTime(frequency, now + delay);
      gain.gain.setValueAtTime(0.0001, now + delay);
      const volume = clamp(Number(state.settings.volume ?? 80), 0, 100) / 100;
      const peak = (kind === "success" ? 0.28 : kind === "tick" ? 0.18 : 0.22) * volume;
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak), now + delay + 0.004);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + duration);
      oscillator.connect(gain); gain.connect(audioContext.destination);
      oscillator.start(now + delay); oscillator.stop(now + delay + duration + 0.01);
    }
  } catch { /* 音频设备不可用时不影响操作 */ }
}

function bindFeedback() {
  document.addEventListener("pointerdown", (event) => {
    const button = event.target.closest("button");
    if (button && !button.disabled) playSound("key");
  });
  document.addEventListener("keydown", (event) => {
    const button = event.target.closest("button:not(:disabled)");
    if (!event.repeat && ["Enter", " "].includes(event.key) && button) {
      playSound("key"); button.classList.add("key-pressed");
      setTimeout(() => button.classList.remove("key-pressed"), 140);
    }
  });
  $("#soundToggle").addEventListener("click", () => {
    state.settings.sound = !state.settings.sound;
    if (state.settings.sound && !state.settings.volume) state.settings.volume = 80;
    syncSettingsUI(); collectSettings(); scheduleConfigSave(); scheduleSave();
  });
  $("#soundVolume").addEventListener("input", (event) => {
    state.settings.volume = Number(event.target.value);
    state.settings.sound = state.settings.volume > 0;
    syncSettingsUI(); collectSettings(); scheduleConfigSave(); scheduleSave(); playSound("tick");
  });
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}

const pad = (n, len = 2) => String(n).padStart(len, "0");

function fmtTime(sec, comma = false) {
  let ms = Math.round(Math.max(0, Number(sec) || 0) * 1000);
  const h = Math.floor(ms / 3600000); ms %= 3600000;
  const m = Math.floor(ms / 60000); ms %= 60000;
  const s = Math.floor(ms / 1000); ms %= 1000;
  return `${pad(h)}:${pad(m)}:${pad(s)}${comma ? "," : "."}${pad(ms, 3)}`;
}

function parseTime(value) {
  const str = String(value).trim().replace(",", ".");
  if (!str) return null;
  let m = str.match(/^(\d+):(\d{1,2}):(\d{1,2}(?:\.\d+)?)$/);
  if (m) {
    const result = Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
    return Number(m[2]) < 60 && Number(m[3]) < 60 && Number.isFinite(result) ? result : null;
  }
  m = str.match(/^(\d+):(\d{1,2}(?:\.\d+)?)$/);
  if (m) {
    const result = Number(m[1]) * 60 + Number(m[2]);
    return Number(m[2]) < 60 && Number.isFinite(result) ? result : null;
  }
  const n = Number(str);
  return Number.isFinite(n) ? n : null;
}

function readJson(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "{}");
    return value && typeof value === "object" ? value : {};
  } catch {
    return {};
  }
}

function writeJson(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ }
}

let toastTimer = null;
function toast(message, type = "info", ms = 3500) {
  toastEl.textContent = message;
  toastEl.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toastEl.className = "toast"; }, ms);
}

function setSaveState(text) {
  $("#saveState").textContent = text;
  $("#topSaveState").textContent = text;
}

// ---------- 悬浮简介 ----------
let tipTarget = null;
let tipTimer = null;
let tipHoverTarget = null;

function positionTip() {
  if (!tipTarget || !tipEl.classList.contains("show")) return;
  const r = tipTarget.getBoundingClientRect();
  const t = tipEl.getBoundingClientRect();
  let left = r.left + r.width / 2 - t.width / 2;
  left = Math.max(8, Math.min(left, window.innerWidth - t.width - 8));
  let top = r.top - t.height - 8;
  if (top < 8) top = Math.min(r.bottom + 8, window.innerHeight - t.height - 8);
  tipEl.style.left = `${Math.round(left)}px`;
  tipEl.style.top = `${Math.max(8, Math.round(top))}px`;
}

function showTip(target) {
  const text = target?.dataset.tip;
  if (!text) return;
  if (tipTarget && tipTarget !== target) tipTarget.removeAttribute("aria-describedby");
  tipTarget = target;
  target.setAttribute("aria-describedby", "tip");
  tipEl.textContent = text;
  tipEl.classList.add("show");
  positionTip();
}

function hideTip() {
  clearTimeout(tipTimer);
  tipHoverTarget = null;
  if (tipTarget) tipTarget.removeAttribute("aria-describedby");
  tipTarget = null;
  tipEl.classList.remove("show");
}

function bindTooltips() {
  document.addEventListener("pointerover", (e) => {
    const target = e.target.closest?.("[data-tip]");
    if (!target || target === tipHoverTarget || target === tipTarget) return;
    hideTip();
    tipHoverTarget = target;
    tipTimer = setTimeout(() => {
      if (target.isConnected && target.matches(":hover")) showTip(target);
    }, 600);
  });
  document.addEventListener("pointerout", (e) => {
    const target = tipTarget || tipHoverTarget;
    if (!target) return;
    const to = e.relatedTarget;
    if (to && target.contains(to)) return;
    hideTip();
  });
  document.addEventListener("focusin", (e) => {
    const target = e.target.closest?.("[data-tip]");
    if (target && e.target.matches(":focus-visible")) showTip(target);
  });
  document.addEventListener("focusout", () => hideTip());
  document.addEventListener("pointerdown", hideTip);
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") hideTip(); });
  window.addEventListener("scroll", hideTip, true);
  window.addEventListener("resize", hideTip);
  window.addEventListener("resize", () => toggleModelMenu(false));
  window.addEventListener("scroll", e => { if (!e.target.closest?.("#modelMenu")) positionModelMenu(); }, true);
}

// ---------- 主题 ----------
let cordPull = 0;
let cordVelocity = 0;
let cordFrame = 0;
let cordPulseTimer = 0;
let cordPointer = null;
const CORD_THRESHOLD = 17;
const CORD_RESIST_FROM = 25;

function reduceMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function cordThemeTarget() {
  let dark = state.theme === "dark";
  if (state.theme === "system") dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  return dark ? "light" : "dark";
}

function applyTheme(theme, persist = true) {
  if (!THEMES.includes(theme)) theme = "system";
  state.theme = theme;
  if (theme === "system") themeRoot.removeAttribute("data-theme");
  else themeRoot.dataset.theme = theme;
  if (persist) {
    try { localStorage.setItem(THEME_KEY, theme); } catch { /* ignore */ }
  }
  appearance.style.setProperty("--theme-index", String(THEMES.indexOf(theme)));
  themeButtons.forEach((button) => {
    const active = button.dataset.theme === theme;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", active ? "true" : "false");
  });
  lampCord.setAttribute("aria-label", `向下拉动，切换为${cordThemeTarget() === "dark" ? "深色" : "浅色"}主题`);
  if (persist) scheduleConfigSave();
  if (typeof drawWave === "function") drawWave();
}

function switchTheme(theme, useViewTransition = true) {
  if (theme === state.theme) return;
  if (!useViewTransition || !document.startViewTransition || reduceMotion()) {
    themeRoot.classList.add("theme-changing");
    applyTheme(theme);
    window.setTimeout(() => themeRoot.classList.remove("theme-changing"), 320);
    return;
  }
  try {
    document.startViewTransition(() => applyTheme(theme));
  } catch {
    applyTheme(theme);
  }
}

function renderCord(pull) {
  cordPull = pull;
  lampCord.style.setProperty("--cord-pull", `${pull.toFixed(2)}px`);
  lampCord.style.setProperty("--cord-stretch", `${Math.max(0, pull).toFixed(2)}px`);
}

function stopCordMotion() {
  if (cordFrame) cancelAnimationFrame(cordFrame);
  if (cordPulseTimer) window.clearTimeout(cordPulseTimer);
  cordFrame = 0;
  cordPulseTimer = 0;
}

function animateCordSpring(from, velocity) {
  stopCordMotion();
  if (reduceMotion()) {
    lampCord.classList.remove("is-pulling");
    renderCord(0);
    return;
  }
  lampCord.classList.add("is-pulling");
  let position = from;
  let speed = velocity;
  let last = performance.now();
  const tick = (now) => {
    const elapsed = Math.min(0.032, Math.max(0.001, (now - last) / 1000));
    last = now;
    const steps = Math.max(1, Math.ceil(elapsed / 0.008));
    const step = elapsed / steps;
    for (let i = 0; i < steps; i += 1) {
      const accel = -250 * position - 17 * speed;
      speed += accel * step;
      position += speed * step;
    }
    if (position < -4.5) {
      position = -4.5;
      speed = Math.max(0, speed);
    } else if (position > 42) {
      position = 42;
      speed = Math.min(0, speed);
    }
    renderCord(position);
    if (Math.abs(position) < 0.05 && Math.abs(speed) < 0.9) {
      renderCord(0);
      lampCord.classList.remove("is-pulling");
      cordFrame = 0;
      return;
    }
    cordFrame = requestAnimationFrame(tick);
  };
  cordFrame = requestAnimationFrame(tick);
}

function pulseCord() {
  stopCordMotion();
  if (reduceMotion()) {
    switchTheme(cordThemeTarget(), false);
    return;
  }
  renderCord(14);
  lampCord.classList.add("is-pulling");
  cordPulseTimer = window.setTimeout(() => {
    cordPulseTimer = 0;
    switchTheme(cordThemeTarget(), false);
    animateCordSpring(14, -18);
  }, 70);
}

function bindThemeControls() {
  themeButtons.forEach((button) => {
    button.addEventListener("click", () => switchTheme(button.dataset.theme));
  });

  lampCord.addEventListener("pointerdown", (event) => {
    if (event.pointerType === "mouse" && event.button !== 0) return;
    event.preventDefault();
    stopCordMotion();
    cordPointer = {
      id: event.pointerId,
      startY: event.clientY,
      startPull: cordPull,
      lastTime: performance.now(),
      moved: false,
    };
    cordVelocity = 0;
    lampCord.classList.add("is-pulling");
    if (lampCord.setPointerCapture) lampCord.setPointerCapture(event.pointerId);
  });

  lampCord.addEventListener("pointermove", (event) => {
    if (!cordPointer || event.pointerId !== cordPointer.id) return;
    event.preventDefault();
    const raw = Math.max(0, cordPointer.startPull + event.clientY - cordPointer.startY);
    const pull = raw <= CORD_RESIST_FROM
      ? raw
      : CORD_RESIST_FROM + (raw - CORD_RESIST_FROM) * 0.24;
    const now = performance.now();
    const elapsed = Math.max(1, now - cordPointer.lastTime);
    const instant = ((pull - cordPull) / elapsed) * 1000;
    cordVelocity = cordVelocity * 0.7 + instant * 0.3;
    cordPointer.lastTime = now;
    if (Math.abs(event.clientY - cordPointer.startY) > 3) cordPointer.moved = true;
    renderCord(pull);
  });

  const endCord = (event, cancelled) => {
    if (!cordPointer || event.pointerId !== cordPointer.id) return;
    const wasMoved = cordPointer.moved;
    if (lampCord.hasPointerCapture?.(event.pointerId)) {
      lampCord.releasePointerCapture(event.pointerId);
    }
    cordPointer = null;
    if (!cancelled && cordPull >= CORD_THRESHOLD) {
      switchTheme(cordThemeTarget(), false);
      animateCordSpring(cordPull, cordVelocity);
    } else if (!cancelled && !wasMoved) {
      pulseCord();
    } else {
      animateCordSpring(cordPull, cordVelocity);
    }
    cordVelocity = 0;
  };

  lampCord.addEventListener("pointerup", (event) => endCord(event, false));
  lampCord.addEventListener("pointercancel", (event) => endCord(event, true));
  lampCord.addEventListener("click", (event) => {
    if (event.detail !== 0) {
      event.preventDefault();
      return;
    }
    pulseCord();
  });
}

// ---------- 设置 ----------
function modeLabel() {
  return MODE_LABEL[state.settings.mode] || MODE_LABEL.extract;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function normalizeSettings() {
  const s = state.settings;
  s.mode = s.mode === "align" ? "align" : "extract";
  s.device = ["auto", "cpu", "cuda"].includes(s.device) ? s.device : "auto";
  s.model = String(s.model || "medium");
  s.vad = s.vad !== false;
  s.gap = Math.round(clamp(Number(s.gap) || 0, PARAM_LIMITS.gap.min, PARAM_LIMITS.gap.max) * 10) / 10;
  s.width = Math.round(clamp(Number(s.width) || 20, PARAM_LIMITS.width.min, PARAM_LIMITS.width.max));
  delete s.addPunc;
  delete s.withRole;
  s.keepPunc = s.keepPunc !== false;
  s.skipEmpty = s.skipEmpty !== false;
  s.singleLine = s.singleLine === true;
  s.excludeNoise = s.excludeNoise !== false;
  s.sound = s.sound !== false;
  s.arabicNumbers = s.arabicNumbers === true;
  for (const [key, fallback] of Object.entries({matchMinimum:.64, matchHigh:.94, matchPhonetic:.90, matchAmbiguity:.035})) {
    s[key] = Number.isFinite(Number(s[key])) ? clamp(Number(s[key]), 0, 1) : fallback;
  }
  s.matchHigh = Math.max(s.matchHigh, s.matchMinimum);
  s.matchGroup = Math.round(clamp(Number(s.matchGroup) || 3, 1, 4));
  s.volume = Number.isFinite(Number(s.volume ?? 80)) ? Math.round(clamp(Number(s.volume ?? 80), 0, 100)) : 80;
}

function updateWidthInfo() {
  const s = state.settings;
  $("#widthInfo").textContent = `${modeLabel()} · 每行 ≤ ${s.width} · 停顿 ≥ ${s.gap}s`;
}

function updateModeNote() {
  if (state.settings.mode !== 'align') {
    $('#modeNote').textContent = '提取视频人声，生成并导出 SRT';
    return;
  }
  $('#modeNote').textContent = '对齐视频音轨，剧本作为纠错参考';
}

const PARAM_FIELDS = [
  { key: "gap", input: "#gapInput", range: "#gapRange", ...PARAM_LIMITS.gap },
  { key: "width", input: "#widthInput", range: "#widthRange", ...PARAM_LIMITS.width },
];

function syncParamControl(param, value = null) {
  const input = $(param.input);
  const range = $(param.range);
  if (!input || !range) return;
  if (value !== null) {
    const v = clamp(Number(value) || param.min, param.min, param.max);
    input.value = param.step < 1 ? v.toFixed(1) : String(Math.round(v));
  }
  const current = clamp(Number(input.value) || param.min, param.min, param.max);
  range.value = String(current);
  const pct = param.max > param.min ? ((current - param.min) / (param.max - param.min)) * 100 : 0;
  range.style.setProperty("--fill", `${pct}%`);
  const stepper = range.closest(".param")?.querySelector(".stepper");
  if (stepper) {
    stepper.querySelector('[data-dir="1"]').disabled = current >= param.max;
    stepper.querySelector('[data-dir="-1"]').disabled = current <= param.min;
  }
}

function syncParamControls() {
  for (const param of PARAM_FIELDS) syncParamControl(param, state.settings[param.key]);
}

function syncSettingsUI() {
  const s = state.settings;
  $("#deviceSelect").value = s.device;
  $("#vadCheck").checked = !!s.vad;
  for (const key of ["keepPunc", "skipEmpty", "singleLine"]) $("#" + key).checked = !!s[key];
  for (const key of ['matchMinimum','matchHigh','matchPhonetic','matchAmbiguity','matchGroup']) $('#' + key).value = s[key];
  $("#excludeNoise").checked = !!s.excludeNoise;
  $("#arabicNumbers").checked = !!s.arabicNumbers;
  $("#soundToggle").setAttribute("aria-pressed", s.sound ? "true" : "false");
  $("#soundToggle").textContent = s.sound ? "音效 开" : "音效 关";
  $("#soundVolume").value = String(s.volume);
  $("#soundLevel").textContent = s.volume + "%";
  syncParamControls();
  setMode(s.mode, false);
  updateModelButton();
}

function setMode(mode, persist = true) {
  if (persist && editLocked()) return;
  const previous = state.settings.mode;
  state.settings.mode = mode === "align" ? "align" : "extract";
  const next = state.settings.mode;
  $$(".mode-btn").forEach((btn) => {
    const active = btn.dataset.mode === next;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-selected", active ? "true" : "false");
    btn.tabIndex = active ? 0 : -1;
  });
  updateModeNote();
  updateModeUI();
  updateWidthInfo();
  renderScript();
  updateButtons();
  renderSubtitleSource();
  if (persist && previous !== next && next === "align" && state.subtitleFile?.origin === "generated" && state.cues.length) {
    toast("已带入提取的 SRT，继续导入剧本即可对齐", "success");
  }
  if (persist) {
    collectSettings();
    scheduleSave();
    scheduleConfigSave();
  }
}

function updateModeUI() {
  const align = state.settings.mode === "align";
  document.body.dataset.mode = align ? 'align' : 'extract';
  $('#settingsTitle').textContent = '识别设置';
  const zone = $("#scriptZone");
  $("#dropgrid").classList.toggle("single", !align);
  zone.hidden = !align;
  zone.classList.toggle("mode-needed", align && !state.script.length && !state.scriptUploading);
  zone.setAttribute("aria-disabled", align ? "false" : "true");
  zone.tabIndex = align ? 0 : -1;
  $("#extractActions").hidden = false;
  $("#rightModeNote").hidden = align;
  scriptList.hidden = !align;
  $("#btnRematchAll").hidden = !align;
  $('#referenceSettings').hidden = !align;
  $('#btnExtract').textContent = align ? '对齐并校验' : '提取字幕';
  $('#btnExtract').dataset.tip = align ? '导入媒体、SRT 与剧本后，一键对齐视频音轨并反向校验。保留原 ASR；参考文字仍需人工确认采用。需下载 Qwen3-ForcedAligner 辅模。' : '提取视频或音频中的人声字幕，生成 SRT。';
  const clear = $("#scriptClear");
  clear.hidden = !align || (!state.script.length && !state.scriptUploading);
  clear.disabled = !align;
}

function loadSettings() {
  Object.assign(state.settings, readJson(SETTINGS_KEY));
  normalizeSettings();
  syncSettingsUI();
}

function collectSettings() {
  const s = state.settings;
  normalizeSettings();
  s.model = String($("#modelBtnText").dataset.model || s.model || "medium");
  s.device = $("#deviceSelect").value;
  s.vad = $("#vadCheck").checked;
  s.gap = Math.round(clamp(
    Number($("#gapInput").value) || 0, PARAM_LIMITS.gap.min, PARAM_LIMITS.gap.max
  ) * 10) / 10;
  s.width = Math.round(clamp(
    Number($("#widthInput").value) || 20, PARAM_LIMITS.width.min, PARAM_LIMITS.width.max
  ));
  for (const key of ["keepPunc", "skipEmpty", "singleLine"]) s[key] = $("#" + key).checked;
  for (const key of ['matchMinimum','matchHigh','matchPhonetic','matchAmbiguity','matchGroup']) s[key] = Number($('#' + key).value);
  normalizeSettings();
  s.excludeNoise = $("#excludeNoise").checked;
  s.arabicNumbers = $("#arabicNumbers").checked;
  syncParamControls();
  writeJson(SETTINGS_KEY, s);
  updateWidthInfo();
  return s;
}

function commitSettings() {
  collectSettings();
  updateButtons();
  renderTable();
  updateOverlay();
  scheduleConfigSave();
  scheduleSave();
}

function applyProjectSettings(saved) {
  if (!saved || typeof saved !== "object") return;
  const s = state.settings;
  if (saved.mode === "extract" || saved.mode === "align") s.mode = saved.mode;
  if (saved.width != null) s.width = clamp(
    Number(saved.width) || 20, PARAM_LIMITS.width.min, PARAM_LIMITS.width.max
  );
  if (saved.gap != null) s.gap = clamp(
    Number(saved.gap) || 0, PARAM_LIMITS.gap.min, PARAM_LIMITS.gap.max
  );
  if (saved.vad != null) s.vad = !!saved.vad;
  if (saved.device) s.device = ["auto", "cpu", "cuda"].includes(saved.device) ? saved.device : "auto";
  if (saved.model && modelIsAvailable(saved.model)) s.model = saved.model;
  for (const key of ["keepPunc", "skipEmpty", "singleLine"]) if (saved[key] != null) s[key] = !!saved[key];
  for (const key of ['matchMinimum','matchHigh','matchPhonetic','matchAmbiguity','matchGroup']) if (saved[key] != null) s[key] = saved[key];
  if (saved.excludeNoise != null) s.excludeNoise = !!saved.excludeNoise;
  if (saved.sound != null) s.sound = !!saved.sound;
  if (saved.arabicNumbers != null) s.arabicNumbers = !!saved.arabicNumbers;
  if (saved.volume != null) s.volume = saved.volume;
  normalizeSettings();
  syncSettingsUI();
  scheduleConfigSave();
}

// ---------- 界面布局 ----------
function clampPanelWidths() {
  const viewport = window.innerWidth || 1440;
  const rightVisible = viewport > 1180;
  const maxLeft = rightVisible
    ? Math.max(280, Math.min(520, viewport - state.layout.right - 460))
    : Math.max(280, Math.min(520, viewport - 460));
  const maxRight = Math.max(280, Math.min(520, viewport - state.layout.left - 460));
  state.layout.left = Math.round(clamp(state.layout.left, 280, maxLeft));
  state.layout.right = Math.round(clamp(state.layout.right, 280, maxRight));
}

function applyLayout() {
  clampPanelWidths();
  const layout = $("#layout");
  layout.style.setProperty("--left-w", `${state.layout.left}px`);
  layout.style.setProperty("--right-w", `${state.layout.right}px`);
}

function loadLayoutLocal() {
  const saved = readJson(LAYOUT_KEY);
  if (Number.isFinite(Number(saved.left))) state.layout.left = Number(saved.left);
  if (Number.isFinite(Number(saved.right))) state.layout.right = Number(saved.right);
  applyLayout();
}

function saveLayoutLocal() {
  writeJson(LAYOUT_KEY, state.layout);
}

function bindSplitters() {
  $$(".splitter").forEach((splitter) => {
    splitter.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      event.preventDefault();
      hideTip();
      const side = splitter.dataset.side;
      const startX = event.clientX;
      const startWidth = side === "left" ? state.layout.left : state.layout.right;
      splitter.setPointerCapture?.(event.pointerId);
      document.body.classList.add("col-resizing");

      const onMove = (moveEvent) => {
        if (moveEvent.pointerId !== event.pointerId) return;
        const delta = moveEvent.clientX - startX;
        if (side === "left") state.layout.left = startWidth + delta;
        else state.layout.right = startWidth - delta;
        applyLayout();
      };
      const onUp = (upEvent) => {
        if (upEvent.pointerId !== event.pointerId) return;
        splitter.removeEventListener("pointermove", onMove);
        splitter.removeEventListener("pointerup", onUp);
        splitter.removeEventListener("pointercancel", onUp);
        document.body.classList.remove("col-resizing");
        if (splitter.hasPointerCapture?.(upEvent.pointerId)) {
          splitter.releasePointerCapture(upEvent.pointerId);
        }
        saveLayoutLocal();
        scheduleConfigSave();
        drawWave();
      };
      splitter.addEventListener("pointermove", onMove);
      splitter.addEventListener("pointerup", onUp);
      splitter.addEventListener("pointercancel", onUp);
    });

    splitter.addEventListener("keydown", (event) => {
      if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
      event.preventDefault();
      const step = event.shiftKey ? 40 : 10;
      const direction = event.key === "ArrowRight" ? 1 : -1;
      if (splitter.dataset.side === "left") state.layout.left += direction * step;
      else state.layout.right -= direction * step;
      applyLayout();
      saveLayoutLocal();
      scheduleConfigSave();
      drawWave();
    });
  });

  window.addEventListener("resize", () => {
    applyLayout();
    drawWave();
  });
}

// ---------- 连接与模型 ----------
async function loadConfig() {
  try {
    const d = await api("/api/config");
    const cfg = d.config || {};
    if (!localStorage.getItem(THEME_KEY) && THEMES.includes(cfg.theme)) {
      applyTheme(cfg.theme, false);
      try { localStorage.setItem(THEME_KEY, cfg.theme); } catch { /* ignore */ }
    }
    if (!localStorage.getItem(SETTINGS_KEY) && cfg.settings && typeof cfg.settings === "object") {
      Object.assign(state.settings, cfg.settings);
      normalizeSettings();
      syncSettingsUI();
    }
    // 旧版保存的栏宽可能左右不等，不再恢复；从 v2 起才认配置里的栏宽。
    if (!localStorage.getItem(LAYOUT_KEY) && cfg.layout_version === 2
        && cfg.layout && typeof cfg.layout === "object") {
      if (Number.isFinite(Number(cfg.layout.left))) state.layout.left = Number(cfg.layout.left);
      if (Number.isFinite(Number(cfg.layout.right))) state.layout.right = Number(cfg.layout.right);
      applyLayout();
    }
  } catch { /* 配置不存在时使用默认值 */ }
}

async function saveConfig(silent = true) {
  const payload = { settings: { ...collectSettings() }, layout: { ...state.layout }, layoutVersion: 2, theme: state.theme };
  const task = configSaveChain.then(async () => {
  try {
    await api("/api/config", payload);
    return true;
  } catch (error) {
    if (!silent) toast(`配置保存失败：${error.message}`, "error");
    return false;
  }
  });
  configSaveChain = task.catch(() => false);
  return task;
}

function scheduleConfigSave() {
  clearTimeout(state.configTimer);
  state.configTimer = setTimeout(() => saveConfig(true), 800);
}

async function checkHealth() {
  clearTimeout(state.healthTimer);
  try {
    const d = await api("/api/health");
    $("#healthDot").className = "ok";
    $("#healthText").textContent = `已连接 v${d.version}`;
    state.models = d.models || [];
    state.auxModels = d.auxiliary || [];
    renderModels();
  } catch (e) {
    $("#healthDot").className = "bad";
    $("#healthText").textContent = "未连接";
    state.healthTimer = setTimeout(checkHealth, 5000);
  }
}

function modelMeta(name) {
  const model = state.models.find(m => m.name === name);
  return model ? {tag:'', size:model.size_hint || '', desc:model.description || '本地识别模型'} : MODEL_META[name] || {tag:'',size:'',desc:''};
}
function modelIsAvailable(name) { return !!state.models.find(m => m.name === name)?.available; }
function orderedModels() {
  return [...state.models].sort((a,b) => (MODEL_ORDER.includes(a.name) ? MODEL_ORDER.indexOf(a.name) : 99) - (MODEL_ORDER.includes(b.name) ? MODEL_ORDER.indexOf(b.name) : 99));
}
function renderModels() { updateModelButton(); renderModelMenu(); renderAuxModels(); updateButtons(); }
function renderAuxModels() {
  const selected = state.auxModels.find(m => m.name === state.settings.auxModel) || state.auxModels[0];
  $('#auxBtnText').textContent = selected?.label || 'Qwen3-ForcedAligner-0.6B';
  $('#auxHelp').dataset.tip = state.auxModels.map(m => m.label + '：' + m.description).join('\n');
  $('#auxHelp').hidden = !$('#auxHelp').dataset.tip.trim();
  $('#auxMenu').innerHTML = state.auxModels.map(m => '<div class="model-choice"><button type="button" class="model-option" role="option" data-aux="' + escapeHtml(m.name) + '" aria-selected="' + (m.name === selected?.name) + '" ' + (!m.available ? 'disabled' : '') + '>' + escapeHtml(m.label) + '</button>' + (!m.available ? '<button type="button" class="model-download" data-download="' + escapeHtml(m.name) + '" ' + (downloadBusy() ? 'disabled' : '') + '>下载</button>' : '<span class="model-ready">已就绪</span>') + '</div>').join('');
}
function toggleAuxMenu(open) {
  const menu = $('#auxMenu'), next = open ?? menu.hidden; menu.hidden = !next;
  $('#auxBtn').setAttribute('aria-expanded', next ? 'true' : 'false');
  if (next) {
    renderAuxModels(); const r = $('#auxBtn').getBoundingClientRect();
    const width = Math.min(Math.max(r.width, 310), innerWidth - 16);
    menu.style.width = width + 'px'; menu.style.left = Math.max(8, r.right - width) + 'px';
    menu.style.top = Math.min(r.bottom + 4, innerHeight - 100) + 'px';
  }
}
function renderModelMenu() {
  const menu = $('#modelMenu');
  menu.innerHTML = orderedModels().map(m => '<div class="model-choice">' +
    '<button type="button" class="model-option" role="option" data-name="' + escapeHtml(m.name) + '" aria-selected="' + (m.name === state.settings.model) + '" ' + (!m.available ? 'disabled' : '') + '>' + escapeHtml(m.label || m.name) + '</button>' +
    (!m.available ? '<button type="button" class="model-download" data-download="' + escapeHtml(m.name) + '" ' + (downloadBusy() || state.jobId ? 'disabled' : '') + '>' + (m.downloaded ? '初始化' : '下载') + '</button>' : '<span class="model-ready">已就绪</span>') + '</div>').join('');
}
function updateModelButton() {
  const btn = $('#modelBtn'), text = $('#modelBtnText');
  const available = orderedModels().filter(m => m.available);
  if (!state.models.some(m => m.name === state.settings.model)) state.settings.model = available[0]?.name || 'large-v3';
  const selected = state.models.find(m => m.name === state.settings.model);
  text.textContent = selected?.label || state.settings.model;
  text.dataset.model = state.settings.model;
  btn.disabled = !state.models.length || (!!state.jobId);
  $('#modelHelp').dataset.tip = orderedModels().map(m => (m.label || m.name) + '：' + (m.description || modelMeta(m.name).desc)).join('\n');
  $('#modelHelp').hidden = !$('#modelHelp').dataset.tip.trim();
}
function positionModelMenu() {
  const menu = $('#modelMenu'); if (menu.hidden) return;
  const r = $('#modelBtn').getBoundingClientRect();
  const width = Math.min(Math.max(r.width, 290), innerWidth - 16);
  menu.style.width = width + 'px';
  menu.style.left = Math.max(8, Math.min(r.right - width, innerWidth - width - 8)) + 'px';
  const height = Math.min(220, menu.scrollHeight);
  menu.style.top = (r.bottom + height + 5 > innerHeight ? Math.max(8, r.top - height - 5) : r.bottom + 4) + 'px';
}
function toggleModelMenu(open) {
  const menu = $('#modelMenu'), next = open ?? menu.hidden;
  menu.hidden = !next; $('#modelBtn').setAttribute('aria-expanded', next ? 'true' : 'false');
  if (next) { renderModelMenu(); positionModelMenu(); }
}
function chooseModel(name) {
  if (!modelIsAvailable(name)) return;
  state.settings.model = name; updateModelButton(); renderModelMenu(); collectSettings(); updateButtons(); scheduleConfigSave(); toggleModelMenu(false);
}
function modelAvailable() { return modelIsAvailable(state.settings.model); }
function downloadBusy() { return ['downloading','preparing'].includes(state.modelDownload?.status); }
function showDownloadProgress() {
  const d = state.modelDownload; if (!d || d.status === 'idle') return;
  const ratio = Math.round((d.progress || 0) * 100);
  progressBar.style.width = ratio + '%';
  progressBar.style.background = d.status === 'error' ? 'var(--red)' : 'var(--accent)';
  progressBar.parentElement.classList.toggle('indeterminate', d.status === 'preparing');
  const bytes = d.total ? ' · ' + (d.downloaded / 1024**2).toFixed(0) + '/' + (d.total / 1024**2).toFixed(0) + ' MB' : '';
  jobMsg.textContent = d.message + (d.status === 'downloading' ? ' · ' + ratio + '%' + bytes : '');
  $('#btnCancel').textContent = downloadBusy() ? '暂停下载' : '取消';
}
async function pollModelDownload() {
  clearTimeout(state.downloadTimer);
  try {
    state.modelDownload = (await api('/api/models/download')).download;
    if (!state.jobId) showDownloadProgress();
    updateButtons();
    if (downloadBusy()) { state.downloadActive = true; state.downloadTimer = setTimeout(pollModelDownload, 700); }
    else if (state.modelDownload.status !== 'idle') {
      const catalog = await api('/api/models'); state.models = catalog.models || []; state.auxModels = catalog.auxiliary || [];
      if (state.modelDownload.status === 'done' && state.downloadActive) {
        if (state.models.some(m => m.name === state.modelDownload.model)) state.settings.model = state.modelDownload.model;
        else state.settings.auxModel = state.modelDownload.model;
        playSound('success');
      }
      state.downloadActive = false;
      renderModels();
    }
  } catch (error) { jobMsg.textContent = '下载状态查询失败，正在重试：' + error.message; state.downloadTimer = setTimeout(pollModelDownload, 1800); }
}
async function downloadModel(name) {
  if (editLocked()) return;
  try {
    state.modelDownload = (await api('/api/models/download', {model:name})).download;
    state.downloadActive = true;
    toggleModelMenu(false); toggleAuxMenu(false); showDownloadProgress(); updateButtons();
    $('#jobMsg').scrollIntoView({block:'nearest'}); await pollModelDownload();
  } catch(error) { toast(error.message,'error'); }
}

function isMediaName(name) {
  return MEDIA_EXT_RE.test(String(name || ""));
}

function isScriptName(name) {
  return SCRIPT_EXT_RE.test(String(name || ""));
}

function uploadFile(file, kind, onProgress = null) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/upload?kind=${encodeURIComponent(kind)}`);
    xhr.setRequestHeader("Content-Type", "application/octet-stream");
    xhr.setRequestHeader("X-Upload-Name", encodeURIComponent(file.name));
    xhr.setRequestHeader("X-SubtitleStudio-Token", SESSION_TOKEN);
    xhr.timeout = 30 * 60 * 1000;
    xhr.responseType = "json";
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && onProgress) onProgress(event.loaded / event.total);
    };
    xhr.onload = () => {
      let data = xhr.response;
      if (!data) {
        try { data = JSON.parse(xhr.responseText || "{}"); } catch { data = {}; }
      }
      if (xhr.status >= 200 && xhr.status < 300 && data && data.ok !== false) {
        resolve(data);
      } else {
        reject(new Error(data?.error || `导入失败（HTTP ${xhr.status}）`));
      }
    };
    xhr.onerror = () => reject(new Error("无法连接本地服务"));
    xhr.ontimeout = () => reject(new Error("文件导入超时，请重试"));
    xhr.onabort = () => {
      const error = new Error("已取消");
      error.name = "AbortError";
      reject(error);
    };
    if (kind === "media") {
      state.uploadXhr = xhr;
    } else if (kind === "script") {
      state.scriptXhr = xhr;
    }
    xhr.send(file);
  });
}

async function pickMedia() {
  if (editLocked() || state.mediaPickerOpen) return;
  state.mediaPickerOpen = true;
  updateButtons();
  try {
    const d = await api("/api/dialog", { kind: "media", multiple: false });
    if (d.path) await loadMedia(d.path);
  } catch (e) {
    toast(e.message, "error");
  } finally {
    state.mediaPickerOpen = false;
    updateButtons();
  }
}

async function pickScript() {
  if (state.settings.mode !== "align") {
    toast("字幕提取模式不使用剧本；切换到「字幕对齐」后再导入", "error", 5000);
    return;
  }
  if (editLocked() || state.scriptUploading || state.scriptPickerOpen) return;
  state.scriptPickerOpen = true;
  updateButtons();
  try {
    const d = await api("/api/dialog", { kind: "script", multiple: false });
    if (!d.path) return;
    const r = await api("/api/script/parse", { path: d.path });
    applyScriptResult(r, d.path);
  } catch (e) {
    toast(e.message, "error");
  } finally {
    state.scriptPickerOpen = false;
    updateButtons();
  }
}

function applyScriptResult(result, sourceName = "") {
  state.script = result.lines || [];
  state.scriptDocument = result.document || null;
  state.referenceGaps = [];
  state.cues.forEach(cue => { cue.reference_match = null; cue.script_text = ''; cue.script_index = null; cue.match_ratio = null; });
  state.scriptName = result.name || sourceName.split(/[\\/]/).pop() || "剧本";
  state.scriptPath = "";
  renderScript();
  scheduleSave();
  const stats = result.stats || {};
  toast(`参考剧本已导入：${stats.total ?? state.script.length} 段，无需整理格式`, "success");
}

async function startScriptUpload(file) {
  if (state.settings.mode !== "align") {
    toast("字幕提取模式不使用剧本；切换到「字幕对齐」后再导入", "error", 5000);
    return;
  }
  if (state.batch || state.jobId) {
    toast("任务处理中，暂时不能更换剧本", "error");
    return;
  }
  if (!isScriptName(file.name)) {
    toast("剧本仅支持 TXT / MD / DOCX；.doc 请先另存为 .docx", "error", 6000);
    return;
  }
  if (state.scriptUploading) {
    toast("正在读取上一个剧本，请稍候", "error");
    return;
  }
  abortScriptUpload();
  const epoch = ++state.scriptEpoch;
  state.scriptUploading = true;
  state.scriptUploadName = file.name;
  renderScript();
  updateButtons();
  try {
    const uploaded = await uploadFile(file, "script");
    if (epoch !== state.scriptEpoch) return;
    const result = await api("/api/script/parse", { path: uploaded.path, remove_after: true });
    if (epoch !== state.scriptEpoch) return;
    state.scriptUploading = false;
    state.scriptXhr = null;
    applyScriptResult(result, uploaded.name || file.name);
  } catch (error) {
    if (epoch === state.scriptEpoch && error.name !== "AbortError") {
      toast(error.message, "error", 7000);
    }
  } finally {
    if (epoch === state.scriptEpoch) {
      state.scriptUploading = false;
      state.scriptXhr = null;
      renderScript();
      updateButtons();
    }
  }
}

function abortScriptUpload() {
  state.scriptEpoch += 1;
  if (state.scriptXhr) {
    const xhr = state.scriptXhr;
    state.scriptXhr = null;
    try { xhr.abort(); } catch { /* ignore */ }
  }
  state.scriptUploading = false;
  state.scriptUploadName = "";
}

function clearScript() {
  if (editLocked()) return;
  if (!state.script.length && !state.scriptUploading) return;
  abortScriptUpload();
  state.script = [];
  state.scriptDocument = null; state.referenceGaps = [];
  state.cues.forEach(cue => { cue.reference_match = null; cue.script_text = ''; cue.script_index = null; cue.match_ratio = null; });
  state.scriptName = "";
  state.scriptPath = "";
  renderScript();
  scheduleSave();
  toast("已移除剧本");
}

async function startMediaUpload(file) {
  if (editLocked()) { toast('正在处理，请稍候或先取消导入', 'error'); return; }
  if (!isMediaName(file.name)) { toast('不支持的媒体格式', 'error'); return; }
  const epoch = ++state.uploadEpoch;
  state.uploading = true; state.uploadPercent = 0; state.uploadName = file.name;
  renderMediaMeta(); updateButtons();
  try {
    const uploaded = await uploadFile(file, 'media', ratio => {
      if (epoch !== state.uploadEpoch) return;
      state.uploadPercent = Math.round(ratio * 100);
      $('#mediaMeta').textContent = '正在导入 ' + state.uploadPercent + '%';
      $('#mediaInfo').textContent = file.name; progressBar.style.width = state.uploadPercent + '%';
    });
    if (epoch !== state.uploadEpoch) return;
    state.uploadXhr = null; state.uploading = false;
    const loaded = await loadMedia(uploaded.path, { uploaded: true });
    if (epoch !== state.uploadEpoch) return;
    if (loaded) toast('素材已导入，SRT将输出到工作副本旁', 'success');
  } catch (error) {
    if (epoch === state.uploadEpoch && error.name !== 'AbortError') toast(error.message, 'error');
  } finally {
    if (epoch === state.uploadEpoch) {
      state.uploadXhr = null; state.uploading = false; progressBar.style.width = '0%';
      renderMediaMeta(); updateButtons();
    }
  }
}

function bindDropzones() {
  const setup = (zone, options) => {
    zone.addEventListener("click", (event) => {
      if (event.target.closest(".drop-clear")) return;
      if (options.disabled()) return;
      options.onPick();
    });
    zone.addEventListener("keydown", (event) => {
      if (event.target.closest(".drop-clear")) return;
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      if (options.disabled()) return;
      options.onPick();
    });
    zone.addEventListener("dragover", (event) => {
      event.preventDefault();
      if (options.disabled()) {
        event.dataTransfer.dropEffect = "none";
        return;
      }
      event.dataTransfer.dropEffect = "copy";
      zone.classList.add("over");
    });
    zone.addEventListener("dragleave", (event) => {
      if (!zone.contains(event.relatedTarget)) zone.classList.remove("over");
    });
    zone.addEventListener("drop", (event) => {
      event.preventDefault();
      zone.classList.remove("over");
      if (options.disabled()) return;
      const file = event.dataTransfer?.files?.[0];
      if (!file) return;
      options.onFile(file);
    });
  };

  setup($("#mediaZone"), {
    disabled: () => state.batch || !!state.jobId || state.uploading || state.mediaPickerOpen,
    onPick: pickMedia,
    onFile: startMediaUpload,
  });
  setup($("#scriptZone"), {
    disabled: () => state.settings.mode !== "align" || state.batch || !!state.jobId
      || state.scriptUploading || state.scriptPickerOpen,
    onPick: pickScript,
    onFile: startScriptUpload,
  });

  $("#mediaClear").addEventListener("click", (event) => {
    event.stopPropagation();
    clearMedia();
  });
  $("#scriptClear").addEventListener("click", (event) => {
    event.stopPropagation();
    clearScript();
  });
  const subtitleZone = $('#subtitleSource');
  subtitleZone.addEventListener('dragover', event => {
    event.preventDefault();
    if (state.settings.mode === 'align' && !editLocked()) subtitleZone.classList.add('over');
  });
  subtitleZone.addEventListener('dragleave', event => { if (!subtitleZone.contains(event.relatedTarget)) subtitleZone.classList.remove('over'); });
  subtitleZone.addEventListener('drop', event => {
    event.preventDefault(); subtitleZone.classList.remove('over');
    if (editLocked()) return;
    if (state.settings.mode !== 'align') { toast('此处显示提取生成物，请切换字幕对齐后拖入 SRT'); return; }
    const file = event.dataTransfer?.files?.[0];
    if (!file || !/\.srt$/i.test(file.name) || file.size > 10 * 1024**2) { toast('请拖入 10 MB 以内的 SRT 文件', 'error'); return; }
    importSrt(file);
  });
  subtitleZone.addEventListener('click', event => {
    if (event.target.closest('button,.help-dot') || state.settings.mode !== 'align') return;
    importSrt();
  });

  const swallow = (event) => {
    const insideZone = !!event.target.closest?.(".dropzone, #subtitleSource");
    event.preventDefault();
    if (event.type === "drop" && !insideZone) toast("请把文件拖到左侧的素材框内", "error");
  };
  window.addEventListener("dragover", swallow);
  window.addEventListener("drop", swallow);
}

async function clearMedia() {
  if (state.batch || state.jobId || state.submitting || state.operation || state.loading) return;
  if (!state.media && !state.uploading) return;
  if (projectPath() && !(await saveProject(false))) { toast('保存失败，已保留当前素材', 'error'); return; }
  state.uploadEpoch++; state.mediaEpoch++; state.asrEpoch++;
  const xhr = state.uploadXhr; state.uploadXhr = null;
  if (xhr) { try { xhr.abort(); } catch {} }
  clearTimeout(state.saveTimer); abortScriptUpload();
  state.uploading = false; state.uploadName = ''; state.uploadPercent = 0;
  state.media = null; state.scriptDocument = null; state.referenceGaps = []; state.srtPath = ''; state.subtitleFile = null; state.cues = []; state.script = []; state.scriptName = '';
  state.waveSpan = 0; state.waveStart = 0; state.auditionEnd = null; clearInterval(state.auditionTimer);
  state.detailWave = null; state.detailWaveEpoch++; clearTimeout(state.detailWaveTimer);
  state.selected = -1; state.history = []; state.redoStack = []; state.editBefore = null;
  state.dirty = false; state.editRevision++; state.waveform = null; state.pendingResult = null;
  video.pause(); video.removeAttribute('src'); video.load(); overlay.textContent = '';
  $('#videoEmpty').hidden = false; setSaveState('');
  progressBar.style.width = '0%'; jobMsg.textContent = '等待任务';
  renderAll(); updateButtons();
  toast('已移除素材，已存工程仍保留');
}

async function loadMedia(path, options = {}) {
  if (state.jobId || state.submitting || state.operation || (state.batch && !options.batch)) return false;
  const epoch = ++state.mediaEpoch;
  state.loading = true; updateButtons();
  const staged = !state.media && state.srtPath && !options.batch
    ? { cues: state.cues, subtitleFile: state.subtitleFile, script: state.script, scriptName: state.scriptName, scriptDocument: state.scriptDocument } : null;
  try {
    if (projectPath() && !(await saveProject(false))) throw new Error('当前工程保存失败，已保留当前素材');
    if (epoch !== state.mediaEpoch) return false;
    const [infoResult, projectResult] = await Promise.all([
      api('/api/media/info?path=' + encodeURIComponent(path)),
      api('/api/projects/load?path=' + encodeURIComponent(path)),
    ]);
    if (epoch !== state.mediaEpoch) return false;
    const info = infoResult.info;
    if (!info || info.error) throw new Error(info?.error || '媒体信息不可用');
    const project = projectResult.project;
    abortScriptUpload();
    state.media = { ...info, uploaded: !!options.uploaded }; state.srtPath = '';
    state.subtitleFile = typeof project?.subtitle_file?.path === 'string' && project.subtitle_file.path ? project.subtitle_file : null;
    state.cues = (project?.cues || []).map(normalizeCue);
    state.script = project?.script_lines || []; state.scriptName = project?.script_name || ''; state.scriptPath = '';
    state.scriptDocument = project?.script_document || null; state.referenceGaps = [];
    if (!project && staged) {
      state.cues = staged.cues; state.subtitleFile = staged.subtitleFile;
      state.script = staged.script; state.scriptName = staged.scriptName;
      state.scriptDocument = staged.scriptDocument;
    }
    projectVersions.set(info.path, project?.revision || 0);
    state.history = []; state.redoStack = []; state.editBefore = null; state.selected = -1;
    state.pendingResult = null; state.waveform = null; state.videoErrorShown = false;
    state.waveSpan = 0; state.waveStart = 0; state.auditionEnd = null; clearInterval(state.auditionTimer);
    state.detailWave = null; state.detailWaveEpoch++; clearTimeout(state.detailWaveTimer);
    state.dirty = false; state.editRevision++;
    if (project?.settings) applyProjectSettings(project.settings);
    if (options.settings) applyProjectSettings(options.settings);
    video.src = '/api/media/stream?path=' + encodeURIComponent(info.path) + '&token=' + encodeURIComponent(SESSION_TOKEN);
    applyPreviewShape(); $('#videoEmpty').hidden = true;
    progressBar.style.width = '0%'; progressBar.style.background = 'var(--accent)'; jobMsg.textContent = '等待任务';
    setSaveState(project ? '已恢复工程' : '');
    renderAll(); loadWaveform();
    if (!project && staged) scheduleSave();
    if (project && state.cues.length && !options.batch) toast('已恢复上次编辑：' + state.cues.length + ' 条', 'success');
    return true;
  } catch (error) {
    if (epoch === state.mediaEpoch) toast(error.message, 'error');
    return false;
  } finally {
    if (epoch === state.mediaEpoch) { state.loading = false; updateButtons(); }
  }
}

function applyPreviewShape() {
  const wrap = $("#videoWrap");
  if (!wrap) return;
  const w = state.media?.width || video.videoWidth || 0;
  const h = state.media?.height || video.videoHeight || 0;
  if (!w || !h) {
    wrap.classList.remove("portrait");
    return;
  }
  wrap.classList.toggle("portrait", h > w);
  wrap.style.setProperty("--video-ratio", `${w} / ${h}`);
}

function renderMediaMeta() {
  const zone = $("#mediaZone");
  const nameEl = $("#mediaMeta");
  const infoEl = $("#mediaInfo");
  const clear = $("#mediaClear");
  if (state.uploading) {
    zone.classList.add("filled");
    clear.hidden = false;
    nameEl.textContent = `正在导入 ${state.uploadPercent}%`;
    nameEl.title = "";
    infoEl.textContent = state.uploadName;
    return;
  }
  const m = state.media;
  if (!m) {
    zone.classList.remove("filled");
    clear.hidden = true;
    nameEl.textContent = "拖入或点击选择";
    nameEl.title = "";
    infoEl.textContent = "";
    return;
  }
  zone.classList.add("filled");
  clear.hidden = false;
  nameEl.textContent = m.name;
  nameEl.title = m.path;
  const bits = [];
  bits.push(m.duration ? fmtTime(m.duration) : "未知时长");
  if (m.width && m.height) bits.push(`${m.width}×${m.height}`);
  if (m.size) bits.push(`${(m.size / 1048576).toFixed(1)} MB`);
  if (m.uploaded) bits.push("拖入副本");
  infoEl.textContent = bits.join(" · ");
}

async function loadWaveform() {
  const path = state.media?.path, epoch = state.mediaEpoch;
  state.waveform = null; drawWave();
  if (!path) return;
  try {
    const result = await api('/api/waveform?path=' + encodeURIComponent(path) + '&buckets=1200', null, null, { timeout: 120000 });
    if (state.media?.path !== path || state.mediaEpoch !== epoch) return;
    state.waveform = result;
    if (result.error) toast('波形不可用：' + result.error, 'error');
    drawWave();
  } catch (error) {
    if (state.media?.path === path && state.mediaEpoch === epoch) toast('波形加载失败：' + error.message, 'error');
  }
}

function normalizeCue(c, i) {
  return {
    ...c,
    original_text: c.original_text ?? String(c.text ?? ''),
    original_start: c.original_start ?? c.start,
    original_end: c.original_end ?? c.end,
    asr_original: c.asr_original || {text: String(c.text ?? ''), start:c.start, end:c.end, id:c.id ?? i + 1},
    id: c.id ?? i + 1,
    start: Number(c.start) || 0,
    end: Math.max(Number(c.end) || 0, (Number(c.start) || 0) + 0.05),
    text: String(c.text ?? "").trim(),
    role: c.role || "",
    script_text: c.script_text || "",
    script_index: c.script_index ?? null,
    match_ratio: c.match_ratio ?? null,
    confidence: c.confidence ?? null,
    avg_logprob: c.avg_logprob,
    no_speech_prob: c.no_speech_prob,
    is_noise: !!c.is_noise,
    needs_review: !!c.needs_review,
    match_needs_review: !!c.match_needs_review,
    edited: !!c.edited,
    estimated: !!c.estimated,
    source: c.source || "",
    words: Array.isArray(c.words) ? c.words : [],
  };
}

function snapshot() { return JSON.stringify({ cues: state.cues, subtitleFile: state.subtitleFile }); }

function restoreSnapshot(value) {
  const saved = JSON.parse(value);
  state.cues = saved.cues;
  state.subtitleFile = saved.subtitleFile;
}

function pushHistory(before) {
  if (!before || before === snapshot()) return;
  state.history.push(before);
  if (state.history.length > HISTORY_LIMIT) state.history.shift();
  state.redoStack = [];
  updateButtons();
}

function undo() {
  if (editLocked()) return;
  if (!state.history.length) return;
  state.redoStack.push(snapshot());
  restoreSnapshot(state.history.pop());
  state.selected = -1;
  renderAll();
  scheduleSave();
}

function redo() {
  if (editLocked()) return;
  if (!state.redoStack.length) return;
  state.history.push(snapshot());
  restoreSnapshot(state.redoStack.pop());
  state.selected = -1;
  renderAll();
  scheduleSave();
}

function filteredRows() {
  const q = state.search.trim().toLowerCase();
  return state.cues
    .map((cue, i) => ({ cue, i }))
    .filter(({ cue }) => {
      if (state.filter === "low" && !(cue.needs_review || cue.match_needs_review || (cue.confidence != null && cue.confidence < 0.6))) return false;
      if (state.filter === "noise" && !cue.is_noise) return false;
      if (state.filter === "edited" && !cue.edited) return false;
      if (q) {
        const hay = `${cue.text || ""} ${cue.script_text || ""} ${cue.role || ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
}

function suggestHtml(cue, i) {
  if (!cue.script_text) return '<span class="muted">—</span>';
  const ratio = cue.match_ratio != null ? Math.round(cue.match_ratio * 100) : 0;
  const cls = ratio >= 75 ? "high" : ratio < 55 ? "low" : "";
  return `<div class="sugg-text" title="${escapeHtml(cue.script_text)}">${escapeHtml(cue.script_text)}</div>
    <div class="sugg-row"><span class="ratio ${cls}">${ratio}%</span>
    ${cue.role ? `<span class="muted">${escapeHtml(cue.role)}</span>` : ""}
    <button class="mini" data-act="apply" data-i="${i}">采用</button></div>`;
}

function badgesHtml(cue) {
  const out = [];
  if (cue.role) out.push(`<span class="badge">${escapeHtml(cue.role)}</span>`);
  if (cue.confidence != null) {
    const pct = Math.round(cue.confidence * 100);
    out.push(`<span class="badge ${pct < 45 ? "low" : ""}">置信 ${pct}%</span>`);
  }
  if (cue.is_noise) out.push('<span class="badge noise">噪音</span>');
    if (cue.needs_review || cue.match_needs_review) out.push('<span class="badge low">待校对</span>');
  if (cue.edited) out.push('<span class="badge edited">已改</span>');
  if (cue.source === "split" || cue.source === "gap_split") out.push('<span class="badge split">已分段</span>');
  if (cue.estimated) out.push('<span class="badge low">时间估算</span>');
  return out.join("") || '<span class="badge">—</span>';
}

function renderTable() {
  const rows = filteredRows();
  cueBody.innerHTML = rows.map(({ cue, i }) => {
    const textClass = `${cue.needs_review || (cue.confidence != null && cue.confidence < 0.45) ? "low" : ""} ${cue.is_noise ? "noise" : ""}`;
    return `<tr data-i="${i}" class="${i === state.selected ? "selected" : ""}">
      <td class="idx">${i + 1}</td>
      <td><input class="time" data-field="start" value="${fmtTime(cue.start, true)}"></td>
      <td><input class="time" data-field="end" value="${fmtTime(cue.end, true)}"></td>
      <td><div class="cue-text ${textClass}" contenteditable="true" spellcheck="false">${escapeHtml(cue.text)}</div></td>
      <td class="suggest">${suggestHtml(cue, i)}</td>
      <td class="badges">${badgesHtml(cue)}</td>
    </tr>`;
  }).join("");
  emptyHint.style.display = state.cues.length ? "none" : "";
  emptyHint.textContent = state.cues.length ? "" : "选择视频 → 开始识别，或导入 SRT";
  $("#cueCount").textContent = `${state.cues.length} 条${rows.length !== state.cues.length ? `（显示 ${rows.length}）` : ""}`;
  updateWidthInfo();
  if (state.selected >= 0 && state.cues[state.selected]) {
    const c = state.cues[state.selected];
    $("#selInfo").textContent = `第 ${state.selected + 1} 条 · ${fmtTime(c.start)} → ${fmtTime(c.end)}`;
  } else {
    $("#selInfo").textContent = "";
  }
  updateButtons();
  drawWave();
}

function renderSubtitleSource(animate = false) {
  const file = state.subtitleFile;
  const source = $('#subtitleSource');
  const name = $('#subtitleFileName');
  const note = $('#subtitleFileNote');
  const ready = state.cues.length > 0;
  source.classList.toggle('filled', ready);
  name.textContent = file?.path ? file.path.split(/[\\/]/).pop()
    : ready ? '当前工程字幕' : state.settings.mode === 'align' ? '请选择用于对齐的 SRT' : '尚未生成字幕';
  name.title = file?.path || '';
  note.hidden = !ready;
  note.textContent = ready ? `${file?.origin === 'generated' ? '提取生成' : file?.origin === 'imported' ? '手动导入' : '工程恢复'} · ${state.cues.length} 条${state.settings.mode === 'align' ? ' · 已载入对齐字幕' : ''}` : '';
  $('#subtitleFileHelp').dataset.tip = state.settings.mode === 'align'
    ? '直接对齐需自行导入 SRT；提取后切换会自动带入当前字幕，并保留校对结果。可用“更换 SRT”选择其他字幕文件。'
    : '提取完成后自动生成 SRT，切换字幕对齐可直接使用。也可导入已有 SRT，继续校对和导出。';
  $('#btnSourceSrt').textContent = state.settings.mode === 'align' ? '导入 SRT' : '导出 SRT';
  if (animate) {
    source.classList.remove('file-arrived');
    void source.offsetWidth;
    source.classList.add('file-arrived');
  }
}

function renderAll() {
  renderMediaMeta();
  renderSubtitleSource();
  updateModeNote();
  renderTable();
  renderScript();
  updateButtons();
}

// ---------- 选择/编辑 ----------
function selectCue(i, seek = true) {
  if (i < 0 || i >= state.cues.length) return;
  state.selected = i;
  $$("#cueBody tr.selected").forEach((el) => el.classList.remove("selected"));
  const row = document.querySelector(`#cueBody tr[data-i="${i}"]`);
  if (row) {
    row.classList.add("selected");
    row.scrollIntoView({ block: "nearest" });
  }
  const cue = state.cues[i];
  if (seek && state.media && Number.isFinite(cue.start)) {
    video.currentTime = Math.max(0, cue.start + 0.02);
  }
  $("#selInfo").textContent = `第 ${i + 1} 条 · ${fmtTime(cue.start)} → ${fmtTime(cue.end)} · ${cue.text.length} 字`;
  updateOverlay();
  renderAlignmentInspector(); drawWave();
  $$("#scriptList .script-line").forEach(row => row.classList.toggle("selected", Number(row.dataset.i) === i));
}

function updateOverlay() {
  const t = video.currentTime || 0;
  const cue = findCueAt(t);
  overlay.textContent = cue ? subtitleText(cue.text) : "";
  $$("#cueBody tr.playing").forEach((el) => el.classList.remove("playing"));
  if (cue) {
    const idx = state.cues.indexOf(cue);
    const row = document.querySelector(`#cueBody tr[data-i="${idx}"]`);
    if (row) row.classList.add("playing");
  }
}

function findCueAt(t) {
  return state.cues.find(c => t >= c.start && t <= c.end) || null;
}

function applyScript(i) {
  if (editLocked()) return;
  const cue = state.cues[i], match = cue?.reference_match;
  if (!cue?.script_text || !match?.reference || match.reference.reference_only) return;
  if (match.stale) { toast('字幕已修改，请先重新匹配', 'error'); return; }
  if (match.status === 'ambiguous' && !match.candidate_confirmed) { toast('存在多候选，请先确认参考位置', 'error'); return; }
  const before = snapshot();
  cue.text = cue.script_text;
  cue.words = []; cue.edited = true; cue.review_decision = 'adopted'; cue.match_needs_review = false;
  // 原 ASR、原时间和完整参考记录均保留。
  pushHistory(before); renderAll(); scheduleSave(); updateOverlay();
}

function markReview(i, decision) {
  if (editLocked() || !state.cues[i]) return;
  const before = snapshot(), cue = state.cues[i];
  cue.review_decision = decision;
  if (decision === 'kept') { cue.text = cue.original_text; cue.edited = cue.text !== cue.original_text; cue.words = []; }
  pushHistory(before); renderAll(); scheduleSave(); updateOverlay();
}

function highlighted(text, differences, side) {
  const chars = [...String(text || '')];
  const ranges = (differences || []).filter(d => d[side + '_end'] > d[side + '_start']);
  return chars.map((c, i) => ranges.some(d => i >= d[side + '_start'] && i < d[side + '_end'])
    ? '<mark class="diff-' + side + '">' + escapeHtml(c) + '</mark>' : escapeHtml(c)).join('');
}

function renderScript() {
  const zone = $('#scriptZone'), nameEl = $('#scriptStats'), infoEl = $('#scriptInfo');
  const references = new Map();
  state.cues.forEach((cue, index) => { if (cue.script_index != null && cue.script_text && !references.has(cue.script_index)) references.set(cue.script_index, index); });
  state.script.forEach(line => { line.cue_index = references.get(line.index) ?? null; });
  const matched = state.cues.filter(c => c.reference_match?.reference).length;
  zone.classList.toggle('filled', !!state.script.length || state.scriptUploading);
  nameEl.textContent = state.scriptUploading ? '正在读取…' : state.scriptName || '拖入或点击选择';
  nameEl.title = state.scriptName || '';
  infoEl.textContent = state.scriptUploading ? state.scriptUploadName : state.script.length ? state.script.length + ' 段 · 全文参考' : '';
  $('#alignmentSummary').textContent = state.script.length ? matched + '/' + state.cues.length + ' 条找到参考 · 结果需人工复核' : '导入任意格式 TXT 剧本后校验';
  const decisions = {adopted:'已采用参考', kept:'保留原文', manual:'人工修改', non_script:'非剧本内容', skipped:'已跳过'};
  if (!state.cues.length) scriptList.innerHTML = '<div class="muted small">导入 SRT 或先识别字幕，校验结果将在这里逐条排列。</div>';
  else scriptList.innerHTML = state.cues.map((cue, i) => {
    const m = cue.reference_match, ref = m?.reference, diff = m?.differences || [];
    const hasMatch = !!ref, reviewed = decisions[cue.review_decision];
    const pct = n => (Number(n || 0) * 100).toFixed(1) + '%';
    const group = m?.group && m.group.cue_end - m.group.cue_start > 1 ? ' · 关联 #' + (m.group.cue_start + 1) + '–' + m.group.cue_end : '';
    const differenceText = diff.map(d => d.operation === 'insert' ? '疑似缺少「' + d.script + '」' : d.operation === 'delete' ? '疑似多出「' + d.asr + '」' : '「' + d.asr + '」↔「' + d.script + '」').join('；');
    const alternativeList = m?.alternatives || [];
    const alternatives = alternativeList.length ? '<details class="match-alternatives"><summary>' + alternativeList.length + ' 个其他参考位置</summary>' + alternativeList.map((c,j) =>
      '<div class="match-candidate"><span>第' + c.paragraph_start + '段 · 字符' + (c.start + 1) + '–' + c.end + ' · ' + pct(c.score) + (c.reference_only ? ' · 疑似叙述' : '') + '</span><p>' + escapeHtml(c.text) + '</p>' +
      (m.status === 'ambiguous' && !c.group_only && !c.reference_only ? '<button type="button" class="mini" data-review="candidate" data-candidate="' + j + '">选择此位置</button>' : '') + '</div>').join('') + '</details>' : '';
    return '<article class="script-line ' + (hasMatch ? 'matched' : 'unmatched') + (i === state.selected ? ' selected' : '') + '" data-i="' + i + '" tabindex="0" aria-label="第' + (i + 1) + '条字幕校验">' +
      '<div class="alignment-head"><b>#' + (i + 1) + '</b><span class="review-status status-' + escapeHtml(m?.status || 'pending') + '">' + escapeHtml(reviewed || (m?.stale ? '已修改 · 待重匹配' : m?.label || '待匹配')) + '</span></div>' +
      '<span class="alignment-time">' + fmtTime(cue.original_start ?? cue.start) + ' → ' + fmtTime(cue.original_end ?? cue.end) + group + '</span>' +
      '<div class="reference-columns"><div><small>ASR / 导入原文</small><p>' + escapeHtml(cue.original_text ?? cue.text) + '</p><small>当前字幕</small><p>' + highlighted(cue.text, diff, 'asr') + '</p></div>' +
      '<div><small>剧本参考</small><p>' + (ref ? highlighted(ref.text, diff, 'script') : '尚无可靠参考') + '</p>' + (ref ? '<small>第' + ref.paragraph_start + (ref.paragraph_end !== ref.paragraph_start ? '–' + ref.paragraph_end : '') + '段 · 字符' + (ref.start + 1) + '–' + ref.end + '</small>' : '') + '</div></div>' +
      (m ? '<div class="match-metrics"><span>字符 ' + pct(m.character_score) + '</span><span>拼音 ' + pct(m.pinyin_score) + '</span><span>综合 ' + pct(m.score) + '</span></div>' : '') +
      (differenceText ? '<p class="match-difference">' + escapeHtml(differenceText) + '</p>' : '') +
      (m?.warning ? '<p class="match-warning">' + escapeHtml(m.warning) + '</p>' : '') + alternatives +
      (m?.status === 'ambiguous' ? '<button type="button" class="mini" data-review="confirm">确认当前参考位置</button>' : '') +
      '<div class="review-actions"><button type="button" data-review="adopt" ' + (!ref || ref.reference_only || m?.stale || (m?.status === 'ambiguous' && !m.candidate_confirmed) ? 'disabled' : '') + '>采用参考</button><button type="button" data-review="kept">保留原文</button><button type="button" data-review="edit">人工修改</button><button type="button" data-review="non_script">非剧本</button><button type="button" data-review="skipped">跳过</button><button type="button" data-review="rematch">重新匹配</button></div></article>';
  }).join('');
  const gaps = state.referenceGaps || [];
  if (gaps.length) scriptList.innerHTML += '<details class="reference-gaps"><summary>' + gaps.length + ' 处未覆盖参考片段</summary>' + gaps.map(g => '<p>字幕 #' + (g.after_cue + 1) + ' 与 #' + (g.before_cue + 1) + ' 之间：' + escapeHtml(g.text) + '</p>').join('') + '<small>可能是叙述或实际台词差异，不自动补入字幕。</small></details>';
  updateModeUI(); updateModeNote(); renderAlignmentInspector(); updateButtons();
}

function renderAlignmentInspector() {
  const cue = state.cues[state.selected];
  $('#alignmentInspector').hidden = state.settings.mode !== 'align';
  $('#alignmentSelection').textContent = cue ? '#' + (state.selected + 1) + ' · ' + (cue.end - cue.start).toFixed(2) + ' 秒 · 拖边缘校时' : '选择一条字幕查看声波';
  for (const [id, key] of [['alignStart', 'start'], ['alignEnd', 'end']]) {
    const input = $('#' + id);
    if (document.activeElement !== input) input.value = cue ? fmtTime(cue[key], true) : '';
    input.disabled = !cue || editLocked();
  }
  $('#btnAudition').disabled = !cue || !state.media;
  $('#btnAlignApply').disabled = !cue?.reference_match?.reference || cue.reference_match.stale || (cue.reference_match.status === 'ambiguous' && !cue.reference_match.candidate_confirmed) || editLocked();
}

function waveWindow() {
  const duration = state.media?.duration || state.waveform?.duration || 0;
  const span = duration ? Math.min(duration, state.waveSpan || duration) : 1;
  const start = Math.max(0, Math.min(state.waveStart || 0, Math.max(0, duration - span)));
  return { duration, start, span };
}

function focusWave(cue) {
  const duration = waveWindow().duration;
  if (!duration || !cue) return;
  state.waveSpan = Math.min(duration, Math.max(4, (cue.end - cue.start) * 3));
  state.waveStart = Math.max(0, cue.start - (state.waveSpan - (cue.end - cue.start)) / 2);
  drawWave(); requestWaveDetail();
}

function requestWaveDetail() {
  clearTimeout(state.detailWaveTimer);
  const view = waveWindow(), path = state.media?.path, epoch = ++state.detailWaveEpoch, mediaEpoch = state.mediaEpoch;
  state.detailWave = null;
  if (!path || !view.duration || view.span > 120 || view.span >= view.duration) return;
  state.detailWaveTimer = setTimeout(async () => {
    try {
      const result = await api('/api/waveform?path=' + encodeURIComponent(path) + '&buckets=1200&start=' + view.start + '&end=' + (view.start + view.span));
      if (epoch !== state.detailWaveEpoch || mediaEpoch !== state.mediaEpoch || state.media?.path !== path) return;
      state.detailWave = result; drawWave();
    } catch { /* 时间戳不完整的媒体保留全片波形，仍可试听校对。 */ }
  }, 120);
}

function bindWaveCanvas(canvas) {
  let drag = null;
  const timeAt = event => { const rect = canvas.getBoundingClientRect(), view = waveWindow(); return clamp(view.start + (event.clientX - rect.left) / rect.width * view.span, 0, view.duration); };
  canvas.addEventListener('pointerdown', event => {
    const view = waveWindow(), cue = state.cues[state.selected];
    if (!view.duration) return;
    const rect = canvas.getBoundingClientRect(), x = event.clientX - rect.left;
    const x1 = cue ? (cue.start - view.start) / view.span * rect.width : -100;
    const x2 = cue ? (cue.end - view.start) / view.span * rect.width : -100;
    const edge = Math.abs(x - x1) <= 9 ? 'start' : Math.abs(x - x2) <= 9 ? 'end' : null;
    if (cue && edge && state.settings.mode === 'align' && !editLocked()) {
      drag = { cue, edge, before: snapshot(), epoch: state.mediaEpoch };
      state.operation = '校时'; updateButtons(); canvas.setPointerCapture(event.pointerId);
    } else { state.auditionEnd = null; video.currentTime = timeAt(event); updateOverlay(); drawWave(); }
  });
  canvas.addEventListener('pointermove', event => {
    if (!drag || drag.epoch !== state.mediaEpoch) return;
    const time = Math.round(timeAt(event) * 1000) / 1000;
    const duration = waveWindow().duration;
    if (drag.edge === 'start') {
      const latestStart = Math.min(drag.cue.end, duration) - .001;
      if (latestStart < 0) return;
      drag.cue.start = clamp(time, 0, latestStart);
    } else {
      const earliestEnd = drag.cue.start + .001;
      if (earliestEnd > duration) return;
      drag.cue.end = clamp(time, earliestEnd, duration);
    }
    drag.cue.edited = true; drag.cue.words = [];
    video.currentTime = drag.cue[drag.edge]; renderAlignmentInspector(); drawWave();
  });
  const finish = event => {
    if (!drag) return;
    const saved = drag; drag = null; state.operation = '';
    if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    if (saved.epoch === state.mediaEpoch) { pushHistory(saved.before); renderAll(); scheduleSave(); }
    updateButtons();
  };
  canvas.addEventListener('pointerup', finish); canvas.addEventListener('pointercancel', finish);
  canvas.addEventListener('lostpointercapture', finish);
  canvas.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight'].includes(event.key) || !state.media) return;
    event.preventDefault(); state.auditionEnd = null;
    video.currentTime = clamp(video.currentTime + (event.key === 'ArrowRight' ? 1 : -1) * (event.shiftKey ? 1 : .1), 0, waveWindow().duration);
    updateOverlay(); drawWave();
  });
}

async function matchScript(silent = false, forceIndices = []) {
  if (state.settings.mode !== 'align' || (editLocked() && !silent)) return false;
  if (!state.cues.length || !state.script.length) {
    if (!silent) toast('需要已有字幕和剧本才能匹配', 'error');
    return false;
  }
  const before = snapshot(), path = projectPath(), epoch = state.mediaEpoch;
  const scriptFingerprint = JSON.stringify(state.scriptDocument || state.script);
  const previousOperation = state.operation;
  state.operation = '匹配剧本'; updateButtons();
  try {
    const doc = state.scriptDocument;
    const validDoc = doc?.text && doc.paragraphs?.length === state.script.length && doc.paragraphs.every((p, i) => p.text === state.script[i].text);
    const d = await api('/api/script/match', { cues: state.cues, lines: state.script,
      document: {text: validDoc ? doc.text : state.script.map(line => line.text).join('\n')},
      options: {minimum: state.settings.matchMinimum, high:state.settings.matchHigh, phonetic:state.settings.matchPhonetic,
        ambiguity:state.settings.matchAmbiguity, max_group:state.settings.matchGroup}, force_indices:forceIndices }, null, {timeout:180000});
    if (!sameDocument(path, epoch, before) || scriptFingerprint !== JSON.stringify(state.scriptDocument || state.script)) throw new Error('字幕或剧本已变化，已保留当前修改，请重新匹配');
    state.script = d.lines;
    state.scriptDocument = d.document; state.referenceGaps = d.gaps || [];
    replaceCues(d.cues, { before });
    const first = d.lines.find(line => line.cue_index != null);
    if (first) { selectCue(first.cue_index); focusWave(state.cues[first.cue_index]); }
    if (!silent) toast('已校验 ' + (d.stats?.total || 0) + ' 条 · ' + (d.stats?.needs_review || 0) + ' 条需复核，未改写字幕', 'success');
    return true;
  } catch (e) { toast(e.message, 'error'); return false; }
  finally { state.operation = previousOperation; updateButtons(); }
}

async function startAsr(autoExport = false, task = 'asr') {
  if (state.jobId || state.submitting || state.operation || state.loading || state.uploading) return null;
  if (!state.media || (task === 'asr' && !modelAvailable())) { toast('请先选择素材和可用模型', 'error'); return null; }
  const s = { ...collectSettings() };
  document.activeElement?.blur();
  const path = projectPath(), mediaEpoch = state.mediaEpoch, before = snapshot();
  const epoch = ++state.asrEpoch;
  const id = crypto.randomUUID().replaceAll('-', '');
  state.jobId = id; state.submitting = true; state.pendingResult = null;
  updateButtons();
  let job = { id, status: 'queued' }, failures = 0;
  try {
    try {
      job = (await api(task === 'align' ? '/api/alignment/jobs' : '/api/jobs', { path, model: s.model, device: s.device,
        cues: task === 'align' ? state.cues : undefined, vad: s.vad, gap_seconds: s.gap, request_id: id })).job;
    } catch (error) {
      if (error.status) throw error;
      toast('提交响应中断，正在按原任务标识查询；请勿重复提交', 'info');
    }
    state.submitting = false;
    while (epoch === state.asrEpoch) {
      try {
        job = (await api('/api/jobs/' + id)).job;
        failures = 0; $('#btnReconnect').hidden = true;
        updateJob(job);
        if (['done', 'error', 'cancelled'].includes(job.status)) break;
      } catch (error) {
        if ([403, 404].includes(error.status)) throw error;
        failures++;
        jobMsg.textContent = '连接中断，保留任务并等待重连（' + failures + '）';
        $('#btnReconnect').hidden = false;
        if (failures === 1) toast('任务仍在后台，正在重试查询', 'info');
      }
      await new Promise(resolve => {
        const timer = setTimeout(() => { state.retryPoll = null; resolve(); }, failures ? Math.min(5000, 600 * 2 ** Math.min(failures, 4)) : 600);
        state.retryPoll = () => { clearTimeout(timer); state.retryPoll = null; resolve(); };
      });
    }
    if (epoch !== state.asrEpoch) return null;
    if (job.status === 'done') {
      while (epoch === state.asrEpoch) {
        try { job = (await api('/api/jobs/' + id + '?result=1')).job; break; }
        catch (error) {
          if ([403, 404].includes(error.status)) throw error;
          jobMsg.textContent = '识别已完成，正在重试获取结果';
          $('#btnReconnect').hidden = false;
          await sleep(1000);
        }
      }
      if (epoch !== state.asrEpoch) return null;
      if (!sameDocument(path, mediaEpoch, before)) {
        state.pendingResult = { job, path };
        throw new Error('字幕已变化，已保留当前修改；可点击“采用识别结果”另行采用');
      }
      replaceCues(job.cues || [], { before,
        subtitleFile: task === 'align' ? state.subtitleFile : job.subtitle_path ? { path: job.subtitle_path, origin: 'generated' } : null });
      renderSubtitleSource(true);
      if (task === 'asr' && s.mode === 'align' && state.script.length) await matchScript(true);
      if (!(await saveProject(false))) throw new Error('识别已完成，工程保存失败，请先保存或导出');
      if (autoExport) {
        const output = await exportSrt(true);
        if (!output) return { ...job, status: 'export_error', error: '识别完成，导出失败；可重试导出', path };
        job.outputPath = output.path;
      }
      playSound('success');
      toast((task === 'align' ? '时间轴对齐完成：' : '提取成功：') + state.cues.length + ' 条字幕', 'success');
    } else if (job.status === 'cancelled') toast('已取消');
    else if (job.error) toast(job.error, 'error');
    return job;
  } catch (error) {
    toast(error.message, 'error', 8000);
    return { ...job, status: 'error', error: error.message };
  } finally {
    if (state.jobId === id) state.jobId = null;
    state.submitting = false; state.retryPoll = null;
    $('#btnReconnect').hidden = true;
    updateButtons();
  }
}

async function alignAndVerify() {
  if (editLocked()) return;
  if (!state.media || !state.cues.length || !state.script.length) { toast('请先导入媒体、SRT 和剧本', 'error'); return; }
  const job = await startAsr(false, 'align');
  if (job?.status === 'done') await matchScript();
}

function updateJob(job) {
  progressBar.parentElement.classList.remove('indeterminate');
  const pct = Math.round((job.progress || 0) * 100);
  progressBar.style.width = `${pct}%`;
  jobMsg.textContent = job.message || job.status;
  if (job.status === "error") progressBar.style.background = "var(--red)";
  else if (job.status === "done") progressBar.style.background = "var(--green)";
  else progressBar.style.background = "var(--accent)";
  updateButtons();
}

async function cancelAsr() {
  if (!state.jobId) return;
  try {
    await api(`/api/jobs/${state.jobId}/cancel`, {});
    toast("已请求取消");
  } catch (e) { toast(e.message, "error"); }
}

// ---------- 分段/编辑操作 ----------
async function doSegment() {
  if (editLocked() || !state.cues.length) return;
  const s = collectSettings(), before = snapshot(), path = projectPath(), epoch = state.mediaEpoch;
  state.operation = '分段'; updateButtons();
  try {
    const d = await api('/api/segment', { cues: state.cues, max_width: s.width, gap_seconds: s.gap });
    if (!sameDocument(path, epoch, before)) throw new Error('字幕已变化，已保留修改，请重新分段');
    replaceCues(d.cues, { before });
    const skipped = d.cues.filter(c => c.gap_split_skipped || c.split_skipped).length;
    toast('分段完成：新增 ' + d.splits + ' 条，停顿 ' + (d.gap_splits || 0) + ' 处' + (skipped ? '；' + skipped + ' 条需人工检查' : ''), 'success');
  } catch (error) { toast(error.message, 'error'); }
  finally { state.operation = ''; updateButtons(); }
}

async function doMerge() {
  if (editLocked() || !state.cues.length) return;
  const s = collectSettings(), before = snapshot(), path = projectPath(), epoch = state.mediaEpoch;
  state.operation = '合并'; updateButtons();
  try {
    const d = await api('/api/segment/merge', { cues: state.cues, max_width: s.width, max_duration: 7, max_gap: 0.25 });
    if (!sameDocument(path, epoch, before)) throw new Error('字幕已变化，已保留修改，请重新合并');
    replaceCues(d.cues, { before });
    toast('合并了 ' + d.merged + ' 处短句', 'success');
  } catch (error) { toast(error.message, 'error'); }
  finally { state.operation = ''; updateButtons(); }
}

function addCue() {
  if (editLocked()) return;
  const before = snapshot();
  const idx = state.selected >= 0 ? state.selected + 1 : state.cues.length;
  const prev = state.cues[idx - 1];
  const start = prev ? prev.end + 0.1 : (video.currentTime || 0);
  state.cues.splice(idx, 0, normalizeCue({
    start, end: start + 2, text: "新字幕", edited: true, source: "manual",
  }, idx));
  pushHistory(before);
  state.selected = idx;
  renderAll();
  scheduleSave();
  const row = document.querySelector(`#cueBody tr[data-i="${idx}"] .cue-text`);
  if (row) {
    row.focus();
    const range = document.createRange();
    range.selectNodeContents(row);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }
}

function deleteCue() {
  if (editLocked()) return;
  if (state.selected < 0 || !state.cues[state.selected]) return;
  const before = snapshot();
  state.cues.splice(state.selected, 1);
  pushHistory(before);
  state.selected = Math.min(state.selected, state.cues.length - 1);
  renderAll();
  scheduleSave();
}

async function importSrt(file = null) {
  if (editLocked()) return;
  state.operation = '导入字幕'; updateButtons();
  const source = projectPath();
  const requestedMode = state.settings.mode;
  try {
    const picked = file instanceof File ? await uploadFile(file, 'srt', ratio => {
      progressBar.style.width = Math.round(ratio * 100) + '%'; jobMsg.textContent = '导入字幕 ' + Math.round(ratio * 100) + '%';
    }) : await api('/api/dialog', { kind: 'srt', multiple: false });
    if (!picked.path) return;
    if (source && !(await saveProject(false))) throw new Error('当前工程尚未保存，已取消导入');
    const parsed = await api('/api/srt/parse', { path: picked.path });
    if (!parsed.cues?.length) throw new Error('没有可导入的字幕');
    let cues = parsed.cues, restored = false;
    if (!state.media) {
      const loaded = await api('/api/projects/load?path=' + encodeURIComponent(picked.path));
      state.mediaEpoch++;
      state.srtPath = picked.path;
      state.script = loaded.project?.script_lines || [];
      state.scriptDocument = loaded.project?.script_document || null;
      state.scriptName = loaded.project?.script_name || '';
      projectVersions.set(picked.path, loaded.project?.revision || 0);
      if (loaded.project) {
        cues = loaded.project.cues || [];
        if (loaded.project.settings) applyProjectSettings(loaded.project.settings);
        restored = true;
      }
    }
    if (requestedMode === 'align') setMode('align', false);
    replaceCues(cues, { reset: !state.media, subtitleFile: { path: picked.path, origin: 'imported' } });
    renderSubtitleSource(true);
    if (!(await saveProject(false))) throw new Error('字幕已导入，但工程尚未保存，请重试');
    toast((restored ? '已恢复SRT工程：' : '已导入：') + cues.length + ' 条' + (parsed.warnings?.length ? '，有格式提醒' : ''), 'success');
  } catch (error) { toast(error.message, 'error'); }
  finally { state.operation = ''; updateButtons(); }
}

async function exportSrt(silent = false) {
  if (editLocked() && !silent) return null;
  if (!state.cues.length) { toast("没有可导出的字幕", "error"); return null; }
  const s = collectSettings();
  const cues = state.cues
    .filter((c) => !s.excludeNoise || !c.is_noise)
    .map((c) => ({ start: c.start, end: c.end, text: subtitleText(c.text), role: c.role || "" }));
  try {
    const d = await api("/api/srt/export", {
      media_path: state.media ? state.media.path : "",
      cues,
      options: { keep_punctuation: s.keepPunc, skip_empty: s.skipEmpty,
        single_line: s.singleLine, output_dir: null },
    });
    if (!silent) { toast(`已导出 ${d.count} 条 → ${d.path}`, "success", 7000); playSound("success"); }
    return d;
  } catch (e) {
    if (e.errors && e.errors.length) {
      toast(`导出检查未通过：${e.errors.slice(0, 3).join("；")}`, "error", 8000);
    } else {
      toast(e.message, "error");
    }
    return null;
  }
}

// ---------- 队列 ----------
function drawWave() {
  const view = waveWindow();
  const css = getComputedStyle(themeRoot);
  const color = (name, fallback) => css.getPropertyValue(name).trim() || fallback;
  const now = video.currentTime || 0;
  $('#waveReadout').textContent = fmtTime(now) + ' / ' + fmtTime(view.duration);
  for (const canvas of [waveCanvas, $('#alignWave')]) {
    if (!canvas || !canvas.clientWidth) continue;
    const dpr = window.devicePixelRatio || 1, w = canvas.clientWidth, h = canvas.clientHeight || 96;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    const ctx = canvas.getContext('2d'); if (!ctx) continue;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = color('--panel-2', '#232327'); ctx.fillRect(0, 0, w, h);
    const xAt = time => (time - view.start) / view.span * w;
    const step = [0.1, .2, .5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 1800, 3600].find(value => value >= view.span / Math.max(2, w / 75)) || 7200;
    ctx.font = '10px ' + getComputedStyle(document.body).fontFamily; ctx.textBaseline = 'top';
    for (let t = Math.ceil(view.start / step) * step; t <= view.start + view.span + .00001; t += step) {
      const x = xAt(t); ctx.strokeStyle = color('--line', '#34343a'); ctx.beginPath(); ctx.moveTo(x, 20); ctx.lineTo(x, h); ctx.stroke();
      const tenths = Math.round(t * 10), seconds = Math.round(t);
      const label = step < 1 ? Math.floor(tenths / 600) + ':' + pad(Math.floor(tenths / 10) % 60) + '.' + tenths % 10
        : Math.floor(seconds / 60) + ':' + pad(seconds % 60);
      ctx.fillStyle = color('--muted', '#a6a6ad'); ctx.fillText(label, clamp(x + 3, 1, Math.max(1, w - ctx.measureText(label).width - 2)), 3);
    }
    const detail = state.detailWave;
    const useDetail = detail && detail.start <= view.start + .001 && detail.end >= view.start + view.span - .001;
    const wave = useDetail ? detail : state.waveform;
    const peaks = wave?.peaks || [], peakStart = useDetail ? detail.start : 0;
    const peakSpan = useDetail ? detail.end - detail.start : view.duration;
    const top = 24, waveformHeight = h - 40;
    ctx.fillStyle = color('--muted-2', '#7e7e87');
    if (peaks.length && view.duration) {
      for (let x = 0; x < w; x++) {
        const a = Math.max(0, Math.floor((view.start + x / w * view.span - peakStart) / peakSpan * peaks.length));
        const b = Math.min(peaks.length, Math.max(a + 1, Math.ceil((view.start + (x + 1) / w * view.span - peakStart) / peakSpan * peaks.length)));
        let peak = 0; for (let i = a; i < b; i++) peak = Math.max(peak, peaks[i] || 0);
        const height = Math.max(1, peak * waveformHeight);
        ctx.fillRect(x, top + (waveformHeight - height) / 2, 1, height);
      }
    } else { ctx.globalAlpha = .4; ctx.fillRect(0, top + waveformHeight / 2, w, 1); ctx.globalAlpha = 1; }
    if (view.duration) {
      state.cues.forEach((cue, index) => {
        if (cue.end < view.start || cue.start > view.start + view.span || cue.is_noise) return;
        const x1 = clamp(xAt(cue.start), 0, w), x2 = clamp(xAt(cue.end), 0, w);
        ctx.fillStyle = color('--accent-2', '#66b3ff'); ctx.globalAlpha = index === state.selected ? .25 : .1;
        ctx.fillRect(x1, 22, Math.max(1, x2 - x1), h - 22); ctx.globalAlpha = 1;
        ctx.fillRect(x1, h - 8, Math.max(1, x2 - x1), 5);
        if (index === state.selected) { ctx.fillRect(xAt(cue.start) - 2, 22, 4, h - 22); ctx.fillRect(xAt(cue.end) - 2, 22, 4, h - 22); }
      });
      if (now >= view.start && now <= view.start + view.span) { ctx.fillStyle = color('--red', '#ff453a'); ctx.fillRect(xAt(now), 0, 1.5, h); }
    }
    canvas.setAttribute('aria-valuemax', String(view.duration)); canvas.setAttribute('aria-valuenow', now.toFixed(3));
  }
}

async function saveProject(silent = false, options = {}) {
  const source = projectPath();
  if (!source) {
    if (state.cues.length) { setSaveState('字幕未保存，请先导出SRT'); return false; }
    return true;
  }
  clearTimeout(state.saveTimer);
  const revision = state.editRevision;
  const payload = JSON.parse(JSON.stringify({ media_path: state.media?.path || '', source_path: source,
    cues: state.cues, script_lines: state.script, script_name: state.scriptName || '', script_document: state.scriptDocument,
    subtitle_file: state.subtitleFile, settings: collectSettings() }));
  state.pendingSaves++;
  if (!silent) setSaveState('保存中…');
  const task = projectSaveChain.then(async () => {
    try {
      payload.expected_revision = projectVersions.get(source) || 0;
      const result = await api('/api/projects/save', payload, null, options);
      projectVersions.set(source, result.revision);
      if (projectPath() === source && state.editRevision === revision) {
        state.dirty = false;
        if (!silent) setSaveState('已保存 ' + String(result.updated_at).slice(11));
      }
      return true;
    } catch (error) {
      if (projectPath() === source) {
        state.dirty = true; setSaveState('保存失败，修改仍保留');
        if (!silent || error.status === 409) toast(error.message, 'error', 8000);
      }
      return false;
    } finally { state.pendingSaves--; }
  });
  projectSaveChain = task.catch(() => false);
  return task;
}

function scheduleSave() {
  if (!projectPath() && !state.cues.length && !state.script.length) return;
  state.editRevision++; state.dirty = true;
  setSaveState(projectPath() ? '未保存' : '字幕未保存，请先导出SRT');
  clearTimeout(state.saveTimer);
  if (projectPath()) state.saveTimer = setTimeout(() => saveProject(false), SAVE_DELAY);
}

async function saveAll() {
  if (state.uploading || state.loading) { toast('素材还在导入中，请稍候', 'error'); return false; }
  clearTimeout(state.saveTimer); clearTimeout(state.configTimer);
  const projectOk = await saveProject(false), configOk = await saveConfig(false);
  if (projectOk && configOk && !state.dirty) setSaveState('已保存 ' + new Date().toTimeString().slice(0, 8));
  else if (!projectOk || !configOk) setSaveState('保存失败，修改仍保留');
  return projectOk && configOk && !state.dirty;
}

function updateButtons() {
  const hasCues = state.cues.length > 0, hasScript = state.script.length > 0;
  const align = state.settings.mode === 'align', locked = editLocked();
  for (const id of ['btnSegment', 'btnMerge', 'btnExport']) $('#' + id).disabled = locked || !hasCues;
  $('#btnAddCue').disabled = locked || (!state.media && !hasCues);
  $('#btnDelete').disabled = locked || state.selected < 0;
  $('#btnUndo').disabled = locked || !state.history.length;
  $('#btnRedo').disabled = locked || !state.redoStack.length;
  $('#btnSourceSrt').disabled = locked || (!align && !hasCues);
  $('#btnRematchAll').disabled = locked || !(hasCues && hasScript && align);
  $('#btnAsr').disabled = locked || !state.media || !modelAvailable();
  $('#btnAsr').textContent = '开始识别';
  $('#btnAsr').hidden = align;
  $('#btnExtract').disabled = locked || !state.media || (align
    ? !hasCues || !hasScript || !state.auxModels.some(m => m.name === 'qwen3-forcedaligner-0.6b' && m.available)
    : !modelAvailable());
  $('#btnCancel').disabled = !state.jobId && !downloadBusy();
  $('#btnOpenFolder').disabled = !state.media || state.uploading || state.loading;
  $('#mediaClear').disabled = !!(state.batch || state.jobId || state.submitting || state.operation || state.loading);
  $('#scriptClear').disabled = locked;
  $('#btnUseResult').hidden = !state.pendingResult || state.pendingResult.path !== projectPath();
  $('#btnUseResult').disabled = locked;
  for (const id of ['deviceSelect', 'vadCheck', 'gapInput', 'gapRange', 'widthInput', 'widthRange']) $('#' + id).disabled = locked;
  for (const id of ['matchMinimum','matchHigh','matchPhonetic','matchAmbiguity','matchGroup']) $('#' + id).disabled = locked;
  $('#modelBtn').disabled = locked || !state.models.length;
  $('#auxBtn').disabled = locked || !state.auxModels.length;
  $$('.step-btn').forEach(button => {
    const param = PARAM_FIELDS.find(p => p.key === button.dataset.param);
    const value = Number($(param.input).value);
    button.disabled = locked || (button.dataset.dir === '1' ? value >= param.max : value <= param.min);
  });
  $$('.mode-btn').forEach(button => { button.disabled = locked; });
  cueBody.querySelectorAll('input.time').forEach(input => { input.disabled = locked; });
  cueBody.querySelectorAll('.cue-text').forEach(cell => {
    cell.contentEditable = locked ? 'false' : 'true'; cell.setAttribute('aria-readonly', locked ? 'true' : 'false');
  });
  cueBody.querySelectorAll('button').forEach(button => { button.disabled = locked; });
  $('#mediaZone').setAttribute('aria-disabled', locked ? 'true' : 'false');
  $('#scriptZone').setAttribute('aria-disabled', locked || !align ? 'true' : 'false');
  $('#btnAsr').dataset.tip = locked ? '任务处理中，编辑暂时锁定' : align
    ? '使用当前 SRT 与剧本匹配；直接对齐请先导入 SRT 和剧本。' : !state.media ? '先选择素材' : '识别当前素材';
  renderAlignmentInspector();
}

function bindEvents() {
  $$(".mode-btn").forEach((btn) => {
    btn.addEventListener("click", () => setMode(btn.dataset.mode));
    btn.addEventListener("keydown", (event) => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key) || editLocked()) return;
      event.preventDefault();
      const buttons = $$(".mode-btn");
      const current = buttons.indexOf(btn);
      const next = event.key === "Home" ? 0 : event.key === "End" ? buttons.length - 1
        : (current + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) % buttons.length;
      setMode(buttons[next].dataset.mode); buttons[next].focus(); playSound("key");
    });
  });
  $("#btnSave").addEventListener("click", saveAll);
  $("#btnSourceSrt").addEventListener("click", () => state.settings.mode === 'align' ? importSrt() : exportSrt(false));
  $("#btnHelp").addEventListener("click", () => $("#helpDialog").showModal());
  $("#btnOpenFolder").addEventListener("click", async () => {
    if (!state.media) return;
    try { await api("/api/open_folder", { path: state.media.path }); }
    catch (e) { toast(e.message, "error"); }
  });
  $("#btnAsr").addEventListener("click", () => startAsr(false));
  $("#btnExtract").addEventListener("click", () => state.settings.mode === 'align' ? alignAndVerify() : startAsr(false));
  $("#btnCancel").addEventListener("click", async () => {
    if (downloadBusy()) { await api('/api/models/cancel', {}); await pollModelDownload(); }
    else await cancelAsr();
  });
  $("#btnReconnect").addEventListener("click", () => { state.retryPoll?.(); checkHealth(); });
  $("#btnUseResult").addEventListener("click", async () => {
    const pending = state.pendingResult;
    if (editLocked() || !pending || pending.path !== projectPath()) return;
    replaceCues(pending.job.cues || [], { subtitleFile: pending.job.subtitle_path
      ? { path: pending.job.subtitle_path, origin: 'generated' } : null });
    renderSubtitleSource(true);
    state.pendingResult = null; updateButtons();
    if (await saveProject(false)) { playSound("success"); toast("已采用识别结果，可撤销", "success"); }
  });
  $("#btnRematchAll").addEventListener("click", () => matchScript());
  $("#btnAlignApply").addEventListener("click", () => { applyScript(state.selected); renderScript(); });
  $("#btnAudition").addEventListener("click", async () => {
    const cue = state.cues[state.selected];
    if (!cue || !state.media) return;
    clearInterval(state.auditionTimer); state.auditionEnd = cue.end; focusWave(cue);
    video.currentTime = cue.start;
    try {
      await video.play();
      state.auditionTimer = setInterval(() => {
        if (state.auditionEnd == null || video.currentTime >= state.auditionEnd || video.paused) {
          if (state.auditionEnd != null && video.currentTime >= state.auditionEnd) video.pause();
          clearInterval(state.auditionTimer); state.auditionEnd = null;
        }
      }, 20);
    } catch { state.auditionEnd = null; toast("当前媒体无法试听", "error"); }
  });
  for (const [id, field] of [["alignStart", "start"], ["alignEnd", "end"]]) {
    $("#" + id).addEventListener("change", (event) => {
      if (editLocked()) return;
      const cue = state.cues[state.selected], time = parseTime(event.target.value), duration = waveWindow().duration;
      if (!cue) return;
      if (!Number.isFinite(time) || time < 0 || (duration && time > duration) || (field === "start" ? time >= cue.end : time <= cue.start)) {
        event.target.value = fmtTime(cue[field], true); toast("时间超出范围或起止无效", "error"); return;
      }
      const before = snapshot(); cue[field] = time; cue.words = []; cue.edited = true;
      pushHistory(before); renderAll(); focusWave(cue); scheduleSave();
    });
  }
  $("#waveZoomIn").addEventListener("click", () => {
    const view = waveWindow(); if (!view.duration) return;
    state.waveSpan = Math.max(.5, view.span / 2); state.waveStart = Math.max(0, (video.currentTime || 0) - state.waveSpan / 2); drawWave(); requestWaveDetail();
  });
  $("#waveZoomOut").addEventListener("click", () => {
    const view = waveWindow(); state.waveSpan = Math.min(view.duration, view.span * 2); state.waveStart = Math.max(0, (video.currentTime || 0) - state.waveSpan / 2); drawWave(); requestWaveDetail();
  });
  $("#waveReset").addEventListener("click", () => { state.waveSpan = 0; state.waveStart = 0; drawWave(); requestWaveDetail(); });

  $("#btnSegment").addEventListener("click", doSegment);
  $("#btnMerge").addEventListener("click", doMerge);
  $("#btnAddCue").addEventListener("click", addCue);
  $("#btnDelete").addEventListener("click", deleteCue);
  $("#btnUndo").addEventListener("click", undo);
  $("#btnRedo").addEventListener("click", redo);
  $("#btnExport").addEventListener("click", () => exportSrt(false));

  $("#filterSelect").addEventListener("change", (e) => { state.filter = e.target.value; renderTable(); });
  let searchTimer;
  $("#searchInput").addEventListener("input", (e) => {
    state.search = e.target.value; clearTimeout(searchTimer); searchTimer = setTimeout(renderTable, 120);
  });

  for (const id of ["#deviceSelect", "#vadCheck", "#excludeNoise", "#arabicNumbers", "#keepPunc", "#skipEmpty", "#singleLine"]) {
    $(id).addEventListener("change", commitSettings);
  }
  for (const param of PARAM_FIELDS) {
    const input = $(param.input);
    const range = $(param.range);
    input.addEventListener("input", () => syncParamControl(param));
    input.addEventListener("change", commitSettings);
    range.addEventListener("input", () => {
      if (Number(input.value) !== Number(range.value)) playSound("tick");
      input.value = range.value;
      syncParamControl(param);
      state.settings[param.key] = Number(range.value);
      updateWidthInfo();
      scheduleConfigSave();
      scheduleSave();
    });
    range.addEventListener("change", commitSettings);
  }
  $$(".step-btn").forEach((btn) => {
    const param = PARAM_FIELDS.find((item) => item.key === btn.dataset.param);
    const input = param && $(param.input);
    if (!input) return;
    btn.addEventListener("click", () => {
      syncParamControl(param);
      const next = clamp(
        (Number(input.value) || param.min) + Number(btn.dataset.dir) * param.step,
        param.min,
        param.max,
      );
      syncParamControl(param, next);
      commitSettings();
    });
  });

  $("#modelBtn").addEventListener("click", () => toggleModelMenu());
  $('#auxBtn').addEventListener('click', () => toggleAuxMenu());
  $('#auxMenu').addEventListener('click', event => {
    const download = event.target.closest('[data-download]');
    if (download && !download.disabled) { downloadModel(download.dataset.download); return; }
    const option = event.target.closest('[data-aux]');
    if (option && !option.disabled) { state.settings.auxModel = option.dataset.aux; renderAuxModels(); toggleAuxMenu(false); scheduleConfigSave(); }
  });
  $("#modelMenu").addEventListener("click", (e) => {
    const download = e.target.closest('[data-download]');
    if (download && !download.disabled) { downloadModel(download.dataset.download); return; }
    const option = e.target.closest(".model-option");
    if (option && !option.disabled) chooseModel(option.dataset.name);
  });
  document.addEventListener("pointerdown", (e) => {
    if (!$("#modelPicker").contains(e.target)) toggleModelMenu(false);
    if (!$('#auxPicker').contains(e.target)) toggleAuxMenu(false);
  });
  $("#modelPicker").addEventListener("keydown", (e) => {
    if (["ArrowDown", "ArrowUp", "Home", "End"].includes(e.key)) {
      e.preventDefault();
      if ($("#modelMenu").hidden) { toggleModelMenu(true); return; }
      const options = [...$("#modelMenu").querySelectorAll(".model-option:not(:disabled)")];
      if (!options.length) return;
      const index = options.indexOf(document.activeElement);
      const next = e.key === "Home" ? 0 : e.key === "End" ? options.length - 1
        : (index + (e.key === "ArrowDown" ? 1 : -1) + options.length) % options.length;
      options[next].focus(); playSound("tick");
    }
    if (e.key === "Escape") {
      e.preventDefault();
      toggleModelMenu(false);
      $("#modelBtn").focus();
    }
  });

  cueBody.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (btn) {
      e.stopPropagation();
      applyScript(Number(btn.dataset.i));
      return;
    }
    const tr = e.target.closest("tr[data-i]");
    if (!tr) return;
    if (e.target.closest("button")) return;
    const i = Number(tr.dataset.i);
    selectCue(i, !e.target.closest('input, [contenteditable="true"]'));
  });

  cueBody.addEventListener("focusin", (e) => {
    if (editLocked()) return;
    if (e.target.matches(".cue-text, input.time")) {
      state.editBefore = snapshot();
      const tr = e.target.closest("tr[data-i]");
      if (tr) selectCue(Number(tr.dataset.i), false);
    }
  });

  cueBody.addEventListener("input", (e) => {
    if (editLocked()) return;
    if (!e.target.classList.contains("cue-text")) return;
    const tr = e.target.closest("tr[data-i]");
    if (!tr) return;
    const cue = state.cues[Number(tr.dataset.i)];
    if (!cue) return;
    cue.text = e.target.innerText.replace(/ /g, " ");
    cue.edited = true; cue.review_decision = 'manual';
    if (cue.reference_match) cue.reference_match.stale = true;
    cue.words = [];
    updateOverlay();
    scheduleSave();
  });

  cueBody.addEventListener("change", (e) => {
    if (editLocked()) return;
    if (!e.target.matches("input.time")) return;
    const tr = e.target.closest("tr[data-i]");
    if (!tr) return;
    const cue = state.cues[Number(tr.dataset.i)];
    if (!cue) return;
    const field = e.target.dataset.field;
    const value = parseTime(e.target.value);
    if (value == null || value < 0) {
      toast("时间格式无效", "error");
      e.target.value = fmtTime(cue[field], true);
      return;
    }
    const old = cue[field];
    cue[field] = value;
    if (cue.end <= cue.start) {
      toast("结束时间必须晚于开始时间", "error");
      cue[field] = old;
      e.target.value = fmtTime(old, true);
      return;
    }
    cue.edited = true;
    pushHistory(state.editBefore);
    state.editBefore = snapshot();
    scheduleSave();
    updateOverlay();
    drawWave();
  });

  cueBody.addEventListener("focusout", (e) => {
    if (editLocked()) { state.editBefore = null; return; }
    if (!e.target.matches(".cue-text, input.time")) return;
    if (state.editBefore && snapshot() !== state.editBefore) {
      state.history.push(state.editBefore);
      if (state.history.length > HISTORY_LIMIT) state.history.shift();
      state.redoStack = [];
    }
    state.editBefore = null;
    scheduleSave();
    renderScript();
    updateButtons();
  });

  cueBody.addEventListener("keydown", (e) => {
    if (e.target.classList.contains("cue-text")) {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        e.target.blur();
      } else if (e.key === "Escape") {
        e.preventDefault();
        if (state.editBefore) state.cues = JSON.parse(state.editBefore);
        state.editBefore = null;
        renderTable();
        scheduleSave();
      }
    } else if (e.target.matches("input.time") && e.key === "Enter") {
      e.target.blur();
    }
  });

  scriptList.addEventListener("click", async (e) => {
    const row = e.target.closest('.script-line[data-i]');
    if (!row) return;
    const i = Number(row.dataset.i), cue = state.cues[i], action = e.target.closest('[data-review]')?.dataset.review;
    if (action && editLocked()) return;
    if (action === 'adopt') applyScript(i);
    else if (action === 'rematch') await matchScript(false, [i]);
    else if (['kept','non_script','skipped'].includes(action)) markReview(i, action);
    else if (action === 'edit') { selectCue(i, false); const cell = $(`#cueBody tr[data-i="${i}"] .cue-text`); cell?.scrollIntoView({block:'center'}); cell?.focus(); }
    else if (action === 'confirm') { const before = snapshot(); cue.reference_match.candidate_confirmed = true; pushHistory(before); renderScript(); scheduleSave(); }
    else if (action === 'candidate') {
      const candidate = cue.reference_match.alternatives[Number(e.target.closest('[data-candidate]').dataset.candidate)];
      const before = snapshot(); cue.script_text = candidate.text; cue.script_index = candidate.paragraph_start - 1;
      Object.assign(cue.reference_match, {reference:candidate, score:candidate.score, character_score:candidate.character_score, pinyin_score:candidate.pinyin_score, candidate_confirmed:true, differences:candidate.differences || []});
      pushHistory(before); renderAll(); scheduleSave();
    } else if (!e.target.closest('details,button')) { selectCue(i, true); focusWave(cue); }
  });
  scriptList.addEventListener('keydown', e => { if (e.target.matches('.script-line') && ['Enter',' '].includes(e.key)) { e.preventDefault(); selectCue(Number(e.target.dataset.i)); } });
  for (const key of ['matchMinimum','matchHigh','matchPhonetic','matchAmbiguity','matchGroup']) {
    $('#' + key).addEventListener('change', commitSettings);
  }

  bindWaveCanvas(waveCanvas); bindWaveCanvas($("#alignWave"));

  video.addEventListener("timeupdate", () => { updateOverlay(); drawWave(); });
  video.addEventListener("loadedmetadata", () => {
    if (state.media && !state.media.duration) state.media.duration = video.duration || 0;
    applyPreviewShape();
    renderMediaMeta();
    drawWave();
  });
  video.addEventListener("error", () => {
    if (!state.media || state.videoErrorShown) return;
    state.videoErrorShown = true;
    toast("浏览器无法播放该格式，建议转成 MP4（H.264）后预览；不影响识别和导出", "error", 7000);
  });

  window.addEventListener("beforeunload", (event) => {
    if (state.dirty || state.pendingSaves || state.jobId) { event.preventDefault(); event.returnValue = ""; }
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden" && state.dirty) {
      clearTimeout(state.saveTimer);
      saveProject(true, { keepalive: true });
    }
  });

  document.addEventListener("keydown", (e) => {
    const tag = (e.target.tagName || "").toLowerCase();
    const editing = e.target.isContentEditable || tag === "input" || tag === "select" || tag === "textarea";
    if (e.ctrlKey && e.key.toLowerCase() === "s") {
      e.preventDefault();
      saveAll();
      return;
    }
    if (editing) return;
    if (e.code === "Space") {
      e.preventDefault();
      if (video.paused) video.play().catch(() => {}); else video.pause();
    } else if (e.ctrlKey && e.key.toLowerCase() === "z") {
      e.preventDefault();
      undo();
    } else if (e.ctrlKey && e.key.toLowerCase() === "y") {
      e.preventDefault();
      redo();
    }
  });

  bindDropzones();
  bindSplitters();
}

function revealApp() {
  clearTimeout(window.__bootTimer);
  document.documentElement.classList.remove("booting");
}

async function init() {
  let initialTheme = "system";
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (THEMES.includes(saved)) initialTheme = saved;
  } catch { /* ignore */ }
  applyTheme(initialTheme, false);
  bindThemeControls();
  bindFeedback();
  loadSettings();
  loadLayoutLocal();
  bindTooltips();
  bindEvents();
  await loadConfig();
  saveLayoutLocal();
  collectSettings();
  renderAll();
  updateModeUI();
  applyLayout();
  revealApp();
  await checkHealth();
  pollModelDownload();
}

init();
