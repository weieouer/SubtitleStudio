"""报告R-01至R-20的后端回归；全部文件写入临时目录。"""
from __future__ import annotations

import concurrent.futures
from array import array
import copy
import hashlib
import http.client
import json
import math
import os
import subprocess
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from urllib.parse import quote
import wave

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
import app
from core import jobs, media, script, segment, srt_io
from core.storage import atomic_json


def cue(text="你好", start=0, end=1, **extra):
    return {"text": text, "start": start, "end": end, **extra}


class CoreTests(unittest.TestCase):
    def test_export_text_options_preserve_original_and_semantic_punctuation(self):
        items = [cue("你好，世界！\n价格3.5元，50%，don't，GPT-4。", role="甲"), cue("！！", 1, 2), cue("  ", 2, 3)]
        original = copy.deepcopy(items)
        result = srt_io.prepare_export_cues(items, keep_punctuation=False, single_line=True)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["text"], "你好世界 价格3.5元50%don'tGPT-4")
        self.assertEqual(items, original)
        self.assertIn("甲：", srt_io.format_srt(result, with_role=True))
        self.assertEqual(len(srt_io.prepare_export_cues(items, skip_empty=False)), 3)
        self.assertEqual(srt_io.prepare_export_cues([cue('Hello,world! 12:30 1,000.5')], keep_punctuation=False)[0]['text'], 'Helloworld 12:30 1,000.5')

    def gap_cue(self, text="你好，走吧！"):
        return cue(text, 0, 3, words=[{"word": "你好", "start": 0, "end": .9},
                                     {"word": "走吧", "start": 2, "end": 2.9}])

    def test_gap_preserves_punctuation_and_spacing(self):
        for text in ("你好，走吧！", " 你好， 走吧！ "):
            parts, n = segment.split_on_gaps([self.gap_cue(text)], .6)
            self.assertEqual(n, 1)
            self.assertEqual("".join(p["text"] for p in parts), text)

    def test_gap_does_not_revert_corrected_text(self):
        original = self.gap_cue("您好，走吧！")
        parts, n = segment.split_on_gaps([original], .6)
        self.assertEqual(n, 0)
        self.assertEqual(parts[0]["text"], original["text"])
        self.assertTrue(parts[0]["gap_split_skipped"])

    def test_gap_without_words_is_unchanged(self):
        original = cue()
        self.assertEqual(segment.split_on_gaps([original], .6), ([original], 0))

    def test_shared_word_time_stays_inside_original(self):
        text = "甲乙丙丁戊己庚辛壬癸子丑"
        parts, _ = segment.segment_cue(cue(text, 0, 2, words=[{"word": text, "start": 0, "end": 2}]), 6)
        self.assertEqual(parts[0]["start"], 0)
        self.assertEqual(parts[-1]["end"], 2)
        self.assertEqual("".join(p["text"] for p in parts), text)
        for i, part in enumerate(parts):
            self.assertLess(part["start"], part["end"])
            if i:
                self.assertGreaterEqual(part["start"], parts[i - 1]["end"])

    def test_short_interval_never_expands(self):
        for end in (.001, .01, .1, 2):
            original = cue("一二三四五六七八九十一二三四五六七八九十", 0, end)
            parts, _ = segment.segment_cue(original, 6)
            self.assertEqual("".join(p["text"] for p in parts), original["text"])
            self.assertLessEqual(parts[-1]["end"], end)

    def test_width_split_preserves_outer_whitespace(self):
        original = "  一二三四五六七八九十。 \n"
        parts, _ = segment.segment_cue(cue(original, 0, 3), 6)
        self.assertEqual("".join(part["text"] for part in parts), original)

    def test_merge_preserves_complete_words(self):
        left = cue("你好", 0, 1, words=[{"word": "你好", "start": 0, "end": 1}], script_text="旧建议")
        right = cue("走吧", 1.1, 2, words=[{"word": "走吧", "start": 1.1, "end": 2}])
        parts, n = segment.merge_cues([left, right])
        self.assertEqual(n, 1)
        self.assertEqual(len(parts[0]["words"]), 2)
        self.assertNotIn("script_text", parts[0])
        self.assertEqual(left["text"], "你好")

    def test_overlap_is_not_merged(self):
        self.assertEqual(segment.merge_cues([cue("甲", 0, 2), cue("乙", 1, 3)])[1], 0)

    def test_match_is_monotonic_and_unique(self):
        result = script.match_script([cue("甲"), cue("乙")], script.parse_script_text("角色：乙\n角色：甲"))
        indexes = [h["cue_index"] for h in result["hits"]]
        self.assertEqual(indexes, sorted(set(indexes)))
        result = script.match_script([cue("你好")], script.parse_script_text("甲：你好\n乙：你好"))
        self.assertEqual(result["stats"]["matched"], 1)
        self.assertEqual(result["cues"][0]["role"], "甲")

    def test_match_can_relocate_beyond_first_window(self):
        result = script.match_script([cue("甲甲甲甲") for _ in range(20)] + [cue("乙乙乙乙")],
                                     script.parse_script_text("角色：乙乙乙乙"))
        self.assertEqual(result["hits"][0]["cue_index"], 20)

    def test_match_preserves_asr_review_reason(self):
        for line in ("角色：你好", "角色：完全无关台词"):
            result = script.match_script([cue(needs_review=True)], script.parse_script_text(line))
            self.assertTrue(result["cues"][0]["needs_review"])

    def test_export_rejects_bad_times_and_overlap(self):
        for items in ([cue(end=20)], [cue(start=float("nan"))], [cue(end=float("inf"))],
                      [cue(start=-1)], [cue(start=1, end=1)], [cue("甲", 0, 2), cue("乙", 1, 3)]):
            self.assertTrue(srt_io.validate_cues(items, 10))

    def test_srt_roundtrip_utf8_crlf(self):
        items, warnings = srt_io.parse_srt_text("1\n00:00:00,000 --> 00:00:01,000\n你好\n第二行\n")
        self.assertFalse(warnings)
        encoded = srt_io.format_srt(items).encode("utf-8")
        self.assertFalse(encoded.startswith(b"\xef\xbb\xbf"))
        self.assertIn(b"\r\n", encoded)
        self.assertEqual(items[0]["text"], "你好\n第二行")

    def test_query_path_decodes_once(self):
        for name in ("name%20.mp4", "name%2F.mp4", "加+号 空格.mp4"):
            self.assertEqual(app._qget(app.parse_qs("path=" + quote(name)), "path"), name)


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix="subtitle-regression-")
        cls.folder = Path(cls.tmp.name)
        cls.patches = [patch.object(app, key, cls.folder / key) for key in
                       ("PROJECT_DIR", "CONFIG_DIR", "OUTPUT_DIR", "UPLOADS_DIR")]
        for p in cls.patches:
            p.start()
        for key in ("PROJECT_DIR", "CONFIG_DIR", "OUTPUT_DIR", "UPLOADS_DIR"):
            getattr(app, key).mkdir()
        cls.source = cls.folder / "source.srt"
        cls.source.write_text(srt_io.format_srt([cue()]), encoding="utf-8")
        cls.binary = cls.folder / "sample.mp4"
        cls.binary.write_bytes(bytes(range(250)) * 4)
        class QuietHandler(app.Handler):
            def log_message(self, *args):
                pass
        cls.server = app.ThreadingHTTPServer(("127.0.0.1", 0), QuietHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(5)
        for p in cls.patches:
            p.stop()
        cls.tmp.cleanup()

    def request(self, method, path, body=None, headers=None, auth=True, raw=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        request_headers = {"Content-Type": "application/json"}
        if auth:
            request_headers["X-SubtitleStudio-Token"] = app.SESSION_TOKEN
        request_headers.update(headers or {})
        payload = raw if raw is not None else json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        try:
            connection.request(method, path, payload, request_headers)
            response = connection.getresponse()
            data = response.read()
            return response.status, dict(response.getheaders()), data
        finally:
            connection.close()

    def json_request(self, method, path, body=None, **kwargs):
        status, _, raw = self.request(method, path, body, **kwargs)
        return status, json.loads(raw)

    def test_session_token_is_in_html_and_required_for_api(self):
        status, _, body = self.request("GET", "/", auth=False)
        self.assertEqual(status, 200)
        self.assertIn(app.SESSION_TOKEN.encode(), body)
        self.assertNotIn(b"__SUBTITLE_SESSION_TOKEN__", body)
        self.assertEqual(self.request("GET", "/api/health", auth=False)[0], 403)
        self.assertEqual(self.request("GET", "/api/health")[0], 200)

    def test_film_icon_is_served(self):
        status, headers, raw = self.request("GET", "/favicon.ico", auth=False)
        self.assertEqual(status, 200)
        self.assertTrue(raw.startswith(b"\0\0\1\0"))
        self.assertIn("image/", headers["Content-Type"])
        self.assertEqual(self.request("GET", "/assets/studio-film.svg", auth=False)[0], 200)

    def test_foreign_host_and_origin_rejected(self):
        for headers in ({"Host": "review.invalid"}, {"Origin": "http://review.invalid"},
                        {"Sec-Fetch-Site": "cross-site"}, {"X-SubtitleStudio-Token": "错".encode("utf-8").decode("latin1")}):
            self.assertEqual(self.request("GET", "/api/config", headers=headers)[0], 403)
        self.assertEqual(self.request("OPTIONS", "/api/config")[0], 403)

    def test_local_origin_allowed(self):
        self.assertEqual(self.request("GET", "/api/config", headers={"Origin": "http://127.0.0.1:" + str(self.server.server_port)})[0], 200)

    def test_static_traversal_rejected(self):
        self.assertEqual(self.request("GET", "/../backend/app.py")[0], 404)

    def test_ranges_and_media_query_token(self):
        url = "/api/media/stream?path=" + quote(str(self.binary)) + "&token=" + app.SESSION_TOKEN
        for header, expected_status, expected_length, expected_range in [
            ("bytes=-100", 206, 100, "bytes 900-999/1000"),
            ("bytes=0-2000", 206, 1000, "bytes 0-999/1000"),
            ("bytes=950-", 206, 50, "bytes 950-999/1000"),
            ("bytes=5-3", 416, 0, "bytes */1000"),
            ("bytes=1000-", 416, 0, "bytes */1000"),
            ("bytes=-0", 416, 0, "bytes */1000"),
            ("bytes=0-1,3-4", 416, 0, "bytes */1000"),
        ]:
            with self.subTest(range=header):
                status, headers, raw = self.request("GET", url, headers={"Range": header}, auth=False)
                self.assertEqual((status, len(raw), headers.get("Content-Range")), (expected_status, expected_length, expected_range))
                self.assertEqual(int(headers["Content-Length"]), len(raw))
                if header == "bytes=-100":
                    self.assertEqual(raw, self.binary.read_bytes()[-100:])

    def test_invalid_schema_returns_400(self):
        cases = [("/api/segment", {"cues": [1]}), ("/api/segment", {"cues": [cue(words=[1])]}),
                 ("/api/segment/merge", {"cues": [cue()], "max_width": 50}),
                 ("/api/segment/merge", {"cues": [cue()], "max_gap": -1}),
                 ("/api/srt/export", {"cues": [cue()], "options": []}),
                 ("/api/script/match", {"cues": [cue()], "lines": ["x"]}),
                 ("/api/projects/save", {"source_path": str(self.source), "cues": [cue()], "expected_revision": True}),
                 ("/api/config", {"layout": {"left": "bad"}})]
        for endpoint, body in cases:
            with self.subTest(endpoint=endpoint, body=body):
                self.assertEqual(self.request("POST", endpoint, body)[0], 400)
        self.assertEqual(self.request("POST", "/api/segment", raw=b'{"cues":[],"max_width":NaN}')[0], 400)

    def test_oversize_body_closes_connection(self):
        with patch.object(app, "MAX_BODY", 1):
            status, headers, _ = self.request("POST", "/api/config", {"theme": "light"})
            self.assertEqual(status, 400)
        self.assertEqual(self.request("POST", "/api/config", raw=b"{}", headers={"Content-Type": "text/plain"})[0], 400)

    def test_standalone_srt_project_and_revision_conflict(self):
        source = self.folder / "standalone.srt"
        source.write_text(self.source.read_text(encoding="utf-8"), encoding="utf-8")
        body = {"source_path": str(source), "cues": [cue("已校对")], "expected_revision": 0}
        status, result = self.json_request("POST", "/api/projects/save", body)
        self.assertEqual(status, 200)
        self.assertEqual(result["revision"], 1)
        self.assertEqual(self.request("POST", "/api/projects/save", body)[0], 409)
        status, loaded = self.json_request("GET", "/api/projects/load?path=" + quote(str(source)))
        self.assertEqual(loaded["project"]["cues"][0]["text"], "已校对")
        self.assertEqual(loaded["project"]["media_path"], "")
        body["expected_revision"] = 1
        self.assertEqual(self.json_request("POST", "/api/projects/save", body)[1]["revision"], 2)

    def test_concurrent_save_only_one_same_revision_wins(self):
        source = self.folder / "concurrent.srt"
        source.write_text("", encoding="utf-8")
        body = {"source_path": str(source), "cues": [cue()], "expected_revision": 0}
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            statuses = list(pool.map(lambda _: self.request("POST", "/api/projects/save", body)[0], range(2)))
        self.assertEqual(sorted(statuses), [200, 409])
        self.assertFalse(list(app.PROJECT_DIR.glob("*.tmp")))

    def test_cross_process_file_lock_serializes_revision_update(self):
        target = self.folder / "cross-process.json"
        code = "import sys,json,time;from pathlib import Path;sys.path.insert(0,sys.argv[1]);from core.storage import locked_file,atomic_json;p=Path(sys.argv[2]);\nwith locked_file(p):\n v=json.loads(p.read_text())['revision'] if p.exists() else 0\n time.sleep(.1)\n atomic_json(p,{'revision':v+1})\n"
        children = [subprocess.Popen([sys.executable, "-c", code, str(ROOT / "backend"), str(target)],
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE) for _ in range(2)]
        for child in children:
            _, error = child.communicate(timeout=15)
            self.assertEqual(child.returncode, 0, error.decode("utf-8", errors="replace"))
        self.assertEqual(json.loads(target.read_text())["revision"], 2)

    def test_export_encoding_collision_and_duration(self):
        body = {"cues": [cue()], "options": {"output_dir": str(self.folder / "export")}}
        outputs = []
        for _ in range(2):
            status, response = self.json_request("POST", "/api/srt/export", body)
            self.assertEqual(status, 200)
            outputs.append(Path(response["path"]))
        self.assertNotEqual(*outputs)
        self.assertEqual(outputs[0].read_bytes(), srt_io.format_srt([cue()]).encode("utf-8"))

    def test_reference_full_text_and_offsets_survive_project_save(self):
        text = '\r\n场景：清晨\r\n  我们明天去公园散步。\r\n'
        status, parsed = self.json_request('POST','/api/script/parse',{'text':text})
        self.assertEqual(status,200)
        self.assertEqual(parsed['document']['text'],text)
        status, matched = self.json_request('POST','/api/script/match',{
            'cues':[cue('我们明天去公圆散步')], 'lines':parsed['lines'], 'document':parsed['document']})
        self.assertEqual(status,200,matched)
        self.assertEqual(matched['cues'][0]['reference_match']['status'],'homophone')
        reference=matched['cues'][0]['reference_match']['reference']
        self.assertEqual(text[reference['start']:reference['end']],reference['text'])
        source=self.folder/'reference-project.srt'; source.write_bytes(self.source.read_bytes())
        body={'source_path':str(source),'cues':matched['cues'],'script_lines':matched['lines'],
              'script_document':parsed['document'],'expected_revision':0}
        self.assertEqual(self.json_request('POST','/api/projects/save',body)[0],200)
        loaded=self.json_request('GET','/api/projects/load?path='+quote(str(source)))[1]['project']
        self.assertEqual(loaded['script_document']['text'],text)
        self.assertEqual(loaded['cues'][0]['original_text'],'我们明天去公圆散步')

    def test_srt_drop_upload_is_preserved_working_copy(self):
        content=srt_io.format_srt([cue('拖入字幕。')]).encode('utf-8')
        status,_,raw=self.request('POST','/api/upload?kind=srt',raw=content,
            headers={'Content-Type':'application/octet-stream','X-Upload-Name':quote('字幕.srt')})
        self.assertEqual(status,200,raw)
        saved=Path(json.loads(raw)['path'])
        self.assertEqual(saved.read_bytes(),content)
        self.assertIn(self.folder/'UPLOADS_DIR',saved.parents)
        self.assertEqual(self.json_request('POST','/api/srt/parse',{'path':str(saved)})[1]['cues'][0]['text'],'拖入字幕。')

    def test_alignment_job_and_catalog_contract(self):
        import core.alignment as alignment
        self.assertEqual(len(self.json_request('GET','/api/models')[1]['models']),5)
        self.assertEqual(self.json_request('POST','/api/models/download',{'model':'not-a-model'})[0],400)
        request_id=hashlib.sha1(str(time.time_ns()).encode()).hexdigest()[:16]
        items=[cue('确认过的字幕',original_text='原始 ASR',original_start=0,original_end=1)]
        aligned=[dict(items[0],start=.1,end=1.1)]
        with patch.object(alignment,'align_cues',return_value=(aligned,{'duration':2})), \
             patch.object(jobs,'RESULTS_DIR',self.folder), \
             patch.object(app,'list_auxiliary',return_value=[{'name':'qwen3-forcedaligner-0.6b','available':True}]):
            status,response=self.json_request('POST','/api/alignment/jobs',{'path':str(self.binary),'cues':items,'device':'cpu','request_id':request_id})
            self.assertEqual(status,200,response)
            app.JOBS.queue.join()
            completed=self.json_request('GET','/api/jobs/'+request_id+'?result=1')[1]['job']
            self.assertEqual(completed['task'],'align')
            self.assertEqual(completed['cues'][0]['text'],'确认过的字幕')
            self.assertEqual(completed['cues'][0]['original_text'],'原始 ASR')
            self.assertEqual(completed['cues'][0]['original_start'],0)

    def test_export_options_filter_empty_and_never_readd_removed_punctuation(self):
        body = {"cues": [cue("你好，\n世界！", role="甲"), cue("！！", 1, 2), cue(" ", 2, 3)],
                "options": {"output_dir": str(self.folder / "options"), "keep_punctuation": False,
                            "add_punctuation": True, "single_line": True, "skip_empty": True, "with_role": True}}
        status, response = self.json_request("POST", "/api/srt/export", body)
        self.assertEqual(status, 200, response)
        self.assertEqual(response["count"], 1)
        exported, warnings, _ = srt_io.parse_srt_file(response["path"])
        self.assertFalse(warnings)
        self.assertEqual(exported[0]["text"], "甲：你好 世界")
        body["options"]["skip_empty"] = False
        self.assertEqual(self.json_request("POST", "/api/srt/export", body)[0], 400)
        body["options"]["single_line"] = "true"
        self.assertEqual(self.json_request("POST", "/api/srt/export", body)[0], 400)

    def test_job_idempotency_and_light_poll(self):
        request_id = hashlib.sha1(str(time.time_ns()).encode()).hexdigest()[:16]
        with patch.object(jobs, "transcribe", return_value=([cue()], {})), \
                patch.object(jobs, "RESULTS_DIR", self.folder), \
                patch.object(app, "list_models", return_value=[{"name": "medium", "available": True}]):
            payload = {"path": str(self.binary), "request_id": request_id, "model": "medium", "device": "cpu"}
            first = self.json_request("POST", "/api/jobs", payload)
            second = self.json_request("POST", "/api/jobs", payload)
            self.assertEqual(first[1]["job"]["id"], second[1]["job"]["id"])
            app.JOBS.queue.join()
            status, light = self.json_request("GET", "/api/jobs/" + request_id)
            self.assertNotIn("cues", light["job"])
            self.assertEqual(light["job"]["status"], "done")
            result = self.json_request("GET", "/api/jobs/" + request_id + "?result=1")[1]
            self.assertEqual(result["job"]["cues"][0]["text"], "你好")
            subtitle = Path(result["job"]["subtitle_path"])
            self.assertTrue(subtitle.is_file())
            self.assertEqual(srt_io.parse_srt_file(str(subtitle))[0][0]["text"], "你好")

    def test_cancelled_queued_job_balances_queue(self):
        entered, release = threading.Event(), threading.Event()
        def fake(*args, **kwargs):
            entered.set()
            release.wait(3)
            return [cue()], {}
        with patch.object(jobs, "transcribe", side_effect=fake), patch.object(jobs, "RESULTS_DIR", self.folder):
            first = app.JOBS.submit(str(self.binary), "medium", "cpu", True)
            self.assertTrue(entered.wait(2))
            second = app.JOBS.submit(str(self.binary), "medium", "cpu", True)
            app.JOBS.cancel(second.id)
            release.set()
            app.JOBS.queue.join()
            self.assertEqual(second.status, "cancelled")
            self.assertEqual(app.JOBS.queue.unfinished_tasks, 0)

    def test_decode_can_cancel_during_frames(self):
        path = self.folder / "audio.wav"
        with wave.open(str(path), "wb") as fh:
            fh.setnchannels(1)
            fh.setsampwidth(2)
            fh.setframerate(16000)
            fh.writeframes(b"\0\0" * 16000)
        event = threading.Event()
        event.set()
        with self.assertRaises(media.DecodeCancelled):
            media.decode_audio(str(path), cancel_event=event)

    def test_streaming_waveform_and_error_reporting(self):
        path = self.folder / "wave.wav"
        with wave.open(str(path), "wb") as fh:
            fh.setnchannels(1)
            fh.setsampwidth(2)
            fh.setframerate(16000)
            fh.writeframes(b"\0\0" * 32000)
        with patch.object(media, "CACHE_DIR", self.folder):
            result = media.waveform(str(path), 100)
            self.assertIsNone(result["error"])
            self.assertLessEqual(len(result["peaks"]), 100)
            self.assertAlmostEqual(result["duration"], 2)
            self.assertTrue(all(p == 0 for p in result["peaks"]))
            invalid = media.waveform(str(self.binary), 100)
            self.assertTrue(invalid["error"])

    def test_zoom_waveform_decodes_requested_time_region(self):
        path = self.folder / "region.wav"
        with wave.open(str(path), "wb") as out:
            out.setnchannels(1)
            out.setsampwidth(2)
            out.setframerate(16000)
            out.writeframes(array("h", [int(10000 * math.sin(2 * math.pi * 440 * i / 16000))
                                       if i < 16000 else 0 for i in range(32000)]).tobytes())
        with patch.object(media, "CACHE_DIR", self.folder):
            voiced = media.waveform_region(str(path), .2, .5, 200)
            silent = media.waveform_region(str(path), 1.5, 1.9, 200)
            self.assertGreater(max(voiced["peaks"]), .2)
            self.assertTrue(all(value == 0 for value in silent["peaks"]))
            self.assertEqual((voiced["start"], voiced["end"], voiced["buckets"]), (.2, .5, 200))
            url = "/api/waveform?path=" + quote(str(path)) + "&start=.2&end=.5&buckets=200"
            status, result = self.json_request("GET", url)
            self.assertEqual(status, 200)
            self.assertGreater(max(result["peaks"]), .2)
            self.assertEqual(self.request("GET", "/api/waveform?path=" + quote(str(path)) + "&start=nan&end=.5")[0], 400)


@unittest.skipUnless(os.name == "nt", "Windows窗口图标测试")
class WindowIconTests(unittest.TestCase):
    def test_native_window_icon_and_taskbar_properties(self):
        import ctypes as c
        from ctypes import wintypes as w
        from core.window_icon import set_window_icon
        user = c.windll.user32
        user.CreateWindowExW.argtypes = [w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD, c.c_int, c.c_int,
                                        c.c_int, c.c_int, w.HWND, w.HMENU, w.HINSTANCE, c.c_void_p]
        user.CreateWindowExW.restype = w.HWND
        user.DestroyWindow.argtypes = [w.HWND]
        user.SendMessageW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
        user.SendMessageW.restype = c.c_ssize_t
        hwnd = user.CreateWindowExW(0, "STATIC", "SubtitleStudio icon test", 0, 0, 0, 100, 100, None, None, None, None)
        self.assertTrue(hwnd)
        try:
            result = set_window_icon(hwnd, ROOT / "frontend/assets/studio-film.ico", ROOT / "run.bat")
            self.assertTrue(result["window_icon"])
            self.assertTrue(result["taskbar"])
            self.assertTrue(user.SendMessageW(hwnd, 0x7F, 0, 0))
            self.assertTrue(user.SendMessageW(hwnd, 0x7F, 1, 0))
        finally:
            user.DestroyWindow(hwnd)


if __name__ == "__main__":
    unittest.main(verbosity=2)
