import vm from 'node:vm';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

export async function runFrontendTests(source) {
  const results = [];
  const extract = name => {
    const start = source.search(new RegExp(`^(?:async )?function ${name}\\(`, 'm'));
    const next = source.slice(start + 1).search(/^(?:async )?function \w+\(/m);
    assert(start >= 0 && next >= 0, name);
    return source.slice(start, start + 1 + next);
  };
  const noop = () => {};
  const make = (overrides = {}, functions = []) => {
    const elements = new Map();
    const context = vm.createContext({
      state: { media: {path: 'A.wav'}, srtPath: '', mediaEpoch: 1, cues: [{start: 0, end: 1, text: '原字幕'}],
        settings: {mode: 'extract', sound: true}, script: [], scriptName: '', selected: -1,
        history: [], redoStack: [], asrEpoch: 0, jobId: null, submitting: false, uploading: false,
        operation: '', batch: false, loading: false, pendingResult: null, pendingSaves: 0,
        editRevision: 1, dirty: true, queue: [] },
      $: id => { if (!elements.has(id)) elements.set(id, {hidden: true, textContent: '', style: {}, disabled: false}); return elements.get(id); },
      document: {activeElement: {blur: noop}}, crypto: {randomUUID},
      toast: noop, renderAll: noop, renderTable: noop, updateButtons: noop, updateOverlay: noop,
      updateJob: noop, drawWave: noop, renderQueue: noop, setSaveState: noop, playSound: noop,
      modelAvailable: () => true, collectSettings: () => ({mode: 'extract', model: 'medium', device: 'cpu', gap: .6, vad: true}),
      scheduleSave: noop, saveProject: async () => true, saveConfig: async () => true,
      matchScript: async () => true, exportSrt: async () => ({path: 'A.srt'}),
      projectVersions: new Map(), projectSaveChain: Promise.resolve(), configSaveChain: Promise.resolve(),
      HISTORY_LIMIT: 60, SAVE_DELAY: 1200, SESSION_TOKEN: 'test-token',
      jobMsg: {textContent: ''}, sleep: async () => {},
      setTimeout: callback => setTimeout(callback, 1), clearTimeout,
      ...overrides,
    });
    vm.runInContext(['projectPath', 'editLocked', 'snapshot', 'sameDocument', 'normalizeCue', 'pushHistory', 'replaceCues', 'clamp', ...functions].map(extract).join('\n'), context);
    return context;
  };
  const test = async (name, run) => { await run(); results.push({name, passed: true}); };

  await test('asr_duplicate_submission_locked_before_request_returns', async () => {
    let release, calls = 0;
    const ctx = make({api: async path => {
      if (path === '/api/jobs') {calls++; return new Promise(resolve => {release = resolve;});}
      return {job: {status: 'done', cues: [{start: 0, end: 1, text: '结果'}]}};
    }}, ['startAsr']);
    const first = ctx.startAsr();
    assert(ctx.state.jobId && ctx.state.submitting);
    assert.equal(await ctx.startAsr(), null);
    assert.equal(calls, 1);
    release({job: {status: 'queued'}});
    assert.equal((await first).status, 'done');
  });

  await test('asr_retains_manual_edits_and_offers_result', async () => {
    let saved = 0;
    const ctx = make({saveProject: async () => {saved++; return true;}}, ['startAsr']);
    ctx.api = async path => {
      if (path === '/api/jobs') return {job: {status: 'queued'}};
      ctx.state.cues[0].text = '人工校对';
      return {job: {status: 'done', cues: [{start: 0, end: 1, text: '识别结果'}]}};
    };
    assert.equal((await ctx.startAsr()).status, 'error');
    assert.equal(ctx.state.cues[0].text, '人工校对');
    assert.equal(ctx.state.pendingResult.job.cues[0].text, '识别结果');
    assert.equal(saved, 0);
  });

  await test('poll_and_result_download_retry_same_task', async () => {
    let polls = 0, downloads = 0, identities = [];
    const ctx = make({}, ['startAsr']);
    ctx.api = async path => {
      if (path === '/api/jobs') return {job: {status: 'queued'}};
      identities.push(ctx.state.jobId);
      if (path.includes('result=1')) { if (++downloads === 1) throw new Error('temporary result failure'); }
      else if (++polls === 1) throw new Error('temporary status failure');
      return {job: {status: 'done', cues: [{start: 0, end: 1, text: '结果'}]}};
    };
    assert.equal((await ctx.startAsr()).status, 'done');
    assert.equal(new Set(identities).size, 1);
    assert(identities.every(Boolean));
    assert.equal(downloads, 2);
  });

  await test('batch_export_failure_is_not_done', async () => {
    const ctx = make({api: async () => ({job: {status: 'done', cues: [{start: 0, end: 1, text: '结果'}]}}),
      exportSrt: async () => null}, ['startAsr']);
    assert.equal((await ctx.startAsr(true)).status, 'export_error');
  });

  await test('standalone_srt_save_uses_source_and_revision', async () => {
    let payload;
    const ctx = make({api: async (path, body) => {payload = body; return {revision: 1, updated_at: '2026-11-04 12:00:00'};}}, ['saveProject']);
    ctx.state.media = null; ctx.state.srtPath = 'standalone.srt';
    assert.equal(await ctx.saveProject(), true);
    assert.equal(payload.source_path, 'standalone.srt');
    assert.equal(payload.media_path, ''); assert.equal(payload.expected_revision, 0);
    assert.equal(ctx.state.dirty, false);
  });

  await test('unbound_cues_never_report_saved', async () => {
    const ctx = make({}, ['saveProject']); ctx.state.media = null;
    assert.equal(await ctx.saveProject(), false);
  });

  await test('saves_are_serial_and_latest_snapshot_wins', async () => {
    let release;
    const payloads = [];
    const ctx = make({api: async (path, body) => {
      payloads.push(body);
      if (payloads.length === 1) return new Promise(resolve => {release = resolve;});
      return {revision: 2, updated_at: '2026-11-04 12:00:00'};
    }}, ['saveProject']);
    const first = ctx.saveProject();
    await Promise.resolve();
    ctx.state.cues[0].text = '最新修改'; ctx.state.editRevision++;
    const second = ctx.saveProject();
    assert.equal(payloads.length, 1);
    release({revision: 1, updated_at: '2026-11-04 12:00:00'});
    assert.equal(await first, true); assert.equal(await second, true);
    assert.equal(payloads[1].expected_revision, 1);
    assert.equal(payloads[1].cues[0].text, '最新修改');
    assert.equal(payloads[0].cues[0].text, '原字幕');
    assert.equal(ctx.state.dirty, false);
  });

  await test('save_conflict_retains_dirty_edits', async () => {
    const ctx = make({api: async () => {throw Object.assign(new Error('conflict'), {status: 409});}}, ['saveProject']);
    assert.equal(await ctx.saveProject(), false);
    assert.equal(ctx.state.dirty, true);
    assert.equal(ctx.state.cues[0].text, '原字幕');
  });

  await test('failed_save_blocks_media_switch', async () => {
    let requests = 0;
    const ctx = make({saveProject: async () => false, api: async () => {requests++;}}, ['loadMedia']);
    assert.equal(await ctx.loadMedia('B.wav'), false);
    assert.equal(ctx.state.media.path, 'A.wav'); assert.equal(requests, 0);
  });

  await test('batch_load_failure_does_not_start_previous_media', async () => {
    let starts = 0;
    const ctx = make({loadMedia: async () => false, startAsr: async () => {starts++;}}, ['runQueue']);
    ctx.state.queue = [{path: 'B.wav', status: 'pending'}];
    await ctx.runQueue();
    assert.equal(starts, 0); assert.equal(ctx.state.queue[0].status, 'error');
  });

  await test('cancelled_batch_renders_cancelled_state', async () => {
    const renders = [];
    const ctx = make({loadMedia: async () => true, startAsr: async () => ({status: 'cancelled'})}, ['runQueue']);
    ctx.state.queue = [{path: 'A.wav', status: 'pending'}];
    ctx.renderQueue = () => renders.push(ctx.state.queue[0].status);
    await ctx.runQueue();
    assert.equal(renders.at(-1), 'cancelled'); assert.equal(ctx.state.batch, false);
  });

  await test('export_retry_uses_saved_cues_without_asr', async () => {
    let starts = 0, exports = 0;
    const ctx = make({loadMedia: async () => true, startAsr: async () => {starts++;},
      exportSrt: async () => {exports++; return {path: 'A.srt'};}}, ['runQueue']);
    ctx.state.queue = [{path: 'A.wav', status: 'export_error'}]; await ctx.runQueue();
    assert.equal(starts, 0); assert.equal(exports, 1); assert.equal(ctx.state.queue[0].status, 'done');
  });

  await test('stale_waveform_is_ignored', async () => {
    let release;
    const ctx = make({api: () => new Promise(resolve => {release = resolve;})}, ['loadWaveform']);
    const pending = ctx.loadWaveform(); ctx.state.media = {path: 'B.wav'}; ctx.state.mediaEpoch++;
    ctx.state.waveform = {tag: 'B'}; release({tag: 'A'}); await pending;
    assert.equal(ctx.state.waveform.tag, 'B');
  });

  await test('unsorted_cue_preview_is_correct', async () => {
    const ctx = make({}, ['findCueAt']); ctx.state.cues = [{start: 10, end: 11}, {start: 20, end: 21}, {start: 0, end: 1}];
    assert.equal(ctx.findCueAt(.5).start, 0);
  });

  await test('stale_segment_response_preserves_current_text', async () => {
    let release;
    const ctx = make({api: () => new Promise(resolve => {release = resolve;})}, ['doSegment']);
    const pending = ctx.doSegment(); ctx.state.cues[0].text = '保留此改动';
    release({cues: [{start: 0, end: 1, text: '旧响应'}], splits: 0}); await pending;
    assert.equal(ctx.state.cues[0].text, '保留此改动'); assert.equal(ctx.state.operation, '');
  });

  await test('replacement_and_undo_keep_one_document_history', async () => {
    const ctx = make({}, ['undo']);
    ctx.replaceCues([{start: 0, end: 1, text: '新字幕'}]);
    ctx.undo(); assert.equal(ctx.state.cues[0].text, '原字幕');
    ctx.replaceCues([{start: 0, end: 1, text: '另一个工程'}], {reset: true});
    assert.equal(ctx.state.history.length, 0); assert.equal(ctx.state.redoStack.length, 0);
  });

  await test('api_timeout_and_session_header', async () => {
    const ctx = make({AbortController, setTimeout, clearTimeout, fetch: async (path, options) => {
      assert.equal(options.headers['X-SubtitleStudio-Token'], 'test-token');
      return new Promise((resolve, reject) => options.signal.addEventListener('abort', () => reject(Object.assign(new Error(), {name: 'AbortError'}))));
    }}, ['api']);
    await assert.rejects(() => ctx.api('/api/config', null, null, {timeout: 1}), /超时/);
  });

  await test('time_input_rejects_empty_or_invalid_clock_values', async () => {
    const ctx = make({}, ['parseTime']);
    for (const value of ['', ' ', '00:60:01', '00:01:60', '1:99', 'Infinity']) assert.equal(ctx.parseTime(value), null);
    assert.equal(ctx.parseTime('00:01:02,250'), 62.25);
    assert.equal(ctx.parseTime('62.25'), 62.25);
  });

  await test('default_audio_gain_is_louder_and_volume_controls_it', async () => {
    const peaks = [];
    class AudioMock {
      constructor() {this.currentTime = 1; this.state = 'running'; this.destination = {};}
      createOscillator() {return {frequency: {setValueAtTime() {}}, connect() {}, start() {}, stop() {}};}
      createGain() {return {gain: {setValueAtTime() {}, exponentialRampToValueAtTime(value) {if (value > .001) peaks.push(value);}}, connect() {}};}
    }
    const ctx = make({window: {AudioContext: AudioMock}, audioContext: null, lastTick: 0}, ['playSound']);
    ctx.playSound('key'); assert(Math.abs(peaks.at(-1) - .176) < .00001);
    ctx.state.settings.volume = 20; ctx.playSound('key'); assert(Math.abs(peaks.at(-1) - .044) < .00001);
    const count = peaks.length; ctx.state.settings.volume = 0; ctx.playSound('success'); assert.equal(peaks.length, count);
  });

  await test('short_cue_drag_stays_positive_and_unlocks_on_lost_capture', async () => {
    const handlers = {};
    const canvas = {getBoundingClientRect: () => ({left: 0, width: 100}), addEventListener: (name, fn) => {handlers[name] = fn;},
      setPointerCapture() {}, hasPointerCapture: () => false, releasePointerCapture() {}};
    const ctx = make({video: {currentTime: 0}, renderAlignmentInspector() {}}, ['waveWindow', 'bindWaveCanvas']);
    ctx.state.media.duration = .005; ctx.state.settings.mode = 'align'; ctx.state.selected = 0;
    ctx.state.cues = [{start: 0, end: .005, text: '短'}];
    ctx.bindWaveCanvas(canvas);
    handlers.pointerdown({clientX: 100, pointerId: 1});
    handlers.pointermove({clientX: -100, pointerId: 1});
    assert(ctx.state.cues[0].end > 0 && ctx.state.cues[0].end <= .005);
    handlers.lostpointercapture({pointerId: 1}); assert.equal(ctx.state.operation, '');
  });

  await test('stale_zoom_waveform_does_not_replace_current_media', async () => {
    let release;
    const ctx = make({api: () => new Promise(resolve => {release = resolve;})}, ['waveWindow', 'requestWaveDetail']);
    ctx.state.detailWaveEpoch = 0; ctx.state.media.duration = 20; ctx.state.waveSpan = 4; ctx.state.waveStart = 5;
    ctx.requestWaveDetail(); await new Promise(resolve => setTimeout(resolve, 5));
    ctx.state.mediaEpoch++; ctx.state.media = {path: 'B.wav', duration: 20}; ctx.state.detailWave = {tag: 'B'};
    release({start: 5, end: 9, peaks: [1]}); await new Promise(resolve => setTimeout(resolve, 5));
    assert.equal(ctx.state.detailWave.tag, 'B');
  });

  return {total: results.length, all_passed: results.every(r => r.passed), results};
}
