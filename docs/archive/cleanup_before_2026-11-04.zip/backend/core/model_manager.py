"""固定模型目录、可续传下载和隔离运行环境；只有用户点击下载才联网。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import threading
import time
from urllib.parse import quote
from urllib.request import Request, urlopen
import venv

from .paths import MODELS_DIR, DATA_DIR
from .storage import atomic_json

CATALOG = {
    "large-v3": {"label": "Whisper large-v3", "engine": "whisper", "repo": "Systran/faster-whisper-large-v3", "size_hint": "约 3 GB", "description": "多语言字幕提取，通用高精度，支持词级时间戳。"},
    "large-v3-turbo": {"label": "Whisper large-v3-turbo", "engine": "whisper", "repo": "mobiuslabsgmbh/faster-whisper-large-v3-turbo", "size_hint": "约 1.6 GB", "description": "多语言字幕提取，速度更快。"},
    "fireredasr2-aed": {"label": "FireRedASR2-AED", "engine": "firered", "repo": "FireRedTeam/FireRedASR2-AED", "size_hint": "约 4.5 GB", "description": "中文字幕提取，支持词级时间戳。"},
    "qwen3-asr-1.7b": {"label": "Qwen3-ASR-1.7B", "engine": "qwen", "repo": "Qwen/Qwen3-ASR-1.7B", "size_hint": "约 3.5 GB", "description": "中文、方言、多语言识别；当前时间戳为分块估计。"},
    "paraformer-zh": {"label": "paraformer-zh", "engine": "paraformer", "repo": "funasr/paraformer-zh", "size_hint": "约 0.9 GB", "description": "测试模型。"},
}
AUXILIARY = {
    "qwen3-forcedaligner-0.6b": {"label": "Qwen3-ForcedAligner-0.6B", "engine": "qwen", "repo": "Qwen/Qwen3-ForcedAligner-0.6B", "size_hint": "约 1.2 GB", "description": "将当前字幕文字精确对齐到视频音轨，不改写字幕。"},
    "silero-vad": {"label": "Silero VAD", "engine": "builtin", "repo": "", "size_hint": "已内置", "description": "语音区间检测和静音过滤，随 faster-whisper 内置，无需重复下载。"},
}
ALL_MODELS = {**CATALOG, **AUXILIARY}
RUNTIME_PACKAGES = {
    "firered": ["https://github.com/FireRedTeam/FireRedASR2S/archive/refs/heads/main.zip"],
    "qwen": ["qwen-asr==0.0.6"],
    "paraformer": ["funasr>=1.3,<2", "torch", "torchaudio", "soundfile", "huggingface_hub"],
}
ENGINE_DIR = DATA_DIR / "engines"


def runtime_python(engine):
    return ENGINE_DIR / engine / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def runtime_ready(engine):
    return engine in ("whisper", "builtin") or (runtime_python(engine).is_file() and (ENGINE_DIR / engine / "ready.json").is_file())


def weights_present(name):
    directory = MODELS_DIR / name
    spec = ALL_MODELS.get(name)
    if not spec:
        return False
    if spec["engine"] == "builtin":
        from importlib.util import find_spec
        package = find_spec("faster_whisper")
        return bool(package and package.origin and (Path(package.origin).parent / "assets" / "silero_vad_v6.onnx").is_file())
    if spec["engine"] == "whisper":
        return (directory / "model.bin").is_file()
    manifest = directory / ".studio-model.json"
    try:
        files = json.loads(manifest.read_text(encoding="utf-8"))["files"]
        return bool(files) and all((directory / f["name"]).is_file() and (directory / f["name"]).stat().st_size == f["size"] for f in files)
    except (OSError, ValueError, KeyError, TypeError):
        return False


class DownloadCancelled(Exception):
    pass


class ModelDownloads:
    def __init__(self):
        self.lock = threading.RLock()
        self.cancel_event = threading.Event()
        self.status = {"status": "idle", "progress": 0, "message": "等待任务", "model": ""}

    def get(self):
        with self.lock:
            return dict(self.status)

    def update(self, **changes):
        with self.lock:
            self.status.update(changes)

    def start(self, name):
        if not isinstance(name, str) or name not in ALL_MODELS or ALL_MODELS[name]["engine"] == "builtin":
            raise ValueError("未知模型，不能下载任意外部地址")
        with self.lock:
            if self.status["status"] in ("downloading", "preparing"):
                if self.status["model"] == name:
                    return self.get()
                raise ValueError("已有模型下载任务，请先完成或取消")
            self.cancel_event = threading.Event()
            self.status = {"status": "downloading", "model": name, "progress": 0,
                           "message": "正在查询官方模型文件…", "downloaded": 0, "total": 0, "error": ""}
            threading.Thread(target=self._run, args=(name,), daemon=True, name="model-download").start()
            return self.get()

    def cancel(self):
        self.cancel_event.set()
        return self.get()

    def check(self):
        if self.cancel_event.is_set():
            raise DownloadCancelled()

    def _sha256(self, path):
        hasher = hashlib.sha256()
        with path.open('rb') as stream:
            while block := stream.read(1024 * 1024):
                self.check()
                hasher.update(block)
        return hasher.hexdigest()

    @staticmethod
    def _request(url, headers=None):
        return urlopen(Request(url, headers={"User-Agent": "SubtitleStudio/2.1", **(headers or {})}), timeout=30)

    def _files(self, name):
        repo = ALL_MODELS[name]["repo"]
        with self._request(f"https://huggingface.co/api/models/{repo}?blobs=true") as response:
            info = json.load(response)
        files = []
        for item in info.get("siblings", []):
            filename = item["rfilename"]
            path = PurePosixPath(filename)
            if path.is_absolute() or ".." in path.parts or "\\" in filename or ":" in filename:
                raise ValueError("模型仓库文件名无效")
            if filename.startswith((".", "assets/", "examples/", "onnx/")) or filename.lower().endswith((".md", ".png", ".jpg", ".wav", ".mp3", ".onnx")):
                continue
            size = item.get("size") or item.get("lfs", {}).get("size") or 0
            files.append({"name": filename, "size": int(size), "sha256": item.get("lfs", {}).get("sha256")})
        if not files:
            raise RuntimeError("官方仓库没有可下载文件")
        return info.get("sha") or "main", files

    def _download_file(self, name, revision, item, completed, total):
        directory = MODELS_DIR / name
        target = directory.joinpath(*PurePosixPath(item["name"]).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        expected = item["size"]
        if target.exists() and expected and target.stat().st_size == expected:
            return
        partial = target.with_name(target.name + ".part")
        offset = partial.stat().st_size if partial.exists() else 0
        if expected and offset == expected:
            digest = item.get("sha256")
            if not digest or self._sha256(partial) == digest:
                os.replace(partial, target)
                return
            partial.unlink(missing_ok=True)
        elif expected and offset > expected:
            partial.unlink(missing_ok=True)
        url = f"https://huggingface.co/{ALL_MODELS[name]['repo']}/resolve/{revision}/{quote(item['name'], safe='/')}"
        for attempt in range(3):
            self.check()
            try:
                offset = partial.stat().st_size if partial.exists() else 0
                headers = {"Range": f"bytes={offset}-"} if offset else {}
                with self._request(url, headers) as response:
                    if response.status != 206:
                        offset = 0
                    with partial.open("ab" if offset else "wb") as stream:
                        while True:
                            self.check()
                            data = response.read(1024 * 1024)
                            if not data:
                                break
                            stream.write(data)
                            offset += len(data)
                            self.update(downloaded=completed + offset, total=total,
                                        progress=min(.88, (completed + offset) / max(1, total) * .88),
                                        message="下载 " + ALL_MODELS[name]["label"] + " · " + item["name"])
                if expected and offset != expected:
                    raise RuntimeError("文件长度不完整，保留下载片段以便重试")
                digest = item.get("sha256")
                if digest:
                    if self._sha256(partial) != digest:
                        partial.unlink(missing_ok=True)
                        raise RuntimeError("模型文件校验失败，已移除损坏片段")
                os.replace(partial, target)
                return
            except DownloadCancelled:
                raise
            except Exception:
                if attempt == 2:
                    raise
                self.cancel_event.wait(1 + attempt)

    def _prepare(self, engine):
        if runtime_ready(engine):
            return
        self.update(status="preparing", progress=.9, message="模型已下载，正在准备独立识别环境…")
        location = ENGINE_DIR / engine
        venv.EnvBuilder(with_pip=True).create(location)
        self.check()
        log = location / "install.log"
        packages = RUNTIME_PACKAGES[engine]
        command = [str(runtime_python(engine)), "-m", "pip", "install", "--disable-pip-version-check", *packages]
        with log.open("w", encoding="utf-8") as output:
            process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            try:
                while process.poll() is None:
                    self.check()
                    self.update(message="安装 " + engine + " 依赖中，进度以安装输出为准…")
                    self.cancel_event.wait(.5)
                if process.returncode:
                    raise RuntimeError("模型已保存，但依赖安装失败，可重试。安装日志：" + str(log))
            finally:
                if process.poll() is None:
                    process.terminate(); process.wait(timeout=10)
        atomic_json(location / "ready.json", {"engine": engine, "packages": packages, "prepared": time.time()})

    def _run(self, name):
        try:
            revision, files = self._files(name)
            directory = MODELS_DIR / name
            directory.mkdir(parents=True, exist_ok=True)
            marker = directory / '.studio-downloading'
            marker.touch()
            total = sum(item["size"] for item in files)
            MODELS_DIR.mkdir(parents=True, exist_ok=True)
            remaining = sum(max(0, item["size"] - (MODELS_DIR / name / item["name"]).stat().st_size) if (MODELS_DIR / name / item["name"]).exists() else item["size"] for item in files)
            if total and shutil.disk_usage(MODELS_DIR).free < remaining + 512 * 1024**2:
                raise RuntimeError("模型目录磁盘空间不足，请释放空间后重试")
            completed = 0
            for item in files:
                self.check()
                self._download_file(name, revision, item, completed, total)
                completed += item["size"]
            for item in files:
                item["size"] = (MODELS_DIR / name / item["name"]).stat().st_size
            atomic_json(MODELS_DIR / name / ".studio-model.json", {"repo": ALL_MODELS[name]["repo"], "revision": revision, "files": files})
            marker.unlink(missing_ok=True)
            self.check()
            self._prepare(ALL_MODELS[name]["engine"])
            self.check()
            self.update(status="done", progress=1, message=ALL_MODELS[name]["label"] + " 已就绪", downloaded=total, total=total)
        except DownloadCancelled:
            self.update(status="cancelled", message="下载已暂停，文件片段保留，点击下载可继续")
        except Exception as error:
            self.update(status="error", error=str(error), message="模型下载失败：" + str(error))


DOWNLOADS = ModelDownloads()


def list_auxiliary():
    result = []
    for name, spec in AUXILIARY.items():
        downloaded = weights_present(name)
        result.append({"name": name, **spec, "downloaded": downloaded,
                       "available": downloaded and runtime_ready(spec["engine"]), "runtime_ready": runtime_ready(spec["engine"])})
    return result
