"""后台识别任务：单 worker 队列、进度、取消、结果落盘。"""
from __future__ import annotations

import json
import queue
import threading
import time
import traceback
import uuid
from pathlib import Path

from .asr import Cancelled, transcribe
from .paths import RESULTS_DIR
from .segment import split_on_gaps
from .storage import atomic_json
from .srt_io import format_srt


class Job:
    def __init__(self, path: str, model: str, device: str, vad: bool, gap_seconds: float = 0.6):
        self.id = uuid.uuid4().hex[:12]
        self.path = path
        self.model = model
        self.device = device
        self.vad = vad
        self.gap_seconds = gap_seconds
        self.status = "queued"       # queued/running/done/error/cancelled
        self.progress = 0.0
        self.message = "排队中"
        self.error = ""
        self.subtitle_path = ""
        self.task = "asr"
        self.input_cues = []
        self.cues: list[dict] = []
        self.info: dict = {}
        self.created = time.time()
        self.started = 0.0
        self.finished = 0.0
        self.cancel_event = threading.Event()

    def to_dict(self, include_cues: bool = True) -> dict:
        data = {
            "id": self.id,
            "path": self.path,
            "model": self.model,
            "device": self.device,
            "gap_seconds": self.gap_seconds,
            "status": self.status,
            "progress": round(self.progress, 3),
            "message": self.message,
            "error": self.error,
            "subtitle_path": self.subtitle_path,
            "task": self.task,
            "created": self.created,
            "started": self.started,
            "finished": self.finished,
        }
        if include_cues:
            data["cues"] = self.cues
            data["info"] = self.info
        return data


class JobManager:
    def __init__(self) -> None:
        self.jobs: dict[str, Job] = {}
        self.lock = threading.Lock()
        self.queue: queue.Queue[Job] = queue.Queue()
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        threading.Thread(target=self._worker, daemon=True, name="asr-worker").start()

    def submit(self, path: str, model: str, device: str, vad: bool, gap_seconds: float = 0.6,
               request_id: str | None = None, task: str = "asr", input_cues: list | None = None) -> Job:
        job = Job(path, model, device, vad, gap_seconds)
        job.task = task
        job.input_cues = input_cues or []
        with self.lock:
            if request_id and request_id in self.jobs:
                previous = self.jobs[request_id]
                if (previous.path, previous.model, previous.device, previous.vad, previous.gap_seconds, previous.task, previous.input_cues) != (path, model, device, vad, gap_seconds, task, input_cues or []):
                    raise ValueError("同一任务标识不能提交不同素材或参数")
                return previous
            if request_id:
                job.id = request_id
            self.jobs[job.id] = job
        self.queue.put(job)
        return job

    def get(self, job_id: str) -> Job | None:
        with self.lock:
            return self.jobs.get(job_id)

    def cancel(self, job_id: str) -> Job | None:
        job = self.get(job_id)
        if job is None:
            return None
        job.cancel_event.set()
        if job.status == "queued":
            job.status = "cancelled"
            job.message = "已取消"
            job.finished = time.time()
        return job

    def _worker(self) -> None:
        while True:
            job = self.queue.get()
            job.status = "running"
            job.started = time.time()

            def on_progress(ratio: float, message: str) -> None:
                job.progress = ratio
                job.message = message

            try:
                if job.cancel_event.is_set():
                    raise Cancelled()
                if job.task == "align":
                    from .alignment import align_cues
                    cues, info = align_cues(job.path, job.input_cues, job.device, on_progress, job.cancel_event)
                else:
                    cues, info = transcribe(
                        job.path, job.model, job.device, job.vad,
                        on_progress=on_progress, cancel_event=job.cancel_event,
                    )
                if job.cancel_event.is_set():
                    job.status = "cancelled"
                    job.message = "已取消"
                else:
                    for cue in cues:
                        cue.setdefault("asr_original", {"text": cue["text"], "start": cue["start"],
                                                       "end": cue["end"], "id": cue.get("id")})
                    if job.gap_seconds > 0 and job.task == "asr":
                        cues, gap_splits = split_on_gaps(cues, job.gap_seconds)
                        info["gap_splits"] = gap_splits
                    for cue in cues:
                        cue.setdefault("original_text", cue["text"])
                        cue.setdefault("original_start", cue["start"])
                        cue.setdefault("original_end", cue["end"])
                    job.cues = cues
                    job.info = info
                    if job.cancel_event.is_set():
                        raise Cancelled()
                    job.progress = 1.0
                    job.message = "完成"
                    job.finished = time.time()
                    self._save(job)
                    job.status = "done"
            except Cancelled:
                job.status = "cancelled"
                job.message = "已取消"
            except Exception as exc:
                job.status = "error"
                job.error = str(exc)
                job.message = str(exc)
                traceback.print_exc()
            finally:
                job.finished = time.time()
                self.queue.task_done()

    def _save(self, job: Job) -> None:
        # A task-specific SRT keeps the extraction available for alignment,
        # independent of final export formatting and noise filters.
        subtitle = RESULTS_DIR / job.id / (Path(job.path).stem + ".srt")
        subtitle.parent.mkdir(parents=True, exist_ok=True)
        subtitle.write_text(format_srt(job.cues), encoding="utf-8", newline="")
        job.subtitle_path = str(subtitle)
        path = RESULTS_DIR / f"{job.id}.json"
        data = job.to_dict()
        data["status"] = "done"
        atomic_json(path, data)
