"""剧本解析、与 ASR 结果模糊匹配。"""
from __future__ import annotations

import re
import zipfile
import xml.etree.ElementTree as ET
from difflib import SequenceMatcher
from pathlib import Path

SCENE_RE = re.compile(
    r"^\s*(第\s*[0-9一二三四五六七八九十百]+\s*[集场幕]|"
    r"[0-9]+\s*[-—]\s*[0-9]+|场\s*[0-9]+|SC\s*\d+)",
    re.IGNORECASE,
)
ROLE_RE = re.compile(
    r"^\s*([^：:]{1,24}?)\s*(?:[（(]([^）)]{0,40})[）)])?\s*[：:]\s*(.+?)\s*$"
)
MARKDOWN_RE = re.compile(r"(\*\*|__|\*|`)")
SKIP_PREFIX = ("△", "▲", "【", "[", "（", "(", "#", ">", "|", "字幕", "音效", "BGM", "bgm")
NOISE_ROLES = {"音效", "BGM", "bgm", "字幕", "画面", "镜头"}


def _docx_text(path: str) -> str:
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    lines: list[str] = []
    for p in root.iter(f"{ns}p"):
        line = "".join(t.text or "" for t in p.iter(f"{ns}t")).strip()
        if line:
            lines.append(line)
    return "\n".join(lines)


def read_script_text(path: str) -> tuple[str, str]:
    suffix = Path(path).suffix.lower()
    if suffix == ".docx":
        return _docx_text(path), "docx"
    if suffix == ".doc":
        raise RuntimeError("暂不支持 .doc，请另存为 .docx 或 .txt")
    from .srt_io import read_text
    return read_text(path)


def parse_script_text(text: str) -> list[dict]:
    """解析 `角色:台词` / `角色（提示）:台词` / `待确认:台词`。"""
    lines: list[dict] = []
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = MARKDOWN_RE.sub("", raw).strip()
        if not line:
            continue
        if SCENE_RE.match(line) or "｜" in line:
            continue
        if line.startswith(SKIP_PREFIX):
            continue
        if line in ("---", "***", "___"):
            continue

        m = ROLE_RE.match(line)
        if not m:
            continue
        role = m.group(1).strip()
        note = (m.group(2) or "").strip()
        content = m.group(3).strip()
        if not content or role in NOISE_ROLES:
            continue
        if len(role) > 20 or re.search(r"\d{1,2}:\d{2}", role):
            continue
        if content.startswith(("【", "△", "▲")):
            continue

        kind = "dialogue"
        if role in ("旁白", "画外音", "OS", "os"):
            kind = "narration"
        elif role == "待确认":
            kind = "unconfirmed"

        lines.append({
            "index": len(lines),
            "source_line": lineno,
            "role": role,
            "note": note,
            "text": content,
            "kind": kind,
            "cue_index": None,
        })

    for i, item in enumerate(lines):
        item["index"] = i
    return lines


def script_stats(lines: list[dict]) -> dict:
    roles = sorted({ln["role"] for ln in lines if ln["role"]})
    counts = {r: sum(1 for ln in lines if ln["role"] == r) for r in roles}
    return {
        "total": len(lines),
        "dialogue": sum(1 for ln in lines if ln["kind"] == "dialogue"),
        "narration": sum(1 for ln in lines if ln["kind"] == "narration"),
        "roles": counts,
        "matched": sum(1 for ln in lines if ln.get("cue_index") is not None),
    }


def _normalize(s: str) -> str:
    s = re.sub(r"[\s，。！？；：、,.!?;:\"'“”‘’（）()《》【】\[\]…—\-]+", "", s or "")
    return s.lower()


def match_script(cues: list[dict], lines: list[dict], *, window: int = 14,
                 threshold: float = 0.34) -> dict:
    """按顺序在时间轴窗口内为本行剧本找最相似的字幕，结果写回 cues / lines。"""
    for cue in cues:
        cue.pop("script_text", None)
        cue.pop("script_index", None)
        cue.pop("match_ratio", None)
        # 匹配提醒独立于ASR/人工校对提醒；重匹配不抹掉后者。
        cue.pop("match_needs_review", None)

    cursor = 0
    hits: list[dict] = []
    for line in lines:
        line["cue_index"] = None
        if line["kind"] == "unconfirmed":
            # 待确认行同样参与匹配，但允许更低阈值
            pass
        ns = _normalize(line["text"])
        if not ns:
            continue
        lo = cursor
        hi = min(len(cues), cursor + window)
        best_ratio = 0.0
        best_idx = None
        for j in range(lo, hi):
            nc = _normalize(cues[j].get("text", ""))
            if not nc:
                continue
            ratio = SequenceMatcher(None, nc, ns).ratio()
            if nc in ns or ns in nc:
                ratio = max(ratio, 0.75)
            # 长度差太大时降权，避免一句短台词吸走长句
            if min(len(nc), len(ns)) / max(len(nc), len(ns)) < 0.35:
                ratio *= 0.75
            if ratio > best_ratio:
                best_ratio, best_idx = ratio, j
        limit = threshold if line["kind"] != "unconfirmed" else max(0.25, threshold - 0.08)
        if best_idx is None or best_ratio < limit:
            # 局部未命中时在剩余时间轴重新定位；仍保持严格单调和唯一占用。
            for j in range(hi, len(cues)):
                nc = _normalize(cues[j].get("text", ""))
                if not nc:
                    continue
                ratio = SequenceMatcher(None, nc, ns).ratio()
                if nc in ns or ns in nc:
                    ratio = max(ratio, 0.75)
                if min(len(nc), len(ns)) / max(len(nc), len(ns)) < 0.35:
                    ratio *= 0.75
                if ratio > best_ratio:
                    best_ratio, best_idx = ratio, j
        if best_idx is None or best_ratio < limit:
            continue

        cue = cues[best_idx]
        cue["script_text"] = line["text"]
        cue["role"] = line["role"]
        cue["match_ratio"] = round(best_ratio, 3)
        cue["script_index"] = line["index"]
        cue["match_needs_review"] = best_ratio < 0.55
        line["cue_index"] = best_idx
        cursor = best_idx + 1
        hits.append({"script_index": line["index"], "cue_index": best_idx, "ratio": round(best_ratio, 3)})

    ratios = [h["ratio"] for h in hits]
    stats = {
        "matched": len(hits),
        "total": len(lines),
        "avg_ratio": round(sum(ratios) / len(ratios), 3) if ratios else 0,
        "low_confidence": sum(1 for r in ratios if r < 0.55),
    }
    return {"cues": cues, "lines": lines, "stats": stats, "hits": hits}
