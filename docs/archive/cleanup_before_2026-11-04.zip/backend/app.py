r"""字幕工作室后端：标准库 HTTP 服务 + JSON API + Range 视频流。

启动：.venv\Scripts\python.exe backend\app.py [--port 8765] [--no-browser]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import os
import re
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from core import media, script, segment, srt_io, reference_match  # noqa: E402
from core.asr import list_models  # noqa: E402
from core.jobs import JobManager  # noqa: E402
from core import validation  # noqa: E402
from core.model_manager import DOWNLOADS, list_auxiliary  # noqa: E402
from core.storage import WRITE_LOCK, atomic_json, locked_file  # noqa: E402
from core.paths import (  # noqa: E402
    CONFIG_DIR, DATA_DIR, FRONTEND_DIR, OUTPUTS_DIR, PROJECTS_DIR, UPLOADS_DIR,
)

WEB_DIR = FRONTEND_DIR
OUTPUT_DIR = OUTPUTS_DIR
PROJECT_DIR = PROJECTS_DIR

VERSION = "2.1.0"
SESSION_TOKEN = secrets.token_urlsafe(32)
DIALOG_LOCK = threading.Lock()
MAX_BODY = 64 * 1024 * 1024
MAX_UPLOAD = 20 * 1024 ** 3
MAX_GAP_SECONDS = 2.0
MIN_WIDTH = 6.0
MAX_WIDTH = 30.0
JOBS = JobManager()


class RevisionConflict(ValueError):
    pass


def _qget(query: dict, key: str, default: str = "") -> str:
    vals = query.get(key)
    return vals[0] if vals else default


def _clean_path(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("文件路径必须是字符串")
    value = (value or "").strip().strip('"').strip("'")
    if not value:
        raise ValueError("缺少文件路径")
    return os.path.abspath(os.path.expandvars(os.path.expanduser(value)))


def _require_file(value: str) -> str:
    path = _clean_path(value)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"文件不存在：{path}")
    return path


def _project_path(media_path: str) -> Path:
    key = hashlib.sha1(os.path.abspath(media_path).encode("utf-8")).hexdigest()[:16]
    return PROJECT_DIR / f"{key}.json"


def _config_file() -> Path:
    return CONFIG_DIR / "ui.json"


def _read_config() -> dict:
    target = _config_file()
    if not target.exists():
        return {}
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _safe_filename(value: str) -> str:
    name = str(value or "").replace("\\", "/").rsplit("/", 1)[-1].strip()
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    if not name:
        return "upload"
    suffix = Path(name).suffix[:12]
    stem = Path(name).stem[:96] or "upload"
    return stem + suffix


def _output_path(media_path: str, out_dir: str | None, overwrite: bool) -> Path:
    if media_path:
        media_path = os.path.abspath(media_path)
        stem = Path(media_path).stem
        folder = _clean_path(out_dir) if out_dir else str(Path(media_path).parent)
    else:
        stem = "字幕_" + time.strftime("%Y%m%d_%H%M%S")
        folder = _clean_path(out_dir) if out_dir else str(OUTPUT_DIR)
    os.makedirs(folder, exist_ok=True)
    target = Path(folder) / f"{stem}.srt"
    if not overwrite and target.exists():
        i = 2
        while (Path(folder) / f"{stem}_{i}.srt").exists():
            i += 1
        target = Path(folder) / f"{stem}_{i}.srt"
    return target


class Handler(BaseHTTPRequestHandler):
    server_version = f"SubtitleStudio/{VERSION}"
    protocol_version = "HTTP/1.1"

    def _check_request(self) -> bool:
        allowed = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
        hosts = self.headers.get_all("Host", [])
        origin = self.headers.get("Origin")
        if (len(hosts) != 1 or hosts[0].lower() not in allowed
                or (origin is not None and origin not in {f"http://{h}" for h in allowed})
                or self.headers.get("Sec-Fetch-Site") == "cross-site"):
            self.close_connection = True
            self.send_json({"ok": False, "error": "拒绝非本机页面请求"}, 403)
            return False
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/"):
            token = self.headers.get("X-SubtitleStudio-Token", "")
            if parsed.path == "/api/media/stream":
                token = token or _qget(parse_qs(parsed.query), "token")
            if not token.isascii() or not secrets.compare_digest(token, SESSION_TOKEN):
                self.close_connection = True
                self.send_json({"ok": False, "error": "页面会话已失效，请刷新页面"}, 403)
                return False
        return True

    def do_OPTIONS(self) -> None:
        self.close_connection = True
        self.send_json({"ok": False, "error": "不允许跨来源调用"}, 403)

    def setup(self) -> None:
        super().setup()
        self.connection.settimeout(30)

    # ---------- 基础响应 ----------
    def send_json(self, data: dict, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_bytes(self, body: bytes, content_type: str, status: int = 200,
                   extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_file(self, path: str, content_type: str | None = None) -> None:
        # 先打开文件；发头之后的读错误只能关闭连接，不能再发送第二份JSON响应。
        with open(path, "rb") as stream:
            self._send_open_file(stream, content_type or media.content_type(path))

    def _send_open_file(self, stream, content_type: str) -> None:
        file_size = os.fstat(stream.fileno()).st_size
        start, end = 0, file_size - 1
        status = 200
        range_header = self.headers.get("Range", "")
        if range_header:
            m = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
            valid = bool(m and (m.group(1) or m.group(2)) and file_size)
            if valid:
                if m.group(1):
                    start = int(m.group(1))
                    end = min(int(m.group(2)), file_size - 1) if m.group(2) else file_size - 1
                else:
                    suffix = int(m.group(2))
                    start, end = max(0, file_size - suffix), file_size - 1
                    valid = suffix > 0
                valid = valid and start < file_size and start <= end
            if not valid:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{file_size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            status = 206
        length = max(0, end - start + 1)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-cache")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{file_size}")
        self.end_headers()
        try:
            stream.seek(start)
            remaining = length
            while remaining > 0:
                chunk = stream.read(min(256 * 1024, remaining))
                if not chunk:
                    self.close_connection = True
                    break
                self.wfile.write(chunk)
                remaining -= len(chunk)
        except OSError:
            self.close_connection = True

    def read_json(self) -> dict:
        self.close_connection = True  # 非法/未读完的请求不复用连接。
        if self.headers.get("Transfer-Encoding"):
            raise ValueError("不支持Transfer-Encoding")
        if len(self.headers.get_all("Content-Length", [])) > 1:
            raise ValueError("重复Content-Length")
        length = int(self.headers.get("Content-Length") or 0)
        if length < 0:
            raise ValueError("Content-Length不能为负数")
        if length <= 0:
            return {}
        if length > MAX_BODY:
            raise ValueError("请求体过大")
        if self.headers.get_content_type() != "application/json":
            raise ValueError("请求体必须为application/json")
        raw = self.rfile.read(length)
        try:
            if len(raw) != length:
                raise ValueError("请求体不完整")
            data = json.loads(raw.decode("utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError("禁止非有限数字")))
        except Exception as exc:
            raise ValueError(f"JSON 解析失败：{exc}") from exc
        if not isinstance(data, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return data

    def log_message(self, fmt: str, *args) -> None:
        # 轮询与静态资源不刷屏，仅记录错误
        if self.path.startswith("/api/jobs/"):
            return
        if self.command == "GET" and not self.path.startswith("/api/"):
            return
        sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

    # ---------- 路由 ----------
    def do_GET(self) -> None:
        if not self._check_request():
            return
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        try:
            if path == "/" or path == "/index.html":
                self._static("index.html")
            elif path == "/favicon.ico":
                self._static("assets/studio-film.ico")
            elif not path.startswith("/api/"):
                self._static(unquote(path).lstrip("/"))
            elif path == "/api/health":
                self.send_json({"ok": True, "version": VERSION, "python": sys.version.split()[0],
                                "models": list_models(), "auxiliary": list_auxiliary(), "data_dir": str(DATA_DIR)})
            elif path == "/api/models":
                self.send_json({"ok": True, "models": list_models(), "auxiliary": list_auxiliary()})
            elif path == "/api/models/download":
                self.send_json({"ok": True, "download": DOWNLOADS.get()})
            elif path == "/api/config":
                self.send_json({"ok": True, "config": _read_config(), "path": str(_config_file())})
            elif path == "/api/media/info":
                p = _require_file(_qget(query, "path"))
                self.send_json({"ok": True, "info": media.probe(p)})
            elif path == "/api/media/stream":
                p = _require_file(_qget(query, "path"))
                if not media.is_media(p):
                    raise ValueError("不支持的媒体格式")
                self.send_file(p)
            elif path == "/api/waveform":
                p = _require_file(_qget(query, "path"))
                buckets = int(_qget(query, "buckets", "1200") or 1200)
                if "start" in query or "end" in query:
                    start = validation.number(float(_qget(query, "start")), "波形开始")
                    end = validation.number(float(_qget(query, "end")), "波形结束")
                    result = media.waveform_region(p, start, end, buckets)
                else:
                    result = media.waveform(p, buckets)
                self.send_json({"ok": True, **result})
            elif path == "/api/projects/load":
                p = _require_file(_qget(query, "path"))
                proj_file = _project_path(p)
                if proj_file.exists():
                    project = validation.mapping(json.loads(proj_file.read_text(encoding="utf-8")), "工程")
                    validation.cues(project.get("cues", []))
                    validation.lines(project.get("script_lines", []))
                    validation.mapping(project.get("settings", {}), "工程settings")
                    self.send_json({"ok": True, "project": project})
                else:
                    self.send_json({"ok": True, "project": None})
            elif re.match(r"^/api/jobs/[a-f0-9]+$", path):
                job = JOBS.get(path.rsplit("/", 1)[-1])
                if job is None:
                    self.send_json({"ok": False, "error": "任务不存在"}, 404)
                else:
                    self.send_json({"ok": True, "job": job.to_dict(include_cues=_qget(query, "result") == "1")})
            else:
                self.send_json({"ok": False, "error": "接口不存在"}, 404)
        except FileNotFoundError as exc:
            self.send_json({"ok": False, "error": str(exc)}, 404)
        except RevisionConflict as exc:
            self.send_json({"ok": False, "error": str(exc)}, 409)
        except ValueError as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)
        except Exception as exc:  # pragma: no cover
            self.send_json({"ok": False, "error": f"服务器错误：{exc}"}, 500)

    def do_POST(self) -> None:
        if not self._check_request():
            return
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            if path == "/api/upload":
                self._upload(parse_qs(parsed.query))
                return
            body = self.read_json()
            if path == "/api/jobs":
                self._create_job(body)
            elif path == "/api/alignment/jobs":
                if DOWNLOADS.get()["status"] in ("downloading", "preparing"):
                    raise ValueError("请先完成模型下载")
                path = _require_file(body.get("path", ""))
                if not media.is_media(path):
                    raise ValueError("需要视频或音频素材")
                cues = validation.cues(body.get("cues", []))
                if not cues:
                    raise ValueError("请先导入或识别字幕")
                if not any(m["name"] == "qwen3-forcedaligner-0.6b" and m["available"] for m in list_auxiliary()):
                    raise ValueError("请先在辅模菜单下载 Qwen3-ForcedAligner-0.6B")
                device = body.get("device", "auto")
                if device not in ("auto", "cpu", "cuda"):
                    raise ValueError("设备无效")
                request_id = body.get("request_id")
                if not isinstance(request_id, str) or not re.fullmatch(r"[a-f0-9]{12,32}", request_id):
                    raise ValueError("任务标识无效")
                job = JOBS.submit(path, "qwen3-forcedaligner-0.6b", device, False, 0, request_id, task="align", input_cues=cues)
                self.send_json({"ok": True, "job": job.to_dict(include_cues=False)})
            elif path == "/api/models/download":
                if any(job.status in ("queued", "running") for job in list(JOBS.jobs.values())):
                    raise ValueError("请先完成或取消识别任务，再下载模型")
                self.send_json({"ok": True, "download": DOWNLOADS.start(body.get("model", ""))})
            elif path == "/api/models/cancel":
                self.send_json({"ok": True, "download": DOWNLOADS.cancel()})
            elif re.match(r"^/api/jobs/[a-f0-9]+/cancel$", path):
                job = JOBS.cancel(path.split("/")[3])
                if job is None:
                    self.send_json({"ok": False, "error": "任务不存在"}, 404)
                else:
                    self.send_json({"ok": True, "job": job.to_dict(include_cues=False)})
            elif path == "/api/srt/parse":
                self._parse_srt(body)
            elif path == "/api/srt/export":
                self._export_srt(body)
            elif path == "/api/script/parse":
                self._parse_script(body)
            elif path == "/api/script/match":
                self._match_script(body)
            elif path == "/api/segment":
                self._segment(body)
            elif path == "/api/segment/merge":
                self._merge(body)
            elif path == "/api/projects/save":
                self._save_project(body)
            elif path == "/api/config":
                self._save_config(body)
            elif path == "/api/dialog":
                self._dialog(body)
            elif path == "/api/open_folder":
                p = _clean_path(body.get("path", ""))
                media.open_path(p)
                self.send_json({"ok": True})
            else:
                self.send_json({"ok": False, "error": "接口不存在"}, 404)
        except FileNotFoundError as exc:
            self.send_json({"ok": False, "error": str(exc)}, 404)
        except RevisionConflict as exc:
            self.send_json({"ok": False, "error": str(exc)}, 409)
        except ValueError as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)
        except Exception as exc:  # pragma: no cover
            self.send_json({"ok": False, "error": f"服务器错误：{exc}"}, 500)

    # ---------- 静态文件 ----------
    def _static(self, name: str) -> None:
        if name == "favicon.ico":
            self._static("assets/studio-film.ico")
            return
        target = (WEB_DIR / name).resolve()
        if WEB_DIR.resolve() not in target.parents or not target.is_file():
            self.send_json({"ok": False, "error": "页面不存在"}, 404)
            return
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype == "application/javascript":
            ctype += "; charset=utf-8"
        body = target.read_bytes()
        if name == "index.html":
            body = body.replace(b"__SUBTITLE_SESSION_TOKEN__", SESSION_TOKEN.encode("ascii"))
        self.send_bytes(body, ctype)

    # ---------- API 实现 ----------
    def _create_job(self, body: dict) -> None:
        if DOWNLOADS.get()["status"] in ("downloading", "preparing"):
            raise ValueError("模型正在下载或安装，请完成后再识别")
        path = _require_file(body.get("path", ""))
        if not media.is_media(path):
            raise ValueError("不支持的媒体格式")
        model = str(body.get("model") or "medium")
        available = {m["name"] for m in list_models() if m["available"]}
        if model not in available:
            raise ValueError(f"模型 {model} 未下载，当前可用：{', '.join(sorted(available)) or '无'}")
        device = str(body.get("device") or "auto")
        if device not in ("auto", "cpu", "cuda"):
            raise ValueError("device 只能是 auto/cpu/cuda")
        gap_seconds = validation.number(body.get("gap_seconds", 0.6), "停顿阈值", 0, MAX_GAP_SECONDS)
        if not (0 <= gap_seconds <= MAX_GAP_SECONDS):
            raise ValueError(f"停顿断句阈值需在 0-{MAX_GAP_SECONDS:g} 秒之间")
        request_id = body.get("request_id")
        if request_id is not None and (not isinstance(request_id, str) or not re.fullmatch(r"[a-f0-9]{12,32}", request_id)):
            raise ValueError("request_id需为12–32位小写十六进制")
        job = JOBS.submit(path, model, device, validation.boolean(body.get("vad", True), "VAD"), gap_seconds, request_id=request_id)
        self.send_json({"ok": True, "job": job.to_dict(include_cues=False)})

    def _parse_srt(self, body: dict) -> None:
        if body.get("path"):
            path = _require_file(body["path"])
            cues, warnings, encoding = srt_io.parse_srt_file(path)
            name = os.path.basename(path)
        else:
            text = str(body.get("text") or "")
            cues, warnings = srt_io.parse_srt_text(text)
            encoding, name = "text", ""
        self.send_json({"ok": True, "cues": cues, "warnings": warnings,
                        "encoding": encoding, "name": name})

    def _export_srt(self, body: dict) -> None:
        cues = validation.cues(body.get("cues", []))
        if not isinstance(cues, list) or not cues:
            raise ValueError("没有可导出的字幕")
        options = validation.mapping(body.get("options", {}), "options")
        for key in ("add_punctuation", "with_role", "overwrite", "keep_punctuation", "skip_empty", "single_line"):
            if key in options:
                validation.boolean(options[key], key)
        media_path = _clean_path(body.get("media_path", "")) if body.get("media_path") else ""
        duration = 0.0
        if media_path:
            if not os.path.isfile(media_path):
                raise FileNotFoundError(f"视频不存在：{media_path}")
            duration = float(media.probe(media_path).get("duration") or 0)
        cues = srt_io.prepare_export_cues(
            cues, keep_punctuation=options.get("keep_punctuation", True),
            skip_empty=options.get("skip_empty", True), single_line=options.get("single_line", False),
        )
        errors = srt_io.validate_cues(cues, duration)
        if errors:
            self.send_json({"ok": False, "error": "导出检查未通过", "errors": errors}, 400)
            return
        text = srt_io.format_srt(
            cues,
            add_punctuation=bool(options.get("add_punctuation", False)) and options.get("keep_punctuation", True),
            with_role=bool(options.get("with_role", False)),
        )
        with WRITE_LOCK:
            overwrite = bool(options.get("overwrite", False))
            target = _output_path(media_path, options.get("output_dir"), overwrite)
            with target.open("w" if overwrite else "x", encoding="utf-8", newline="") as fh:
                fh.write(text)
        self.send_json({"ok": True, "path": str(target), "count": len(cues)})

    def _parse_script(self, body: dict) -> None:
        remove_after = False
        if body.get("path"):
            path = _require_file(body["path"])
            text, encoding = script.read_script_text(path)
            name = os.path.basename(path)
            remove_after = bool(body.get("remove_after"))
        else:
            text = str(body.get("text") or "")
            encoding, name = "text", ""
        document = reference_match.parse_document(text)
        lines = document["paragraphs"]
        if remove_after:
            try:
                uploaded = Path(path).resolve()
                uploads = UPLOADS_DIR.resolve()
                if uploads in uploaded.parents:
                    uploaded.unlink(missing_ok=True)
                    uploaded.parent.rmdir()
            except OSError:
                pass
        self.send_json({"ok": True, "lines": lines, "document": document,
                        "stats": {"total": len(lines), "characters": len(text)},
                        "encoding": encoding, "name": name})

    def _match_script(self, body: dict) -> None:
        cues = validation.cues(body.get("cues", []))
        lines = validation.lines(body.get("lines", []))
        if not isinstance(cues, list) or not isinstance(lines, list):
            raise ValueError("cues/lines 必须是数组")
        document = validation.mapping(body.get("document", {}), "document")
        if not document:
            document = {"text": "\n".join(line["text"] for line in lines)}
        options = validation.mapping(body.get("options", {}), "匹配选项")
        force = body.get("force_indices", [])
        if not isinstance(force, list) or any(isinstance(i, bool) or not isinstance(i, int) or not 0 <= i < len(cues) for i in force):
            raise ValueError("重新匹配序号无效")
        result = reference_match.match_reference(cues, document, options, force)
        self.send_json({"ok": True, **result})

    def _segment(self, body: dict) -> None:
        cues = validation.cues(body.get("cues", []))
        if not isinstance(cues, list):
            raise ValueError("cues 必须是数组")
        max_width = validation.number(body.get("max_width", 20), "每行宽度", MIN_WIDTH, MAX_WIDTH)
        if not (MIN_WIDTH <= max_width <= MAX_WIDTH):
            raise ValueError(f"每行宽度需在 {MIN_WIDTH:g}-{MAX_WIDTH:g} 之间")
        gap_seconds = validation.number(body.get("gap_seconds", 0), "停顿阈值", 0, MAX_GAP_SECONDS)
        if not (0 <= gap_seconds <= MAX_GAP_SECONDS):
            raise ValueError(f"停顿断句阈值需在 0-{MAX_GAP_SECONDS:g} 秒之间")
        gap_splits = 0
        if gap_seconds > 0:
            cues, gap_splits = segment.split_on_gaps(cues, gap_seconds)
        result, splits, estimated = segment.segment_cues(cues, max_width)
        self.send_json({"ok": True, "cues": result, "splits": splits, "gap_splits": gap_splits,
                        "estimated": estimated, "count": len(result)})

    def _merge(self, body: dict) -> None:
        cues = validation.cues(body.get("cues", []))
        if not isinstance(cues, list):
            raise ValueError("cues 必须是数组")
        result, merged = segment.merge_cues(
            cues,
            max_width=validation.number(body.get("max_width", 20), "每行宽度", MIN_WIDTH, MAX_WIDTH),
            max_duration=validation.number(body.get("max_duration", 7), "合并时长", 0.001, 60),
            max_gap=validation.number(body.get("max_gap", 0.25), "合并间隔", 0, 2),
        )
        self.send_json({"ok": True, "cues": result, "merged": merged, "count": len(result)})

    def _save_config(self, body: dict) -> None:
        settings = validation.mapping(body.get("settings", {}), "settings")
        layout = validation.mapping(body.get("layout", {}), "layout")
        if "gap" in settings:
            validation.number(settings["gap"], "停顿阈值", 0, MAX_GAP_SECONDS)
        if "width" in settings:
            validation.number(settings["width"], "每行宽度", MIN_WIDTH, MAX_WIDTH)
        for key in ("left", "right"):
            if key in layout:
                validation.number(layout[key], "栏宽", 100, 2000)
        theme = str(body.get("theme") or "system")
        if theme not in ("system", "light", "dark"):
            theme = "system"
        data = {
            "settings": settings,
            "layout": layout,
            "layout_version": 2 if body.get("layoutVersion") == 2 else 0,
            "theme": theme,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        target = _config_file()
        with locked_file(target):
            atomic_json(target, data)
        self.send_json({"ok": True, "path": str(target), "updated_at": data["updated_at"]})

    def _save_project(self, body: dict) -> None:
        media_path = _require_file(body.get("media_path") or body.get("source_path", ""))
        if not media.is_media(media_path) and Path(media_path).suffix.lower() != ".srt":
            raise ValueError("工程来源必须为媒体或SRT文件")
        cues = validation.cues(body.get("cues", []))
        expected = body.get("expected_revision", 0)
        if isinstance(expected, bool) or not isinstance(expected, int) or expected < 0:
            raise ValueError("expected_revision必须是非负整数")
        data = {
            "version": 2,
            "media_path": media_path if media.is_media(media_path) else "",
            "source_path": media_path,
            "cues": cues,
            "script_lines": validation.lines(body.get("script_lines", [])),
            "script_name": str(body.get("script_name") or ""),
            "script_document": validation.mapping(body.get("script_document") or {}, "script_document"),
            "subtitle_file": validation.mapping(body.get("subtitle_file") or {}, "subtitle_file"),
            "settings": validation.mapping(body.get("settings", {}), "settings"),
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        target = _project_path(media_path)
        with locked_file(target):
            current = validation.mapping(json.loads(target.read_text(encoding="utf-8")), "已有工程") if target.exists() else {}
            revision = current.get("revision", 0)
            if isinstance(revision, bool) or not isinstance(revision, int) or revision < 0:
                raise ValueError("已有工程版本号无效，已保留原文件，请先导出字幕备份")
            if expected != revision:
                raise RevisionConflict("工程已由其他页面更新；请先导出当前字幕备份，再重新加载工程")
            data["revision"] = revision + 1
            atomic_json(target, data)
        self.send_json({"ok": True, "path": str(target), "updated_at": data["updated_at"], "revision": data["revision"]})

    def _upload(self, query: dict) -> None:
        """浏览器拖入的文件：流向 data/uploads 工作目录，供识别与导出使用。"""
        self.close_connection = True
        self.connection.settimeout(60)
        if self.headers.get("Transfer-Encoding") or len(self.headers.get_all("Content-Length", [])) != 1:
            raise ValueError("上传必须使用单个Content-Length")
        kind = _qget(query, "kind", "media")
        if kind not in ("media", "script", "srt"):
            raise ValueError("上传类型不受支持")
        name = _safe_filename(unquote(self.headers.get("X-Upload-Name", "")))
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            raise ValueError("上传内容为空")
        if length > MAX_UPLOAD:
            raise ValueError("文件超过 20 GB")
        suffix = Path(name).suffix.lower()
        if kind == "media" and not media.is_media(name):
            raise ValueError("不支持的媒体格式")
        if kind == "script" and suffix not in (".txt", ".md", ".docx"):
            raise ValueError("剧本仅支持 txt / md / docx")
        if kind == "srt" and (suffix != ".srt" or length > 10 * 1024**2):
            raise ValueError("字幕仅支持 10 MB 以内的 SRT 文件")

        root = UPLOADS_DIR / ("_scripts" if kind == "script" else "_subtitles" if kind == "srt" else "drag")
        root.mkdir(parents=True, exist_ok=True)
        workdir = root / f"{time.strftime('%Y%m%d_%H%M%S')}_{os.urandom(3).hex()}"
        workdir.mkdir(parents=True, exist_ok=False)
        target = workdir / name
        temp = target.with_suffix(target.suffix + ".part")
        remaining = length
        try:
            with open(temp, "wb") as fh:
                while remaining > 0:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("上传中断")
                    fh.write(chunk)
                    remaining -= len(chunk)
            os.replace(temp, target)
        except Exception:
            try:
                temp.unlink(missing_ok=True)
                workdir.rmdir()
            except OSError:
                pass
            raise
        self.send_json({
            "ok": True, "path": str(target), "name": name,
            "dir": str(target.parent), "size": length,
        })

    def _dialog(self, body: dict) -> None:
        # 独立进程的主线程驱动Tk；同一服务只允许一个系统对话框。
        if not DIALOG_LOCK.acquire(blocking=False):
            raise ValueError("已有文件选择框打开，请先完成选择")
        try:
            kind = str(body.get("kind") or "media")
            if kind not in ("media", "script", "srt", "dir"):
                raise ValueError("未知对话框类型")
            result = subprocess.run(
                [sys.executable, str(Path(__file__).parent / "core" / "file_dialog.py")],
                input=json.dumps(body), capture_output=True, text=True, encoding="utf-8",
                timeout=600, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            if result.returncode:
                raise ValueError("无法打开系统文件选择框")
            self.send_json(json.loads(result.stdout))
        finally:
            DIALOG_LOCK.release()


def find_port(start: int = 8765) -> int:
    for port in range(start, start + 30):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("找不到可用端口")


def _dpi_aware() -> None:
    """让窗口尺寸按物理像素计算，避免 2K/125% 被误判成 2048 宽。"""
    try:
        import ctypes

        if ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            return
    except (AttributeError, OSError):
        pass
    try:
        import ctypes

        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except (AttributeError, OSError):
        pass


def window_geometry() -> tuple[int, int, int, int] | None:
    """按主屏工作区返回居中窗口尺寸与位置：(宽, 高, x, y)。"""
    if os.name != "nt":
        return None
    _dpi_aware()
    try:
        import ctypes
        from ctypes import wintypes

        rect = wintypes.RECT()
        if not ctypes.windll.user32.SystemParametersInfoW(
            0x0030, 0, ctypes.byref(rect), 0  # SPI_GETWORKAREA
        ):
            return None
        work_w = rect.right - rect.left
        work_h = rect.bottom - rect.top
        if work_w < 640 or work_h < 480:
            return None
        # 窗口比屏幕降一档：4K→2K，2K→1080p，1080p→720p。
        if work_w >= 3840:
            width, height = 2560, 1440
        elif work_w >= 2560:
            width, height = 1920, 1080
        elif work_w >= 1920:
            width, height = 1280, 720
        elif work_w >= 1280:
            width, height = 1280, 720
        else:
            width, height = round(work_w * 0.90), round(work_h * 0.90)
        width = max(640, min(width, work_w - 24))
        height = max(480, min(height, work_h - 24))
        x = rect.left + (work_w - width) // 2
        y = rect.top + (work_h - height) // 2
        return width, height, x, y
    except (AttributeError, OSError, ValueError):
        return None


def _dpi_scale() -> float:
    """系统缩放比例（125% → 1.25）。Chrome 命令行的窗口坐标/尺寸按 DIP 解释。"""
    try:
        import ctypes

        return max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0)
    except (AttributeError, OSError):
        return 1.0


def _browser_profile() -> str:
    """独立浏览器配置目录。

    复用用户日常 Chrome 时，窗口参数会发给已有进程并被忽略，窗口先出现在
    默认位置再被移动。独立配置让 Chrome 每次按参数直接开窗，不经过二次挪动。
    """
    path = Path(tempfile.gettempdir()) / "SubtitleStudio" / "chrome-profile"
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def open_browser(url: str) -> None:
    candidates = [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
    ]
    geometry = window_geometry()
    if geometry:
        # Chrome 把 --window-size/--window-position 当作 DIP，会再乘系统缩放；
        # 先除以缩放比例，首帧即落在物理像素的目标位置，无需开窗后再移动。
        scale = _dpi_scale()
        requested = tuple(round(v / scale) for v in geometry)
        window_args = [f"--window-size={requested[0]},{requested[1]}",
                       f"--window-position={requested[2]},{requested[3]}"]
    else:
        window_args = ["--window-size=1680,1000"]
    profile = _browser_profile()
    for exe in candidates:
        if os.path.isfile(exe):
            try:
                subprocess.Popen(
                    [exe, f"--app={url}", f"--user-data-dir={profile}",
                     "--no-first-run", "--no-default-browser-check",
                     "--disable-background-mode", *window_args],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
                if os.name == "nt":
                    from core.window_icon import apply_browser_icon
                    threading.Thread(target=apply_browser_icon,
                                     args=(FRONTEND_DIR / "assets" / "studio-film.ico", FRONTEND_DIR.parent / "run.bat"),
                                     daemon=True, name="window-icon").start()
                return
            except OSError:
                continue
    webbrowser.open(url)


def main() -> None:
    parser = argparse.ArgumentParser(description="字幕工作室后端")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    server = None
    for candidate in range(args.port, args.port + 30):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", candidate), Handler)
            break
        except OSError:
            continue
    if server is None:
        raise RuntimeError("找不到可用端口")
    port = server.server_port
    server.daemon_threads = True
    url = f"http://127.0.0.1:{port}/"
    models = list_models()
    available = [f"{m['name']}({m['size_gb']}G)" for m in models if m["available"]]
    print(f"字幕工作室 v{VERSION}  {url}")
    print(f"模型: {', '.join(available) if available else '未发现，请放入 data/models'}")
    print("Ctrl+C 停止")

    if not args.no_browser:
        import threading
        threading.Timer(0.6, lambda: open_browser(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
